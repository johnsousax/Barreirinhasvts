'use server';
import { z } from 'zod';
import { assertPermission } from '@/lib/auth';
import { check, run, type ActionResult } from '@/lib/action';
import { diff, logAudit } from '@/lib/audit';
import { DEFAULT_SETTINGS } from '@/lib/settings';
import { revalidateSite } from './_helpers';

const str = (max = 300) => z.string().trim().max(max).default('');
const settingsSchema = z.object({
  company_name: z.string().trim().min(2, 'Informe o nome').max(80),
  tagline: str(120), description: str(500), logo_url: str(1000), favicon_url: str(1000),
  phone: str(30),
  whatsapp: z.string().transform((v) => v.replace(/\D/g, '')).refine((v) => v.length >= 10 && v.length <= 13, 'WhatsApp inválido (use DDD)'),
  whatsapp_message: str(500), whatsapp_tour_message: str(500),
  email: z.string().trim().max(160).refine((v) => !v || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v), 'E-mail inválido').default(''),
  instagram: z.string().trim().max(60).transform((v) => v.replace(/^@/, '').replace(/^https?:\/\/(www\.)?instagram\.com\//, '').replace(/\/$/, '')).default(''),
  facebook_url: str(300), tiktok_url: str(300), youtube_url: str(300),
  address: str(300), city: str(80), state: str(2), zip: str(12), maps_url: str(1000), business_hours: str(200),
  seo_title: str(80), seo_description: str(200), og_image: str(1000),
  low_seats_threshold: z.coerce.number().min(0.05, 'Mínimo 0.05').max(0.9, 'Máximo 0.9'),
  show_closed_tours: z.boolean(),
  notify_email: z.string().trim().max(160).refine((v) => !v || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v), 'E-mail inválido').default(''),
  notify_new_booking: z.boolean(), notify_new_lead: z.boolean(),
});

export async function saveSettings(input: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('settings.manage');
    const data = settingsSchema.parse({ ...DEFAULT_SETTINGS, ...input });
    const { data: current } = await sb.from('site_settings').select('data').eq('id', 1).maybeSingle();
    check(await sb.from('site_settings').upsert({ id: 1, data, updated_by: staff.id, updated_at: new Date().toISOString() }).select('id'));
    const changes = diff((current?.data ?? {}) as Record<string, unknown>, data);
    await logAudit(sb, staff, { action: 'update', entity: 'site_settings', summary: `alterou as configurações (${Object.keys(changes).join(', ') || 'sem mudanças'})`, changes });
    revalidateSite();
    return { ok: true, message: 'Configurações salvas e aplicadas ao site.' };
  });
}
