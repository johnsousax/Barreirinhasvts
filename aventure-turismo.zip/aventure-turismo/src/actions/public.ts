'use server';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { createPublicClient } from '@/lib/supabase/public';
import { isSupabaseConfigured } from '@/lib/supabase/env';
import { getSettings } from '@/lib/data/public';
import { escapeHtml, sendEmail } from '@/lib/integrations/email';
import type { ActionResult } from '@/lib/action';

const phone = z.string().trim().refine((v) => { const d = v.replace(/\D/g, ''); return d.length >= 10 && d.length <= 13; }, 'Informe um WhatsApp com DDD');
const optionalEmail = z.string().trim().max(160).refine((v) => v === '' || /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v), 'E-mail inválido');

const bookingSchema = z.object({
  tourId: z.string().uuid(),
  scheduleId: z.string().uuid().or(z.literal('')),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).or(z.literal('')),
  time: z.string().max(20),
  name: z.string().trim().min(2, 'Informe seu nome').max(120),
  phone,
  email: optionalEmail,
  people: z.coerce.number().int().min(1, 'Mínimo 1 pessoa').max(50, 'Para grupos maiores, fale no WhatsApp'),
  notes: z.string().trim().max(1000),
  website: z.string().max(0, 'spam').optional(), // honeypot
});

export async function requestBooking(_: unknown, form: FormData): Promise<ActionResult<{ code: string; date: string; tour: string }>> {
  if (!isSupabaseConfigured) return { ok: false, error: 'Reservas online indisponíveis no momento. Use o WhatsApp.' };
  const raw = Object.fromEntries(['tourId', 'scheduleId', 'date', 'time', 'name', 'phone', 'email', 'people', 'notes', 'website'].map((k) => [k, String(form.get(k) ?? '')]));
  const parsed = bookingSchema.safeParse(raw);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    parsed.error.issues.forEach((i) => { fieldErrors[String(i.path[0])] ??= i.message; });
    if (fieldErrors.website) return { ok: false, error: 'Não foi possível enviar.' };
    if (!raw.scheduleId && !raw.date) fieldErrors.date = 'Escolha a data';
    return { ok: false, error: 'Revise os campos destacados.', fieldErrors };
  }
  const v = parsed.data;
  if (!v.scheduleId && !v.date) return { ok: false, error: 'Escolha a data do passeio.', fieldErrors: { date: 'Escolha a data' } };

  const { data, error } = await createPublicClient().rpc('request_booking', {
    p_tour_id: v.tourId, p_schedule_id: v.scheduleId || null, p_desired_date: v.date || null, p_desired_time: v.time || null,
    p_name: v.name, p_phone: v.phone, p_email: v.email || null, p_people: v.people, p_notes: v.notes || null,
  });
  if (error) {
    const known = /Restam|Escolha|Informe|inválid|indisponível|não está recebendo|Muitas/i.test(error.message);
    return { ok: false, error: known ? error.message : 'Não foi possível registrar agora. Tente de novo ou use o WhatsApp.' };
  }
  const row = (data as { booking_code: string; booking_date: string; tour_name: string }[])[0];

  const settings = await getSettings();
  if (settings.notify_new_booking && settings.notify_email) {
    await sendEmail(settings.notify_email, `Nova solicitação de reserva ${row.booking_code}`,
      `<p><b>${escapeHtml(v.name)}</b> solicitou <b>${escapeHtml(row.tour_name)}</b> para ${row.booking_date} (${v.people} pessoa(s)).</p><p>WhatsApp: ${escapeHtml(v.phone)}</p><p>Abra o painel para confirmar.</p>`);
  }
  revalidatePath('/passeios', 'layout');
  return { ok: true, data: { code: row.booking_code, date: row.booking_date, tour: row.tour_name } };
}

const contactSchema = z.object({
  name: z.string().trim().min(2, 'Informe seu nome').max(120),
  phone,
  email: optionalEmail,
  interest: z.string().trim().max(200),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).or(z.literal('')),
  message: z.string().trim().max(1500),
  website: z.string().max(0).optional(),
});

export async function submitContact(_: unknown, form: FormData): Promise<ActionResult> {
  if (!isSupabaseConfigured) return { ok: false, error: 'Formulário indisponível no momento. Use o WhatsApp.' };
  const parsed = contactSchema.safeParse(Object.fromEntries(['name', 'phone', 'email', 'interest', 'date', 'message', 'website'].map((k) => [k, String(form.get(k) ?? '')])));
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    parsed.error.issues.forEach((i) => { fieldErrors[String(i.path[0])] ??= i.message; });
    return { ok: false, error: 'Revise os campos destacados.', fieldErrors };
  }
  const v = parsed.data;
  const { error } = await createPublicClient().rpc('submit_lead', {
    p_name: v.name, p_phone: v.phone, p_email: v.email || null, p_interest: v.interest || 'Contato pelo site',
    p_tour_id: null, p_desired_date: v.date || null, p_notes: v.message || null, p_source: 'formulario_contato',
  });
  if (error) return { ok: false, error: /Muitas|inválid|Informe/.test(error.message) ? error.message : 'Não foi possível enviar agora. Tente pelo WhatsApp.' };
  const settings = await getSettings();
  if (settings.notify_new_lead && settings.notify_email) {
    await sendEmail(settings.notify_email, 'Novo contato pelo site', `<p><b>${escapeHtml(v.name)}</b> (${escapeHtml(v.phone)})</p><p>${escapeHtml(v.interest)}</p><p>${escapeHtml(v.message)}</p>`);
  }
  return { ok: true, message: 'Mensagem enviada! Vamos responder pelo WhatsApp em breve.' };
}
