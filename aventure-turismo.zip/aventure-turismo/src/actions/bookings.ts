'use server';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { assertPermission, ActionError } from '@/lib/auth';
import { check, run, type ActionResult } from '@/lib/action';
import { logAudit } from '@/lib/audit';
import { BOOKING_STATUS } from '@/lib/tour-status';
import type { BookingStatus } from '@/lib/types';
import { revalidateSite } from './_helpers';

const STATUSES = Object.keys(BOOKING_STATUS) as [BookingStatus, ...BookingStatus[]];
const uuidOrNull = z.preprocess((v) => (v === '' || v == null ? null : v), z.string().uuid().nullable());
const moneyOrNull = z.preprocess((v) => (v === '' || v == null ? null : Number(String(v).replace(',', '.'))), z.number().min(0).nullable());

const bookingSchema = z.object({
  customer_id: uuidOrNull,
  customer_name: z.string().trim().max(120).optional().default(''),
  customer_phone: z.string().trim().max(30).optional().default(''),
  customer_email: z.string().trim().max(160).optional().default(''),
  tour_id: z.string().uuid('Escolha o passeio'),
  schedule_id: uuidOrNull,
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Informe a data'),
  start_time: z.preprocess((v) => (v === '' ? null : v), z.string().regex(/^\d{2}:\d{2}/).nullable()),
  people: z.coerce.number().int().min(1, 'Mínimo 1 pessoa').max(200),
  unit_price: moneyOrNull,
  total_amount: moneyOrNull,
  status: z.enum(STATUSES),
  source: z.string().trim().min(1).max(40),
  notes: z.preprocess((v) => (v === '' ? null : v), z.string().max(2000).nullable()),
  lead_id: uuidOrNull.optional(),
}).refine((v) => v.customer_id || (v.customer_name.length >= 2 && v.customer_phone.replace(/\D/g, '').length >= 10), {
  message: 'Selecione um cliente ou informe nome e telefone', path: ['customer_name'],
});

export async function saveBooking(id: string | null, input: Record<string, unknown>): Promise<ActionResult<{ id: string }>> {
  return run(async () => {
    const { staff, sb } = await assertPermission('bookings.manage');
    const v = bookingSchema.parse(input);
    let customerId = v.customer_id;
    if (!customerId) {
      const digits = v.customer_phone.replace(/\D/g, '');
      const { data: found } = await sb.from('customers').select('id, phone, whatsapp').or(`phone.ilike.%${digits.slice(-8)}%,whatsapp.ilike.%${digits.slice(-8)}%`).limit(5);
      const match = found?.find((c) => [c.phone, c.whatsapp].some((p) => (p ?? '').replace(/\D/g, '').endsWith(digits.slice(-10))));
      customerId = match?.id ?? (check(await sb.from('customers').insert({
        name: v.customer_name, phone: v.customer_phone, whatsapp: v.customer_phone, email: v.customer_email || null, source: v.source,
      }).select('id').single()) as { id: string }).id;
    }
    const row = {
      customer_id: customerId, tour_id: v.tour_id, schedule_id: v.schedule_id, date: v.date, start_time: v.start_time,
      people: v.people, unit_price: v.unit_price, total_amount: v.total_amount ?? (v.unit_price != null ? v.unit_price * v.people : null),
      status: v.status, source: v.source, notes: v.notes, lead_id: v.lead_id ?? null,
    };
    let code: string;
    if (id) {
      const r = check(await sb.from('bookings').update(row).eq('id', id).select('code').single()) as { code: string };
      code = r.code;
      await logAudit(sb, staff, { action: 'update', entity: 'bookings', entityId: id, summary: `editou a reserva ${code}`, changes: row });
    } else {
      const r = check(await sb.from('bookings').insert({ ...row, created_by: staff.id }).select('id, code').single()) as { id: string; code: string };
      id = r.id; code = r.code;
      await logAudit(sb, staff, { action: 'create', entity: 'bookings', entityId: id, summary: `criou a reserva ${code}` });
      if (v.lead_id) await sb.from('leads').update({ stage: 'reservado', customer_id: customerId }).eq('id', v.lead_id);
    }
    revalidatePath('/admin/reservas');
    revalidatePath('/admin');
    if (v.schedule_id) revalidateSite();
    return { ok: true, data: { id: id! }, message: `Reserva ${code} salva.` };
  });
}

export async function setBookingStatus(id: string, status: BookingStatus, note?: string): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('bookings.manage');
    if (!(status in BOOKING_STATUS)) throw new ActionError('Status inválido.');
    const before = check(await sb.from('bookings').select('code, status, schedule_id, lead_id').eq('id', id).single()) as { code: string; status: BookingStatus; schedule_id: string | null; lead_id: string | null };
    if (before.status === status) return { ok: true };
    check(await sb.from('bookings').update({ status }).eq('id', id).select('id').single());
    if (note?.trim()) {
      const { data: last } = await sb.from('booking_history').select('id').eq('booking_id', id).eq('to_status', status)
        .order('created_at', { ascending: false }).limit(1).maybeSingle();
      if (last) await sb.from('booking_history').update({ note: note.trim().slice(0, 500) }).eq('id', last.id);
    }
    if (before.lead_id && (status === 'concluida' || status === 'pago')) {
      await sb.from('leads').update({ stage: status === 'concluida' ? 'concluido' : 'reservado' }).eq('id', before.lead_id);
    }
    await logAudit(sb, staff, {
      action: 'status', entity: 'bookings', entityId: id,
      summary: `alterou a reserva ${before.code} de ${BOOKING_STATUS[before.status].label} para ${BOOKING_STATUS[status].label}`,
      changes: { status: { de: before.status, para: status }, note },
    });
    revalidatePath('/admin/reservas');
    revalidatePath(`/admin/reservas/${id}`);
    if (before.schedule_id) revalidateSite();
    return { ok: true, message: `Reserva ${BOOKING_STATUS[status].label.toLowerCase()}.` };
  });
}

const paymentSchema = z.object({
  amount: z.preprocess((v) => Number(String(v).replace(',', '.')), z.number().positive('Valor inválido')),
  method: z.enum(['pix', 'cartao', 'dinheiro', 'transferencia', 'outro']),
  status: z.enum(['pendente', 'pago', 'estornado', 'cancelado']),
  paid_at: z.preprocess((v) => (v ? new Date(String(v)).toISOString() : new Date().toISOString()), z.string()),
  notes: z.preprocess((v) => (v === '' ? null : v), z.string().max(300).nullable()),
});

export async function addPayment(bookingId: string, input: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('bookings.manage');
    const v = paymentSchema.parse(input);
    check(await sb.from('payments').insert({ ...v, booking_id: bookingId, created_by: staff.id }).select('id').single());
    const b = check(await sb.from('bookings').select('code').eq('id', bookingId).single()) as { code: string };
    await logAudit(sb, staff, { action: 'create', entity: 'payments', entityId: bookingId, summary: `registrou pagamento de R$ ${v.amount.toFixed(2)} na reserva ${b.code}` });
    revalidatePath(`/admin/reservas/${bookingId}`);
    return { ok: true, message: 'Pagamento registrado.' };
  });
}

export async function deletePayment(bookingId: string, paymentId: string): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('bookings.manage');
    check(await sb.from('payments').delete().eq('id', paymentId).eq('booking_id', bookingId).select('id'));
    await logAudit(sb, staff, { action: 'delete', entity: 'payments', entityId: bookingId, summary: 'removeu um pagamento' });
    revalidatePath(`/admin/reservas/${bookingId}`);
    return { ok: true, message: 'Pagamento removido.' };
  });
}

const passengerSchema = z.object({
  name: z.string().trim().min(2, 'Informe o nome').max(120),
  document: z.preprocess((v) => (v === '' ? null : v), z.string().max(30).nullable()),
  birth_date: z.preprocess((v) => (v === '' ? null : v), z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable()),
  phone: z.preprocess((v) => (v === '' ? null : v), z.string().max(30).nullable()),
});

export async function addPassenger(bookingId: string, input: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const { sb } = await assertPermission('bookings.manage');
    check(await sb.from('booking_passengers').insert({ ...passengerSchema.parse(input), booking_id: bookingId }).select('id'));
    revalidatePath(`/admin/reservas/${bookingId}`);
    return { ok: true, message: 'Passageiro adicionado.' };
  });
}

export async function deletePassenger(bookingId: string, passengerId: string): Promise<ActionResult> {
  return run(async () => {
    const { sb } = await assertPermission('bookings.manage');
    check(await sb.from('booking_passengers').delete().eq('id', passengerId).eq('booking_id', bookingId).select('id'));
    revalidatePath(`/admin/reservas/${bookingId}`);
    return { ok: true, message: 'Passageiro removido.' };
  });
}

export async function getSchedulesForTour(tourId: string) {
  const { sb } = await assertPermission('bookings.manage');
  const today = new Date().toISOString().slice(0, 10);
  const { data } = await sb.from('schedule_availability').select('id, date, start_time, capacity, available, status')
    .eq('tour_id', tourId).gte('date', today).in('status', ['aberto', 'fechado']).order('date').order('start_time').limit(100);
  return data ?? [];
}

export async function searchCustomers(q: string) {
  const { sb } = await assertPermission('customers.manage');
  const term = q.trim().replace(/[%,()]/g, '');
  if (term.length < 2) return [];
  const { data } = await sb.from('customers').select('id, name, phone, email').or(`name.ilike.%${term}%,phone.ilike.%${term}%,email.ilike.%${term}%`).limit(8);
  return data ?? [];
}
