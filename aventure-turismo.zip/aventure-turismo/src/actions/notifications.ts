'use server';
import { revalidatePath } from 'next/cache';
import { assertPermission, getCurrentStaff } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { run, type ActionResult } from '@/lib/action';

export interface NotificationItem { id: string; kind: string; title: string; body: string | null; link: string | null; created_at: string; read: boolean }

export async function listNotifications(limit = 30): Promise<{ items: NotificationItem[]; unread: number }> {
  const staff = await getCurrentStaff();
  if (!staff?.permissions.includes('notifications.view')) return { items: [], unread: 0 };
  const sb = await createClient();
  const [{ data: items }, { data: reads }] = await Promise.all([
    sb.from('notifications').select('id, kind, title, body, link, created_at').order('created_at', { ascending: false }).limit(limit),
    sb.from('notification_reads').select('notification_id').eq('user_id', staff.id).gte('read_at', new Date(Date.now() - 90 * 864e5).toISOString()),
  ]);
  const readSet = new Set((reads ?? []).map((r) => r.notification_id));
  const list = (items ?? []).map((n) => ({ ...n, read: readSet.has(n.id) }));
  return { items: list, unread: list.filter((n) => !n.read).length };
}

export async function markNotificationsRead(ids: string[]): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('notifications.view');
    if (ids.length) await sb.from('notification_reads').upsert(ids.slice(0, 200).map((id) => ({ notification_id: id, user_id: staff.id })), { ignoreDuplicates: true });
    revalidatePath('/admin/notificacoes');
    return { ok: true };
  });
}
