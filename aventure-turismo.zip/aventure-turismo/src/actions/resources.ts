'use server';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { assertPermission, ActionError } from '@/lib/auth';
import { check, run, type ActionResult } from '@/lib/action';
import { logAudit } from '@/lib/audit';
import { RESOURCES, type FieldDef } from '@/lib/resources';
import { slugify } from '@/lib/format';
import { revalidateSite } from './_helpers';

function fieldSchema(f: FieldDef) {
  const opt = <T extends z.ZodTypeAny>(s: T) => (f.required ? s : s.nullable().optional());
  switch (f.type) {
    case 'number': return z.preprocess((v) => (v === '' || v == null ? (f.required ? undefined : null) : Number(v)), opt(z.number({ message: 'Número inválido' })));
    case 'rating': return z.coerce.number().int().min(1).max(5);
    case 'boolean': return z.preprocess((v) => v === true || v === 'true' || v === 'on', z.boolean());
    case 'date': return z.preprocess((v) => (v === '' ? null : v), opt(z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida')));
    case 'datetime': return z.preprocess((v) => (v === '' || v == null ? null : new Date(String(v)).toISOString()), opt(z.string()));
    case 'select': {
      const s = f.options ? z.enum(f.options.map((o) => o.value) as [string, ...string[]], { message: 'Selecione uma opção' }) : z.string().uuid();
      return z.preprocess((v) => (v === '' ? null : v), opt(s));
    }
    case 'url': return z.preprocess((v) => (v === '' ? null : v), opt(z.string().url('Link inválido')));
    default: {
      const s = z.string().trim().max(f.type === 'textarea' ? 10000 : 500);
      return f.required ? s.min(1, 'Campo obrigatório') : z.preprocess((v) => (v === '' ? null : v), s.nullable().optional());
    }
  }
}

export async function saveResource(key: string, id: string | null, values: Record<string, unknown>): Promise<ActionResult<{ id: string }>> {
  return run(async () => {
    const def = RESOURCES[key];
    if (!def) throw new ActionError('Recurso inválido.');
    const { staff, sb } = await assertPermission(def.permission);
    const shape = Object.fromEntries(def.fields.map((f) => [f.name, fieldSchema(f)]));
    const data = z.object(shape).parse(values) as Record<string, unknown>;

    for (const f of def.fields.filter((x) => x.type === 'slug')) {
      data[f.name] = slugify(String(data[f.name] || data[f.slugFrom ?? 'name'] || ''));
      if (!data[f.name]) throw new ActionError('Informe um nome para gerar o endereço.');
    }
    if (def.table === 'ideas' && !id) data.created_by = staff.id;

    const label = String(data[def.labelField] ?? def.singular);
    if (id) {
      check(await sb.from(def.table).update(data).eq('id', id).select('id').single());
      await logAudit(sb, staff, { action: 'update', entity: def.table, entityId: id, summary: `editou ${def.singular} "${label}"`, changes: data });
    } else {
      const row = check(await sb.from(def.table).insert(data).select('id').single()) as { id: string };
      id = row.id;
      await logAudit(sb, staff, { action: 'create', entity: def.table, entityId: id, summary: `criou ${def.singular} "${label}"` });
    }
    if (def.revalidate.length) revalidateSite(def.revalidate);
    revalidatePath(`/admin/${def.key}`);
    return { ok: true, data: { id: id! }, message: 'Alterações salvas.' };
  });
}

export async function toggleResource(key: string, id: string, field: string, value: boolean): Promise<ActionResult> {
  return run(async () => {
    const def = RESOURCES[key];
    if (!def || !def.toggles.some((t) => t.name === field)) throw new ActionError('Operação inválida.');
    const { staff, sb } = await assertPermission(def.permission);
    const row = check(await sb.from(def.table).update({ [field]: value }).eq('id', id).select(def.labelField).single()) as Record<string, string>;
    const t = def.toggles.find((x) => x.name === field)!;
    await logAudit(sb, staff, { action: 'update', entity: def.table, entityId: id, summary: `alterou ${t.label.toLowerCase()} de ${def.singular} "${row[def.labelField] ?? ''}" para ${value ? t.onLabel : t.offLabel}` });
    if (def.revalidate.length) revalidateSite(def.revalidate);
    revalidatePath(`/admin/${def.key}`);
    return { ok: true, message: value ? t.onLabel : t.offLabel };
  });
}

export async function deleteResource(key: string, id: string): Promise<ActionResult> {
  return run(async () => {
    const def = RESOURCES[key];
    if (!def) throw new ActionError('Recurso inválido.');
    const { staff, sb } = await assertPermission(def.permission);
    const row = check(await sb.from(def.table).delete().eq('id', id).select(def.labelField).single()) as Record<string, string>;
    await logAudit(sb, staff, { action: 'delete', entity: def.table, entityId: id, summary: `excluiu ${def.singular} "${row[def.labelField] ?? ''}"` });
    if (def.revalidate.length) revalidateSite(def.revalidate);
    revalidatePath(`/admin/${def.key}`);
    return { ok: true, message: 'Excluído.' };
  });
}
