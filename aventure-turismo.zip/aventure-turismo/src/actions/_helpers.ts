import { revalidatePath } from 'next/cache';

/** Atualiza todo o site público após uma alteração no painel. */
export function revalidateSite(paths: string[] = []) {
  revalidatePath('/', 'layout');
  paths.forEach((p) => revalidatePath(p));
}

export const emptyToNull = (v: unknown) => (v === '' || v === undefined ? null : v);
