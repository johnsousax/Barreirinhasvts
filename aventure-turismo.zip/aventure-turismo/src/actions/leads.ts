'use server';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { assertPermission } from '@/lib/auth';
import { check, run, type ActionResult } from '@/lib/action';
import { logAudit } from '@/lib/audit';
import { LEAD_STAGES } from '@/lib/tour-status';
import type { LeadStage } from '@/lib/types';

const STAGES = LEAD_STAGES.map((s) => s.key) as [LeadStage, ...LeadStage[]];
const opt = (max: number) => z.preprocess((v) => (typeof v === 'string' && v.trim() === '' ? null : v), z.string().trim().max(max).nullable());

const leadSchema = z.object({
  name: z.string().trim().min(2, 'Informe o nome').max(120),
  phone: opt(30), whatsapp: opt(30),
  email: z.preprocess((v) => (v === '' ? null : v), z.string().email('E-mail inválido').nullable()),
  interest: opt(200),
  tour_id: z.preprocess((v) => (v === '' ? null : v), z.string().uuid().nullable()),
  desired_date: z.preprocess((v) => (v === '' ? null : v), z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable()),
  people: z.preprocess((v) => (v === '' || v == null ? null : Number(v)), z.number().int().positive().nullable()),
  notes: opt(3000),
  source: z.string().trim().min(1).max(40),
  stage: z.enum(STAGES),
  lost_reason: opt(300),
});

export async function saveLead(id: string | null, input: Record<string, unknown>): Promise<ActionResult<{ id: string }>> {
  return run(async () => {
    const { staff, sb } = await assertPermission('leads.manage');
    const v = leadSchema.parse(input);
    if (id) {
      check(await sb.from('leads').update(v).eq('id', id).select('id').single());
      await logAudit(sb, staff, { action: 'update', entity: 'leads', entityId: id, summary: `editou o lead ${v.name}` });
    } else {
      id = (check(await sb.from('leads').insert({ ...v, assigned_to: staff.id }).select('id').single()) as { id: string }).id;
      await logAudit(sb, staff, { action: 'create', entity: 'leads', entityId: id, summary: `criou o lead ${v.name}` });
    }
    revalidatePath('/admin/leads');
    return { ok: true, data: { id: id! }, message: 'Lead salvo.' };
  });
}

export async function moveLead(id: string, stage: LeadStage, position?: number): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('leads.manage');
    if (!STAGES.includes(stage)) return { ok: false, error: 'Etapa inválida.' };
    const before = check(await sb.from('leads').select('name, stage').eq('id', id).single()) as { name: string; stage: LeadStage };
    check(await sb.from('leads').update({ stage, ...(position != null ? { position } : {}) }).eq('id', id).select('id').single());
    if (before.stage !== stage) {
      const label = (k: LeadStage) => LEAD_STAGES.find((s) => s.key === k)?.label;
      await logAudit(sb, staff, { action: 'status', entity: 'leads', entityId: id, summary: `moveu o lead ${before.name} de ${label(before.stage)} para ${label(stage)}` });
    }
    revalidatePath('/admin/leads');
    return { ok: true };
  });
}

export async function addLeadNote(id: string, note: string): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('leads.manage');
    const text = z.string().trim().min(2, 'Escreva a anotação').max(1000).parse(note);
    const lead = check(await sb.from('leads').select('stage').eq('id', id).single()) as { stage: LeadStage };
    check(await sb.from('lead_history').insert({ lead_id: id, from_stage: lead.stage, to_stage: lead.stage, note: text, created_by: staff.id }).select('id'));
    revalidatePath('/admin/leads');
    return { ok: true, message: 'Anotação adicionada.' };
  });
}

export async function getLeadHistory(id: string) {
  const { sb } = await assertPermission('leads.manage');
  const { data } = await sb.from('lead_history').select('id, from_stage, to_stage, note, created_at, author:profiles(full_name)').eq('lead_id', id).order('created_at', { ascending: false }).limit(50);
  return (data ?? []) as unknown as { id: string; from_stage: LeadStage | null; to_stage: LeadStage | null; note: string | null; created_at: string; author: { full_name: string } | null }[];
}

export async function deleteLead(id: string): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('leads.manage');
    const l = check(await sb.from('leads').delete().eq('id', id).select('name').single()) as { name: string };
    await logAudit(sb, staff, { action: 'delete', entity: 'leads', entityId: id, summary: `excluiu o lead ${l.name}` });
    revalidatePath('/admin/leads');
    return { ok: true, message: 'Lead excluído.' };
  });
}
