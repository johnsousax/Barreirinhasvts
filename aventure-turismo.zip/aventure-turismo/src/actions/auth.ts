'use server';
import { redirect } from 'next/navigation';
import { headers } from 'next/headers';
import { z } from 'zod';
import { createClient } from '@/lib/supabase/server';
import { isSupabaseConfigured, SITE_URL } from '@/lib/supabase/env';
import type { ActionResult } from '@/lib/action';

const loginSchema = z.object({ email: z.string().trim().email('E-mail inválido'), password: z.string().min(6, 'Senha muito curta') });

export async function signIn(_: unknown, form: FormData): Promise<ActionResult> {
  if (!isSupabaseConfigured) return { ok: false, error: 'Supabase não configurado. Veja o README.' };
  const parsed = loginSchema.safeParse({ email: form.get('email'), password: form.get('password') });
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message };
  const sb = await createClient();
  const { data, error } = await sb.auth.signInWithPassword(parsed.data);
  if (error) return { ok: false, error: 'E-mail ou senha incorretos.' };
  const { data: profile } = await sb.from('profiles').select('active, full_name, email').eq('id', data.user.id).maybeSingle();
  if (!profile?.active) {
    await sb.auth.signOut();
    return { ok: false, error: 'Seu acesso ainda não foi liberado. Fale com o administrador.' };
  }
  await sb.from('profiles').update({ last_seen_at: new Date().toISOString() }).eq('id', data.user.id);
  await sb.from('audit_logs').insert({ user_id: data.user.id, user_name: profile.full_name || profile.email, action: 'login', entity: 'auth', summary: `${profile.full_name || profile.email} entrou no painel` });
  const next = String(form.get('next') ?? '');
  redirect(next.startsWith('/admin') ? next : '/admin');
}

export async function signOut() {
  const sb = await createClient();
  await sb.auth.signOut();
  redirect('/admin/login');
}

export async function requestPasswordReset(_: unknown, form: FormData): Promise<ActionResult> {
  if (!isSupabaseConfigured) return { ok: false, error: 'Supabase não configurado.' };
  const email = z.string().trim().email().safeParse(form.get('email'));
  if (!email.success) return { ok: false, error: 'Informe um e-mail válido.' };
  const origin = (await headers()).get('origin') ?? SITE_URL;
  const sb = await createClient();
  await sb.auth.resetPasswordForEmail(email.data, { redirectTo: `${origin}/auth/callback?next=/admin/redefinir-senha` });
  // resposta idêntica exista ou não o e-mail (evita enumeração de contas)
  return { ok: true, message: 'Se o e-mail estiver cadastrado, você receberá um link para criar uma nova senha.' };
}

export async function updatePassword(_: unknown, form: FormData): Promise<ActionResult> {
  const schema = z.object({ password: z.string().min(8, 'Use pelo menos 8 caracteres'), confirm: z.string() })
    .refine((v) => v.password === v.confirm, { message: 'As senhas não conferem', path: ['confirm'] });
  const parsed = schema.safeParse({ password: form.get('password'), confirm: form.get('confirm') });
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message };
  const sb = await createClient();
  const { error } = await sb.auth.updateUser({ password: parsed.data.password });
  if (error) return { ok: false, error: 'Link expirado. Solicite um novo e tente de novo.' };
  redirect('/admin');
}
