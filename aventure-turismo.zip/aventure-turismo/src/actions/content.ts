'use server';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { assertPermission, ActionError } from '@/lib/auth';
import { check, run, type ActionResult } from '@/lib/action';
import { logAudit } from '@/lib/audit';
import { CMS_BY_KEY } from '@/lib/cms-schema';
import { revalidateSite } from './_helpers';

const content = z.record(z.string(), z.unknown()).refine((v) => JSON.stringify(v).length < 60000, 'Conteúdo muito grande');

export async function saveSectionDraft(key: string, data: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const section = CMS_BY_KEY[key];
    if (!section) throw new ActionError('Seção inválida.');
    const { staff, sb } = await assertPermission('content.manage');
    const draft = content.parse(data);
    check(await sb.from('site_sections').upsert({ key, draft, has_unpublished: true, updated_by: staff.id, updated_at: new Date().toISOString() }).select('key'));
    await logAudit(sb, staff, { action: 'draft', entity: 'site_sections', entityId: key, summary: `salvou rascunho da seção "${section.label}"` });
    revalidatePath('/admin/conteudo');
    return { ok: true, message: 'Rascunho salvo. Publique para aparecer no site.' };
  });
}

export async function publishSection(key: string, data?: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const section = CMS_BY_KEY[key];
    if (!section) throw new ActionError('Seção inválida.');
    const { staff, sb } = await assertPermission('content.manage');
    let value = data ? content.parse(data) : null;
    if (!value) {
      const row = check(await sb.from('site_sections').select('draft').eq('key', key).single()) as { draft: Record<string, unknown> };
      value = row.draft;
    }
    const now = new Date().toISOString();
    check(await sb.from('site_sections').upsert({ key, draft: value, published: value, has_unpublished: false, updated_by: staff.id, updated_at: now, published_by: staff.id, published_at: now }).select('key'));
    await logAudit(sb, staff, { action: 'publish', entity: 'site_sections', entityId: key, summary: `publicou a seção "${section.label}"` });
    revalidateSite();
    revalidatePath('/admin/conteudo');
    return { ok: true, message: `"${section.label}" publicado no site.` };
  });
}

export async function publishAllSections(): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('content.manage');
    const rows = check(await sb.from('site_sections').select('key, draft').eq('has_unpublished', true)) as { key: string; draft: Record<string, unknown> }[];
    const now = new Date().toISOString();
    for (const r of rows) {
      check(await sb.from('site_sections').update({ published: r.draft, has_unpublished: false, published_by: staff.id, published_at: now }).eq('key', r.key).select('key'));
    }
    await logAudit(sb, staff, { action: 'publish', entity: 'site_sections', summary: `publicou ${rows.length} seção(ões) do site` });
    revalidateSite();
    revalidatePath('/admin/conteudo');
    return { ok: true, message: rows.length ? `${rows.length} seção(ões) publicada(s).` : 'Não há alterações pendentes.' };
  });
}

export async function discardSectionDraft(key: string): Promise<ActionResult> {
  return run(async () => {
    const { sb } = await assertPermission('content.manage');
    const row = check(await sb.from('site_sections').select('published').eq('key', key).single()) as { published: Record<string, unknown> };
    check(await sb.from('site_sections').update({ draft: row.published, has_unpublished: false }).eq('key', key).select('key'));
    revalidatePath('/admin/conteudo');
    return { ok: true, message: 'Rascunho descartado.' };
  });
}
