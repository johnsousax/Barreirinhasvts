'use server';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { assertPermission, ActionError } from '@/lib/auth';
import { check, run, type ActionResult } from '@/lib/action';
import { diff, logAudit } from '@/lib/audit';
import { slugify } from '@/lib/format';
import { TOUR_STATUS } from '@/lib/tour-status';
import type { TourStatus } from '@/lib/types';
import { revalidateSite } from './_helpers';

const nullableText = (max = 500) => z.preprocess((v) => (typeof v === 'string' && v.trim() === '' ? null : v), z.string().trim().max(max).nullable());
const money = z.preprocess((v) => (v === '' || v == null ? null : Number(String(v).replace(',', '.'))), z.number().min(0, 'Valor inválido').nullable());
const list = z.array(z.string().trim().max(300)).transform((a) => a.filter(Boolean));
const STATUSES = Object.keys(TOUR_STATUS) as [TourStatus, ...TourStatus[]];

const tourSchema = z.object({
  name: z.string().trim().min(2, 'Informe o nome').max(120),
  slug: z.string().trim().max(120).optional().default(''),
  short_description: nullableText(300),
  description: nullableText(8000),
  category_id: z.preprocess((v) => (v === '' ? null : v), z.string().uuid().nullable()),
  destination_id: z.preprocess((v) => (v === '' ? null : v), z.string().uuid().nullable()),
  tour_type: z.enum(['compartilhado', 'privativo', 'ambos']),
  duration_label: nullableText(80),
  duration_minutes: z.preprocess((v) => (v === '' || v == null ? null : Number(v)), z.number().int().positive('Duração inválida').nullable()),
  price: money,
  promo_price: money,
  price_note: nullableText(80),
  capacity: z.coerce.number().int().min(0).max(1000),
  default_times: z.array(z.string().regex(/^\d{2}:\d{2}$/, 'Horário no formato 08:00')).default([]),
  meeting_point: nullableText(300),
  itinerary: z.array(z.object({ time: z.string().max(10).optional().default(''), title: z.string().trim().max(120), description: z.string().max(500).optional().default('') }))
    .transform((a) => a.filter((s) => s.title)),
  included: list, not_included: list, recommendations: list, important_info: list,
  cover_url: nullableText(1000),
  photos: z.array(z.string().max(1000)).max(20).default([]),
  video_url: z.preprocess((v) => (v === '' ? null : v), z.string().url('Link de vídeo inválido').nullable()),
  status: z.enum(STATUSES),
  featured: z.boolean(),
  sort_order: z.coerce.number().int(),
  whatsapp_message: nullableText(500),
  seo_title: nullableText(70),
  seo_description: nullableText(170),
  is_placeholder: z.boolean(),
}).refine((v) => v.promo_price == null || v.price == null || v.promo_price < v.price, { message: 'O preço promocional deve ser menor que o preço', path: ['promo_price'] });

export type TourInput = z.input<typeof tourSchema>;

/**
 * mode = 'draft'   → novo passeio: salva como rascunho (fora do site).
 *                    passeio publicado: guarda as mudanças em draft_data sem alterar o site.
 * mode = 'publish' → aplica tudo e publica.
 */
export async function saveTour(id: string | null, input: TourInput, mode: 'draft' | 'publish'): Promise<ActionResult<{ id: string; slug: string }>> {
  return run(async () => {
    const { staff, sb } = await assertPermission('tours.manage');
    const data = tourSchema.parse(input);
    data.slug = slugify(data.slug || data.name);
    if (!data.cover_url && data.photos.length) data.cover_url = data.photos[0];

    const current = id ? check(await sb.from('tours').select('*').eq('id', id).single()) as Record<string, unknown> : null;

    if (mode === 'draft' && current?.publication === 'publicado') {
      check(await sb.from('tours').update({ draft_data: data, updated_by: staff.id }).eq('id', id!).select('id').single());
      await logAudit(sb, staff, { action: 'draft', entity: 'tours', entityId: id, summary: `salvou um rascunho do passeio "${data.name}"` });
      revalidatePath(`/admin/passeios/${id}`);
      return { ok: true, data: { id: id!, slug: String(current.slug) }, message: 'Rascunho salvo. O site continua com a versão publicada.' };
    }

    const row = {
      ...data,
      draft_data: null,
      updated_by: staff.id,
      ...(mode === 'publish' ? { publication: 'publicado', published_at: current?.published_at ?? new Date().toISOString() } : {}),
    };

    if (current) {
      check(await sb.from('tours').update(row).eq('id', id!).select('id').single());
      const changes = diff(current, data);
      const statusChange = changes.status
        ? ` e alterou o status de ${TOUR_STATUS[changes.status.de as TourStatus]?.label} para ${TOUR_STATUS[data.status].label}` : '';
      await logAudit(sb, staff, {
        action: mode === 'publish' ? 'publish' : 'update', entity: 'tours', entityId: id,
        summary: `${mode === 'publish' ? 'publicou' : 'editou'} o passeio "${data.name}"${statusChange}`, changes,
      });
    } else {
      const created = check(await sb.from('tours').insert({ ...row, publication: mode === 'publish' ? 'publicado' : 'rascunho', created_by: staff.id }).select('id').single()) as { id: string };
      id = created.id;
      await logAudit(sb, staff, { action: 'create', entity: 'tours', entityId: id, summary: `criou o passeio "${data.name}"${mode === 'publish' ? ' e publicou' : ' como rascunho'}` });
    }
    revalidateSite(['/passeios', `/passeios/${data.slug}`]);
    revalidatePath('/admin/passeios');
    return { ok: true, data: { id: id!, slug: data.slug }, message: mode === 'publish' ? 'Passeio publicado. O site já foi atualizado.' : 'Rascunho salvo.' };
  });
}

export async function discardTourDraft(id: string): Promise<ActionResult> {
  return run(async () => {
    const { sb } = await assertPermission('tours.manage');
    check(await sb.from('tours').update({ draft_data: null }).eq('id', id).select('id').single());
    revalidatePath(`/admin/passeios/${id}`);
    return { ok: true, message: 'Rascunho descartado.' };
  });
}

export async function setTourStatus(id: string, status: TourStatus): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('tours.manage');
    if (!(status in TOUR_STATUS)) throw new ActionError('Status inválido.');
    const before = check(await sb.from('tours').select('name, slug, status').eq('id', id).single()) as { name: string; slug: string; status: TourStatus };
    check(await sb.from('tours').update({ status, updated_by: staff.id }).eq('id', id).select('id').single());
    await logAudit(sb, staff, {
      action: 'status', entity: 'tours', entityId: id,
      summary: `alterou o status do passeio ${before.name} de ${TOUR_STATUS[before.status].label} para ${TOUR_STATUS[status].label}`,
      changes: { status: { de: before.status, para: status } },
    });
    revalidateSite(['/passeios', `/passeios/${before.slug}`]);
    revalidatePath('/admin/passeios');
    return { ok: true, message: `Status alterado para ${TOUR_STATUS[status].label}. O site já mostra a mudança.` };
  });
}

export async function setTourPublication(id: string, publication: 'publicado' | 'rascunho' | 'arquivado'): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('tours.manage');
    const t = check(await sb.from('tours').update({ publication, ...(publication === 'publicado' ? { published_at: new Date().toISOString() } : {}) })
      .eq('id', id).select('name, slug').single()) as { name: string; slug: string };
    const verb = { publicado: 'publicou', rascunho: 'despublicou', arquivado: 'arquivou' }[publication];
    await logAudit(sb, staff, { action: 'publish', entity: 'tours', entityId: id, summary: `${verb} o passeio "${t.name}"` });
    revalidateSite(['/passeios', `/passeios/${t.slug}`]);
    revalidatePath('/admin/passeios');
    return { ok: true, message: { publicado: 'Passeio publicado.', rascunho: 'Passeio retirado do site.', arquivado: 'Passeio arquivado.' }[publication] };
  });
}

export async function toggleTourFeatured(id: string, featured: boolean): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('tours.manage');
    const t = check(await sb.from('tours').update({ featured }).eq('id', id).select('name').single()) as { name: string };
    await logAudit(sb, staff, { action: 'update', entity: 'tours', entityId: id, summary: `${featured ? 'destacou' : 'removeu o destaque de'} "${t.name}"` });
    revalidateSite();
    return { ok: true, message: featured ? 'Passeio destacado.' : 'Destaque removido.' };
  });
}

export async function duplicateTour(id: string): Promise<ActionResult<{ id: string }>> {
  return run(async () => {
    const { staff, sb } = await assertPermission('tours.manage');
    const src = check(await sb.from('tours').select('*').eq('id', id).single()) as Record<string, unknown>;
    const { id: _id, created_at, updated_at, published_at, draft_data, ...rest } = src;
    const copy = { ...rest, name: `${src.name} (cópia)`, slug: `${src.slug}-copia-${Date.now().toString(36)}`, publication: 'rascunho', featured: false, created_by: staff.id, updated_by: staff.id };
    const row = check(await sb.from('tours').insert(copy).select('id').single()) as { id: string };
    await logAudit(sb, staff, { action: 'create', entity: 'tours', entityId: row.id, summary: `duplicou o passeio "${src.name}"` });
    revalidatePath('/admin/passeios');
    return { ok: true, data: { id: row.id }, message: 'Cópia criada como rascunho.' };
  });
}

export async function deleteTour(id: string): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('tours.manage');
    const t = check(await sb.from('tours').delete().eq('id', id).select('name').single()) as { name: string };
    await logAudit(sb, staff, { action: 'delete', entity: 'tours', entityId: id, summary: `excluiu o passeio "${t.name}"` });
    revalidateSite(['/passeios']);
    revalidatePath('/admin/passeios');
    return { ok: true, message: 'Passeio excluído.' };
  });
}

// ─── Horários e vagas ────────────────────────────────────────────────
const scheduleSchema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida'),
  start_time: z.preprocess((v) => (v === '' ? null : v), z.string().regex(/^\d{2}:\d{2}$/).nullable()),
  capacity: z.coerce.number().int().min(0, 'Capacidade inválida').max(1000),
  manual_occupied: z.coerce.number().int().min(0).max(1000),
  status: z.enum(['aberto', 'fechado', 'cancelado', 'realizado']),
  notes: z.preprocess((v) => (v === '' ? null : v), z.string().max(300).nullable()),
}).refine((v) => v.manual_occupied <= v.capacity, { message: 'Ocupadas não pode ser maior que a capacidade', path: ['manual_occupied'] });

async function afterScheduleChange(sb: Awaited<ReturnType<typeof assertPermission>>['sb'], tourId: string) {
  const t = await sb.from('tours').select('slug').eq('id', tourId).single();
  revalidateSite(t.data ? [`/passeios/${t.data.slug}`] : []);
  revalidatePath(`/admin/passeios/${tourId}`);
  revalidatePath('/admin/calendario');
}

export async function saveSchedule(tourId: string, scheduleId: string | null, input: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('tours.manage');
    const data = scheduleSchema.parse(input);
    if (scheduleId) {
      const { data: avail } = await sb.from('schedule_availability').select('booked').eq('id', scheduleId).single();
      if (avail && data.capacity < avail.booked + data.manual_occupied) {
        throw new ActionError(`Já existem ${avail.booked} vagas reservadas. A capacidade não pode ser menor que ${avail.booked + data.manual_occupied}.`);
      }
      check(await sb.from('tour_schedules').update(data).eq('id', scheduleId).eq('tour_id', tourId).select('id').single());
    } else {
      check(await sb.from('tour_schedules').insert({ ...data, tour_id: tourId }).select('id').single());
    }
    await logAudit(sb, staff, { action: scheduleId ? 'update' : 'create', entity: 'tour_schedules', entityId: scheduleId, summary: `${scheduleId ? 'editou' : 'criou'} o horário de ${data.date.split('-').reverse().join('/')} ${data.start_time ?? ''} (capacidade ${data.capacity})` });
    await afterScheduleChange(sb, tourId);
    return { ok: true, message: 'Horário salvo.' };
  });
}

const bulkSchema = z.object({
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  weekdays: z.array(z.number().int().min(0).max(6)).min(1, 'Escolha os dias da semana'),
  times: z.array(z.string().regex(/^\d{2}:\d{2}$/)).min(1, 'Informe ao menos um horário'),
  capacity: z.coerce.number().int().min(1).max(1000),
}).refine((v) => v.to >= v.from, { message: 'A data final deve ser depois da inicial', path: ['to'] });

export async function bulkCreateSchedules(tourId: string, input: Record<string, unknown>): Promise<ActionResult<{ created: number }>> {
  return run(async () => {
    const { staff, sb } = await assertPermission('tours.manage');
    const v = bulkSchema.parse(input);
    const rows: Record<string, unknown>[] = [];
    const d = new Date(`${v.from}T12:00:00`);
    const end = new Date(`${v.to}T12:00:00`);
    while (d <= end && rows.length < 800) {
      if (v.weekdays.includes(d.getDay())) {
        const iso = d.toISOString().slice(0, 10);
        v.times.forEach((t) => rows.push({ tour_id: tourId, date: iso, start_time: t, capacity: v.capacity }));
      }
      d.setDate(d.getDate() + 1);
    }
    if (!rows.length) throw new ActionError('Nenhuma data corresponde aos dias escolhidos.');
    const { data: existing } = await sb.from('tour_schedules').select('date, start_time').eq('tour_id', tourId).gte('date', v.from).lte('date', v.to);
    const taken = new Set((existing ?? []).map((e) => `${e.date}|${(e.start_time ?? '').slice(0, 5)}`));
    const fresh = rows.filter((r) => !taken.has(`${r.date}|${r.start_time}`));
    if (fresh.length) check(await sb.from('tour_schedules').insert(fresh).select('id'));
    await logAudit(sb, staff, { action: 'create', entity: 'tour_schedules', summary: `criou ${fresh.length} horários em lote (${v.from} a ${v.to})` });
    await afterScheduleChange(sb, tourId);
    return { ok: true, data: { created: fresh.length }, message: `${fresh.length} horários criados${rows.length - fresh.length ? ` (${rows.length - fresh.length} já existiam)` : ''}.` };
  });
}

export async function deleteSchedule(tourId: string, scheduleId: string): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('tours.manage');
    const { count } = await sb.from('bookings').select('id', { count: 'exact', head: true }).eq('schedule_id', scheduleId).neq('status', 'cancelada');
    if (count) throw new ActionError(`Este horário tem ${count} reserva(s). Cancele o horário em vez de excluir.`);
    check(await sb.from('tour_schedules').delete().eq('id', scheduleId).eq('tour_id', tourId).select('id'));
    await logAudit(sb, staff, { action: 'delete', entity: 'tour_schedules', entityId: scheduleId, summary: 'excluiu um horário de passeio' });
    await afterScheduleChange(sb, tourId);
    return { ok: true, message: 'Horário excluído.' };
  });
}
