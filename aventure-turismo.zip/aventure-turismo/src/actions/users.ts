'use server';
import { z } from 'zod';
import { headers } from 'next/headers';
import { revalidatePath } from 'next/cache';
import { assertPermission, ActionError } from '@/lib/auth';
import { check, run, type ActionResult } from '@/lib/action';
import { logAudit } from '@/lib/audit';
import { createAdminClient } from '@/lib/supabase/admin';
import { SITE_URL } from '@/lib/supabase/env';
import { ROLE_LABEL } from '@/lib/permissions';

const roleEnum = z.enum(['admin', 'gerente', 'atendente']);

export async function inviteUser(input: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('users.manage');
    const v = z.object({ email: z.string().trim().toLowerCase().email('E-mail inválido'), full_name: z.string().trim().min(2, 'Informe o nome').max(120), role: roleEnum }).parse(input);
    const admin = createAdminClient();
    const origin = (await headers()).get('origin') ?? SITE_URL;
    const { data, error } = await admin.auth.admin.inviteUserByEmail(v.email, {
      data: { full_name: v.full_name },
      redirectTo: `${origin}/auth/callback?next=/admin/redefinir-senha`,
    });
    if (error) throw new ActionError(/already/i.test(error.message) ? 'Este e-mail já tem cadastro. Ative o usuário na lista.' : error.message);
    const { error: upErr } = await admin.from('profiles').upsert({ id: data.user.id, email: v.email, full_name: v.full_name, role: v.role, active: true });
    if (upErr) throw new ActionError(upErr.message);
    await logAudit(sb, staff, { action: 'create', entity: 'profiles', entityId: data.user.id, summary: `convidou ${v.full_name} como ${ROLE_LABEL[v.role]}` });
    revalidatePath('/admin/usuarios');
    return { ok: true, message: `Convite enviado para ${v.email}.` };
  });
}

export async function updateUser(id: string, input: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('users.manage');
    const v = z.object({ full_name: z.string().trim().min(2).max(120), role: roleEnum, active: z.boolean() }).parse(input);
    if (id === staff.id && (v.role !== 'admin' || !v.active)) throw new ActionError('Você não pode remover o seu próprio acesso de administrador.');
    if (v.role !== 'admin' || !v.active) {
      const { count } = await sb.from('profiles').select('id', { count: 'exact', head: true }).eq('role', 'admin').eq('active', true).neq('id', id);
      if (!count) throw new ActionError('É preciso manter pelo menos um administrador ativo.');
    }
    const before = check(await sb.from('profiles').select('full_name, role, active').eq('id', id).single()) as { full_name: string; role: string; active: boolean };
    check(await sb.from('profiles').update(v).eq('id', id).select('id').single());
    if (!v.active && before.active) {
      try { await createAdminClient().auth.admin.signOut(id); } catch { /* sessão já expirada */ }
    }
    const parts = [];
    if (before.role !== v.role) parts.push(`papel de ${ROLE_LABEL[before.role]} para ${ROLE_LABEL[v.role]}`);
    if (before.active !== v.active) parts.push(v.active ? 'reativou o acesso' : 'desativou o acesso');
    await logAudit(sb, staff, { action: 'update', entity: 'profiles', entityId: id, summary: `alterou o usuário ${v.full_name}${parts.length ? ` (${parts.join(', ')})` : ''}` });
    revalidatePath('/admin/usuarios');
    return { ok: true, message: 'Usuário atualizado.' };
  });
}

export async function updateRolePermissions(role: string, permissions: string[]): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('users.manage');
    const r = roleEnum.parse(role);
    if (r === 'admin') throw new ActionError('O administrador sempre tem acesso total.');
    check(await sb.from('role_permissions').delete().eq('role', r).select('role'));
    if (permissions.length) check(await sb.from('role_permissions').insert(permissions.map((p) => ({ role: r, permission: p }))).select('role'));
    await logAudit(sb, staff, { action: 'update', entity: 'role_permissions', entityId: r, summary: `alterou as permissões do perfil ${ROLE_LABEL[r]}`, changes: { permissions } });
    revalidatePath('/admin/usuarios');
    return { ok: true, message: 'Permissões atualizadas.' };
  });
}

export async function updateMyProfile(input: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('dashboard.view');
    const v = z.object({ full_name: z.string().trim().min(2, 'Informe seu nome').max(120) }).parse(input);
    check(await sb.from('profiles').update(v).eq('id', staff.id).select('id').single());
    revalidatePath('/admin', 'layout');
    return { ok: true, message: 'Perfil atualizado.' };
  });
}
