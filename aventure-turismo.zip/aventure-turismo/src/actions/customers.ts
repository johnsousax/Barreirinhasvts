'use server';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { assertPermission } from '@/lib/auth';
import { check, run, type ActionResult } from '@/lib/action';
import { logAudit } from '@/lib/audit';

const opt = (max: number) => z.preprocess((v) => (typeof v === 'string' && v.trim() === '' ? null : v), z.string().trim().max(max).nullable());

const customerSchema = z.object({
  name: z.string().trim().min(2, 'Informe o nome').max(120),
  phone: opt(30), whatsapp: opt(30),
  email: z.preprocess((v) => (v === '' ? null : v), z.string().email('E-mail inválido').nullable()),
  city: opt(80), state: opt(2), notes: opt(3000),
  source: z.string().trim().min(1).max(40),
});

export async function saveCustomer(id: string | null, input: Record<string, unknown>): Promise<ActionResult<{ id: string }>> {
  return run(async () => {
    const { staff, sb } = await assertPermission('customers.manage');
    const v = customerSchema.parse(input);
    if (v.state) v.state = v.state.toUpperCase();
    if (id) {
      check(await sb.from('customers').update(v).eq('id', id).select('id').single());
      await logAudit(sb, staff, { action: 'update', entity: 'customers', entityId: id, summary: `editou o cliente ${v.name}` });
    } else {
      id = (check(await sb.from('customers').insert(v).select('id').single()) as { id: string }).id;
      await logAudit(sb, staff, { action: 'create', entity: 'customers', entityId: id, summary: `cadastrou o cliente ${v.name}` });
    }
    revalidatePath('/admin/clientes');
    revalidatePath(`/admin/clientes/${id}`);
    return { ok: true, data: { id: id! }, message: 'Cliente salvo.' };
  });
}

export async function addInteraction(customerId: string, input: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('customers.manage');
    const v = z.object({
      channel: z.enum(['whatsapp', 'ligacao', 'email', 'presencial', 'instagram', 'nota']),
      description: z.string().trim().min(2, 'Descreva o contato').max(2000),
    }).parse(input);
    check(await sb.from('customer_interactions').insert({ ...v, customer_id: customerId, created_by: staff.id }).select('id'));
    revalidatePath(`/admin/clientes/${customerId}`);
    return { ok: true, message: 'Contato registrado.' };
  });
}

export async function deleteCustomer(id: string): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('customers.manage');
    const c = check(await sb.from('customers').delete().eq('id', id).select('name').single()) as { name: string };
    await logAudit(sb, staff, { action: 'delete', entity: 'customers', entityId: id, summary: `excluiu o cliente ${c.name}` });
    revalidatePath('/admin/clientes');
    return { ok: true, message: 'Cliente excluído.' };
  });
}
