'use server';
import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { assertPermission, getCurrentStaff, ActionError } from '@/lib/auth';
import { check, run, type ActionResult } from '@/lib/action';
import { logAudit } from '@/lib/audit';
import { createClient } from '@/lib/supabase/server';

export interface MediaItem { id: string; url: string; path: string | null; kind: string; category: string; alt: string | null; width: number | null; height: number | null; size_bytes: number | null; created_at: string }

async function assertMediaAccess() {
  const staff = await getCurrentStaff();
  if (!staff) throw new ActionError('Sessão expirada.');
  if (!staff.permissions.includes('content.manage') && !staff.permissions.includes('tours.manage')) throw new ActionError('Sem permissão para mídia.');
  return { staff, sb: await createClient() };
}

export async function listMedia(category?: string): Promise<MediaItem[]> {
  const { sb } = await assertMediaAccess();
  let q = sb.from('media').select('*').order('created_at', { ascending: false }).limit(300);
  if (category) q = q.eq('category', category);
  const { data } = await q;
  return (data ?? []) as MediaItem[];
}

/** Registra um arquivo já enviado ao bucket "media" pelo navegador (upload direto com RLS). */
export async function registerMedia(input: Record<string, unknown>): Promise<ActionResult<MediaItem>> {
  return run(async () => {
    const { staff, sb } = await assertMediaAccess();
    const v = z.object({
      url: z.string().url(), path: z.string().min(3).max(300),
      kind: z.enum(['image', 'video']), category: z.string().trim().min(1).max(40), alt: z.string().max(200).nullable().optional(),
      width: z.number().int().nullable().optional(), height: z.number().int().nullable().optional(), size_bytes: z.number().int().nullable().optional(),
    }).parse(input);
    const row = check(await sb.from('media').insert({ ...v, created_by: staff.id }).select('*').single()) as MediaItem;
    await logAudit(sb, staff, { action: 'create', entity: 'media', entityId: row.id, summary: `enviou o arquivo ${v.path.split('/').pop()}` });
    revalidatePath('/admin/midia');
    return { ok: true, data: row };
  });
}

export async function updateMedia(id: string, input: Record<string, unknown>): Promise<ActionResult> {
  return run(async () => {
    const { sb } = await assertMediaAccess();
    const v = z.object({ category: z.string().trim().min(1).max(40), alt: z.string().trim().max(200).nullable() }).parse(input);
    check(await sb.from('media').update(v).eq('id', id).select('id').single());
    revalidatePath('/admin/midia');
    return { ok: true, message: 'Arquivo atualizado.' };
  });
}

export async function deleteMedia(id: string): Promise<ActionResult> {
  return run(async () => {
    const { staff, sb } = await assertPermission('content.manage');
    const m = check(await sb.from('media').select('path, url').eq('id', id).single()) as { path: string | null; url: string };
    if (m.path) {
      const { error } = await sb.storage.from('media').remove([m.path]);
      if (error) throw new ActionError(error.message);
    }
    check(await sb.from('media').delete().eq('id', id).select('id'));
    await logAudit(sb, staff, { action: 'delete', entity: 'media', entityId: id, summary: `excluiu o arquivo ${(m.path ?? m.url).split('/').pop()}` });
    revalidatePath('/admin/midia');
    return { ok: true, message: 'Arquivo excluído. Verifique se ele não era usado em alguma página.' };
  });
}
