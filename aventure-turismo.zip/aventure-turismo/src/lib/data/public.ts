import { cache } from 'react';
import { createPublicClient } from '../supabase/public';
import { isSupabaseConfigured } from '../supabase/env';
import { mergeSettings, type SiteSettings } from '../settings';
import { withDefaults } from '../cms-schema';
import { effectiveStatus } from '../tour-status';
import type { Availability, Banner, Category, Destination, Faq, GalleryItem, Review, ScheduleSlot, Tour, TourStatus } from '../types';

/*
 * Camada de dados do site público. Tudo vem do banco. Se o Supabase não
 * estiver configurado ou falhar, devolve valores vazios/padrão para que a
 * página renderize um estado vazio em vez de quebrar.
 */

async function safe<T>(fallback: T, fn: () => PromiseLike<{ data: T | null; error: unknown }>): Promise<T> {
  if (!isSupabaseConfigured) return fallback;
  try {
    const { data, error } = await fn();
    if (error) { console.error('[site-data]', error); return fallback; }
    return data ?? fallback;
  } catch (e) {
    console.error('[site-data]', e);
    return fallback;
  }
}

export const getSettings = cache(async (): Promise<SiteSettings> => {
  const row = await safe<{ data: Partial<SiteSettings> } | null>(null, () =>
    createPublicClient().from('site_settings').select('data').eq('id', 1).maybeSingle());
  return mergeSettings(row?.data);
});

export const getSections = cache(async () => {
  const rows = await safe<{ key: string; content: Record<string, unknown> }[]>([], () =>
    createPublicClient().rpc('get_published_sections'));
  const map = Object.fromEntries(rows.map((r) => [r.key, r.content]));
  return <T = Record<string, any>>(key: string) => withDefaults<T>(key, map[key]);
});

const TOUR_FIELDS = '*, category:tour_categories(name, slug), destination:destinations(name, slug)';

export type PublicTour = Tour & { availability: Availability | null; display_status: TourStatus };

const getAvailabilityMap = cache(async () => {
  const rows = await safe<Availability[]>([], () => createPublicClient().rpc('get_tours_availability'));
  return new Map(rows.map((r) => [r.tour_id, r]));
});

export interface TourFilters { categoria?: string; destino?: string; tipo?: string; duracao?: string; preco?: string; disponibilidade?: string; q?: string }

export const getTours = cache(async (filters: TourFilters = {}): Promise<PublicTour[]> => {
  const [settings, availability] = await Promise.all([getSettings(), getAvailabilityMap()]);
  const rows = await safe<Tour[]>([], () =>
    createPublicClient().from('tours').select(TOUR_FIELDS).eq('publication', 'publicado')
      .order('featured', { ascending: false }).order('sort_order').order('name'));

  let list = rows.map((t) => {
    const avail = availability.get(t.id) ?? null;
    return { ...t, availability: avail, display_status: effectiveStatus(t.status, avail, settings.low_seats_threshold) };
  });
  if (!settings.show_closed_tours) list = list.filter((t) => t.display_status !== 'encerrado');

  const f = filters;
  if (f.categoria) list = list.filter((t) => t.category?.slug === f.categoria);
  if (f.destino) list = list.filter((t) => t.destination?.slug === f.destino);
  if (f.tipo) list = list.filter((t) => t.tour_type === f.tipo || t.tour_type === 'ambos');
  if (f.q) {
    const q = f.q.toLowerCase();
    list = list.filter((t) => `${t.name} ${t.short_description ?? ''} ${t.destination?.name ?? ''}`.toLowerCase().includes(q));
  }
  if (f.duracao) {
    const [min, max] = f.duracao.split('-').map(Number);
    list = list.filter((t) => t.duration_minutes != null && t.duration_minutes >= min && (!max || t.duration_minutes <= max));
  }
  if (f.preco) {
    const [min, max] = f.preco.split('-').map(Number);
    list = list.filter((t) => {
      const p = t.promo_price ?? t.price;
      return p != null && p >= min && (!max || p <= max);
    });
  }
  if (f.disponibilidade === 'com-vagas') list = list.filter((t) => ['disponivel', 'poucas_vagas', 'ultimas_vagas'].includes(t.display_status));
  return list;
});

export const getTourBySlug = cache(async (slug: string) => {
  const tours = await getTours();
  const tour = tours.find((t) => t.slug === slug);
  if (!tour) return null;
  const slots = await safe<ScheduleSlot[]>([], () => createPublicClient().rpc('get_tour_availability', { p_tour_id: tour.id }));
  return { tour, slots };
});

export const getCategories = cache(() =>
  safe<Category[]>([], () => createPublicClient().from('tour_categories').select('*').eq('active', true).order('sort_order')));

export const getDestinations = cache(() =>
  safe<Destination[]>([], () => createPublicClient().from('destinations').select('*').eq('status', 'publicado').order('sort_order')));

export const getDestinationBySlug = cache(async (slug: string) => {
  const list = await getDestinations();
  return list.find((d) => d.slug === slug) ?? null;
});

export const getReviews = cache((featuredOnly = false) =>
  safe<Review[]>([], () => {
    let q = createPublicClient().from('reviews').select('*, tour:tours(name)').eq('visible', true);
    if (featuredOnly) q = q.eq('featured', true);
    return q.order('featured', { ascending: false }).order('sort_order').order('review_date', { ascending: false }).limit(featuredOnly ? 6 : 100);
  }));

export const getGallery = cache(() =>
  safe<GalleryItem[]>([], () => createPublicClient().from('gallery').select('id, image_url, title, category, featured').eq('visible', true)
    .order('featured', { ascending: false }).order('sort_order')));

export const getFaqs = cache(() =>
  safe<Faq[]>([], () => createPublicClient().from('faqs').select('id, question, answer').eq('visible', true).order('sort_order')));

export const getBanners = cache((placement: string) =>
  safe<Banner[]>([], () => {
    const now = new Date().toISOString();
    return createPublicClient().from('banners').select('id, title, subtitle, image_url, button_label, button_url, placement')
      .eq('active', true).eq('placement', placement)
      .or(`starts_at.is.null,starts_at.lte.${now}`).or(`ends_at.is.null,ends_at.gt.${now}`)
      .order('sort_order').limit(3);
  }));
