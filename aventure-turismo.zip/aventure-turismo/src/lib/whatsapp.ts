export function waDigits(n: string | null | undefined) {
  const d = (n ?? '').replace(/\D/g, '');
  if (!d) return '';
  return d.length <= 11 ? `55${d}` : d;
}

export function fillTemplate(tpl: string, vars: Record<string, string | number | undefined | null>) {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? '')).replace(/\s{2,}/g, ' ').trim();
}

/** Link wa.me com mensagem pré-preenchida (funciona sem API oficial). */
export function whatsappUrl(number: string | null | undefined, message?: string) {
  const d = waDigits(number);
  if (!d) return '';
  return `https://wa.me/${d}${message ? `?text=${encodeURIComponent(message)}` : ''}`;
}
