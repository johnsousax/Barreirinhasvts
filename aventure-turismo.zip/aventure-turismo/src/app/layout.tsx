import type { Metadata, Viewport } from 'next';
import { getSettings } from '@/lib/data/public';
import { SITE_URL } from '@/lib/supabase/env';
import './globals.css';

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  return {
    metadataBase: new URL(SITE_URL),
    title: { default: s.seo_title || s.company_name, template: `%s | ${s.company_name}` },
    description: s.seo_description,
    applicationName: s.company_name,
    icons: { icon: s.favicon_url || '/brand/icon.png', apple: s.favicon_url || '/brand/icon.png' },
    openGraph: {
      type: 'website', locale: 'pt_BR', siteName: s.company_name,
      title: s.seo_title, description: s.seo_description,
      images: s.og_image ? [{ url: s.og_image, width: 1200, height: 630 }] : undefined,
    },
    twitter: { card: 'summary_large_image', title: s.seo_title, description: s.seo_description },
    alternates: { canonical: '/' },
    formatDetection: { telephone: false },
  };
}

export const viewport: Viewport = { themeColor: '#0E3A6E', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wdth,wght@12..96,75..100,500..800&family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet" />
      </head>
      <body>{children}</body>
    </html>
  );
}
