import { PageHeader } from '@/components/admin/Shell';
import { UsersManager } from '@/components/admin/UsersManager';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { isServiceRoleConfigured } from '@/lib/supabase/env';

export const metadata = { title: 'Usuários' };

export default async function UsersPage() {
  const staff = await requirePermission('users.manage');
  const sb = await createClient();
  const [{ data: users }, { data: perms }] = await Promise.all([
    sb.from('profiles').select('id, full_name, email, role, active, last_seen_at').order('active', { ascending: false }).order('full_name'),
    sb.from('role_permissions').select('role, permission'),
  ]);
  const rolePerms: Record<string, string[]> = {};
  (perms ?? []).forEach((p) => { (rolePerms[p.role] ??= []).push(p.permission); });
  return (
    <>
      <PageHeader title="Usuários e permissões" />
      {!isServiceRoleConfigured && <p className="mb-4 rounded-2xl bg-sol-50 px-4 py-3 text-sm text-sol-700">Para enviar convites por e-mail, configure SUPABASE_SERVICE_ROLE_KEY no servidor. Sem ela, peça que a pessoa se cadastre e depois libere o acesso aqui.</p>}
      <UsersManager users={users ?? []} rolePerms={rolePerms} meId={staff.id} canInvite={isServiceRoleConfigured} />
    </>
  );
}
