import Link from 'next/link';
import { PageHeader } from '@/components/admin/Shell';
import { NewBookingButton } from '@/components/admin/Bookings';
import { Pagination, UrlFilters } from '@/components/admin/UrlFilters';
import { ExportCsv } from '@/components/admin/ExportCsv';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { EmptyState } from '@/components/ui/States';
import { Table, Td, Th } from '@/components/ui/Table';
import { WhatsAppIcon } from '@/components/ui/icons';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { BOOKING_STATUS } from '@/lib/tour-status';
import { SOURCES, sourceLabel } from '@/lib/constants';
import { brl, fmtDate, fmtTime, formatPhone } from '@/lib/format';
import { whatsappUrl } from '@/lib/whatsapp';
import type { Booking } from '@/lib/types';

export const metadata = { title: 'Reservas' };
const PER_PAGE = 30;

export default async function BookingsPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  await requirePermission('bookings.manage');
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page) || 1);
  const sb = await createClient();

  let q = sb.from('bookings').select('*, customer:customers!inner(id, name, phone, whatsapp, email), tour:tours(id, name, slug)', { count: 'exact' })
    .order('date', { ascending: false }).order('start_time', { ascending: false });
  if (sp.status) q = q.eq('status', sp.status);
  if (sp.passeio) q = q.eq('tour_id', sp.passeio);
  if (sp.origem) q = q.eq('source', sp.origem);
  if (sp.horario) q = q.eq('schedule_id', sp.horario);
  if (sp.de) q = q.gte('date', sp.de);
  if (sp.ate) q = q.lte('date', sp.ate);
  if (sp.q) {
    const term = sp.q.replace(/[%,()]/g, '').trim();
    q = /^avt-/i.test(term) ? q.ilike('code', `%${term}%`) : q.or(`name.ilike.%${term}%,phone.ilike.%${term}%,email.ilike.%${term}%`, { referencedTable: 'customers' });
  }
  const [{ data, count }, { data: tours }] = await Promise.all([
    q.range((page - 1) * PER_PAGE, page * PER_PAGE - 1),
    sb.from('tours').select('id, name, price, promo_price').neq('publication', 'arquivado').order('name'),
  ]);
  const bookings = (data ?? []) as Booking[];
  const tourOpts = (tours ?? []).map((t) => ({ value: t.id, label: t.name, price: t.promo_price ?? t.price }));
  const csv = bookings.map((b) => ({
    codigo: b.code, cliente: b.customer?.name, telefone: b.customer?.phone ?? b.customer?.whatsapp, passeio: b.tour?.name,
    data: b.date, horario: fmtTime(b.start_time), pessoas: b.people, valor: b.total_amount ?? '', status: BOOKING_STATUS[b.status].label, origem: sourceLabel(b.source),
  }));

  return (
    <>
      <PageHeader title="Reservas" description="Solicitações do site e reservas registradas pela equipe."
        actions={<><ExportCsv rows={csv} filename="reservas" /><NewBookingButton tours={tourOpts} /></>} />
      <Card>
        <UrlFilters filters={[
          { name: 'q', type: 'search', placeholder: 'Cliente, telefone, e-mail ou código AVT-…' },
          { name: 'status', type: 'select', label: 'Status', options: Object.entries(BOOKING_STATUS).map(([k, m]) => ({ value: k, label: m.label })) },
          { name: 'passeio', type: 'select', label: 'Passeio', options: tourOpts },
          { name: 'origem', type: 'select', label: 'Origem', options: SOURCES },
          { name: 'de', type: 'date', label: 'De' },
          { name: 'ate', type: 'date', label: 'Até' },
        ]} />
        {bookings.length === 0 ? <EmptyState title="Nenhuma reserva encontrada." description="Ajuste os filtros ou registre uma nova reserva." /> : (
          <Table>
            <thead><tr><Th>Código</Th><Th>Cliente</Th><Th className="hidden lg:table-cell">Passeio</Th><Th>Data</Th><Th className="hidden md:table-cell">Pessoas</Th><Th className="hidden xl:table-cell">Valor</Th><Th>Status</Th><Th className="hidden xl:table-cell">Origem</Th><Th /></tr></thead>
            <tbody>
              {bookings.map((b) => {
                const phone = b.customer?.whatsapp || b.customer?.phone;
                return (
                  <tr key={b.id} className="hover:bg-slate-50/70">
                    <Td><Link href={`/admin/reservas/${b.id}`} className="whitespace-nowrap font-semibold text-lagoa-700 hover:underline">{b.code}</Link></Td>
                    <Td><span className="block font-medium">{b.customer?.name}</span><span className="text-xs text-ink-muted">{formatPhone(phone)}</span></Td>
                    <Td className="hidden lg:table-cell">{b.tour?.name}</Td>
                    <Td className="whitespace-nowrap">{fmtDate(b.date)}<span className="block text-xs text-ink-muted">{fmtTime(b.start_time)}</span></Td>
                    <Td className="hidden md:table-cell">{b.people}</Td>
                    <Td className="hidden whitespace-nowrap xl:table-cell">{b.total_amount != null ? brl(b.total_amount) : '—'}</Td>
                    <Td><Badge tone={BOOKING_STATUS[b.status].tone}>{BOOKING_STATUS[b.status].label}</Badge></Td>
                    <Td className="hidden xl:table-cell">{sourceLabel(b.source)}</Td>
                    <Td>{phone && <a href={whatsappUrl(phone, `Olá, ${b.customer?.name?.split(' ')[0]}! Aqui é da Aventure Turismo sobre a sua reserva ${b.code} (${b.tour?.name}, ${fmtDate(b.date)}).`)} target="_blank" rel="noopener noreferrer" className="grid size-8 place-items-center rounded-full text-[#1FAF55] hover:bg-emerald-50" aria-label="Abrir WhatsApp"><WhatsAppIcon className="size-4" /></a>}</Td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        )}
        <Pagination page={page} total={count ?? 0} perPage={PER_PAGE} />
      </Card>
    </>
  );
}
