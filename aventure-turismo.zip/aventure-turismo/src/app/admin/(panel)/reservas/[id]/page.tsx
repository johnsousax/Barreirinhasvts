import Link from 'next/link';
import { notFound } from 'next/navigation';
import { PageHeader } from '@/components/admin/Shell';
import { BookingStatusControl, EditBookingButton, PassengersPanel, PaymentsPanel } from '@/components/admin/Bookings';
import { Badge } from '@/components/ui/Badge';
import { ButtonLink } from '@/components/ui/Button';
import { Card, CardHeader } from '@/components/ui/Card';
import { WhatsAppIcon } from '@/components/ui/icons';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { BOOKING_STATUS } from '@/lib/tour-status';
import { sourceLabel } from '@/lib/constants';
import { brl, capFirst, fmtDateLong, fmtDateTime, fmtTime, formatPhone } from '@/lib/format';
import { whatsappUrl } from '@/lib/whatsapp';
import type { Booking, BookingStatus } from '@/lib/types';

export const metadata = { title: 'Reserva' };

export default async function BookingDetail({ params }: { params: Promise<{ id: string }> }) {
  await requirePermission('bookings.manage');
  const { id } = await params;
  const sb = await createClient();
  const [{ data }, { data: payments }, { data: passengers }, { data: history }, { data: tours }] = await Promise.all([
    sb.from('bookings').select('*, customer:customers(id, name, phone, whatsapp, email), tour:tours(id, name, slug, meeting_point)').eq('id', id).maybeSingle(),
    sb.from('payments').select('*').eq('booking_id', id).order('paid_at'),
    sb.from('booking_passengers').select('*').eq('booking_id', id).order('created_at'),
    sb.from('booking_history').select('id, from_status, to_status, note, created_at, author:profiles(full_name)').eq('booking_id', id).order('created_at', { ascending: false }),
    sb.from('tours').select('id, name, price, promo_price').order('name'),
  ]);
  if (!data) notFound();
  const b = data as Booking & { tour: { id: string; name: string; slug: string; meeting_point: string | null } };
  const phone = b.customer?.whatsapp || b.customer?.phone;
  const first = b.customer?.name?.split(' ')[0] ?? '';
  const templates = [
    { label: 'Confirmar reserva', text: `Olá, ${first}! Sua reserva ${b.code} do passeio ${b.tour?.name} está confirmada para ${fmtDateLong(b.date)}${b.start_time ? ` às ${fmtTime(b.start_time)}` : ''}, para ${b.people} pessoa(s).${b.tour?.meeting_point ? ` Ponto de encontro: ${b.tour.meeting_point}.` : ''} Qualquer dúvida, é só chamar!` },
    { label: 'Lembrete do passeio', text: `Oi, ${first}! Passando para lembrar do seu passeio ${b.tour?.name} em ${fmtDateLong(b.date)}${b.start_time ? ` às ${fmtTime(b.start_time)}` : ''}. Leve protetor solar, água e roupa de banho. Até lá!` },
    { label: 'Solicitar pagamento', text: `Olá, ${first}! Para garantir a reserva ${b.code}${b.total_amount != null ? ` (${brl(b.total_amount)})` : ''}, pode nos enviar o comprovante do pagamento por aqui?` },
    { label: 'Pedir avaliação', text: `Oi, ${first}! Obrigado por viver os Lençóis com a Aventure. Pode nos contar como foi a experiência? Sua avaliação ajuda muito!` },
  ];
  const history_ = (history ?? []) as unknown as { id: string; from_status: BookingStatus | null; to_status: BookingStatus; note: string | null; created_at: string; author: { full_name: string } | null }[];

  return (
    <>
      <PageHeader title={<span className="flex flex-wrap items-center gap-3">Reserva {b.code}<Badge tone={BOOKING_STATUS[b.status].tone}>{BOOKING_STATUS[b.status].label}</Badge></span>}
        back={{ href: '/admin/reservas', label: 'Reservas' }}
        actions={<EditBookingButton booking={b} tours={(tours ?? []).map((t) => ({ value: t.id, label: t.name, price: t.promo_price ?? t.price }))} />} />
      <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <Card className="p-5">
            <h2 className="text-sm font-semibold text-ink-muted">Alterar status</h2>
            <div className="mt-3"><BookingStatusControl id={b.id} status={b.status} /></div>
          </Card>
          <Card>
            <CardHeader title="Detalhes" />
            <dl className="grid gap-x-6 gap-y-4 p-5 text-sm sm:grid-cols-3">
              <div><dt className="text-ink-muted">Passeio</dt><dd className="font-medium"><Link href={`/admin/passeios/${b.tour?.id}`} className="hover:text-lagoa-600">{b.tour?.name}</Link></dd></div>
              <div><dt className="text-ink-muted">Data</dt><dd className="font-medium">{capFirst(fmtDateLong(b.date))} {fmtTime(b.start_time)}</dd></div>
              <div><dt className="text-ink-muted">Pessoas</dt><dd className="font-medium">{b.people}</dd></div>
              <div><dt className="text-ink-muted">Valor por pessoa</dt><dd className="font-medium">{b.unit_price != null ? brl(b.unit_price) : '—'}</dd></div>
              <div><dt className="text-ink-muted">Total</dt><dd className="font-medium">{b.total_amount != null ? brl(b.total_amount) : '—'}</dd></div>
              <div><dt className="text-ink-muted">Origem</dt><dd className="font-medium">{sourceLabel(b.source)}</dd></div>
              <div><dt className="text-ink-muted">Vínculo com horário</dt><dd className="font-medium">{b.schedule_id ? 'Sim (ocupa vagas)' : 'Data livre'}</dd></div>
              <div><dt className="text-ink-muted">Criada em</dt><dd className="font-medium">{fmtDateTime(b.created_at)}</dd></div>
              {b.notes && <div className="sm:col-span-3"><dt className="text-ink-muted">Observações</dt><dd className="whitespace-pre-line">{b.notes}</dd></div>}
            </dl>
          </Card>
          <PaymentsPanel bookingId={b.id} payments={payments ?? []} total={b.total_amount} />
          <PassengersPanel bookingId={b.id} passengers={passengers ?? []} people={b.people} />
        </div>

        <aside className="space-y-6">
          <Card className="p-5">
            <h2 className="font-semibold">Cliente</h2>
            <Link href={`/admin/clientes/${b.customer?.id}`} className="mt-2 block text-lg font-semibold text-lagoa-700 hover:underline">{b.customer?.name}</Link>
            <p className="text-sm text-ink-soft">{formatPhone(phone)}</p>
            {b.customer?.email && <p className="text-sm text-ink-soft">{b.customer.email}</p>}
            {phone && (
              <div className="mt-4 space-y-2">
                <p className="text-xs font-semibold text-ink-muted">Mensagens prontas</p>
                {templates.map((t) => <ButtonLink key={t.label} href={whatsappUrl(phone, t.text)} variant="secondary" size="sm" className="w-full justify-start"><WhatsAppIcon className="size-4 text-[#1FAF55]" />{t.label}</ButtonLink>)}
              </div>
            )}
          </Card>
          <Card className="p-5">
            <h2 className="font-semibold">Histórico</h2>
            <ol className="mt-4 space-y-4 border-l border-duna-800/10 pl-4">
              {history_.map((h) => (
                <li key={h.id} className="relative text-sm">
                  <span className="absolute -left-[21px] top-1 size-2.5 rounded-full bg-lagoa-500 ring-4 ring-white" />
                  <p className="font-medium">{h.from_status ? `${BOOKING_STATUS[h.from_status].label} → ` : 'Criada como '}{BOOKING_STATUS[h.to_status].label}</p>
                  {h.note && <p className="text-ink-soft">{h.note}</p>}
                  <p className="text-xs text-ink-muted">{fmtDateTime(h.created_at)}{h.author ? ` · ${h.author.full_name}` : ' · Site'}</p>
                </li>
              ))}
            </ol>
          </Card>
        </aside>
      </div>
    </>
  );
}
