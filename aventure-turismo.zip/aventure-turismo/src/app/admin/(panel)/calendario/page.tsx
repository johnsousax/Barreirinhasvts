import { PageHeader } from '@/components/admin/Shell';
import { CalendarView } from '@/components/admin/CalendarView';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { getSettings } from '@/lib/data/public';
import { todayISO } from '@/lib/format';

export const metadata = { title: 'Calendário' };

export default async function CalendarPage({ searchParams }: { searchParams: Promise<{ mes?: string; passeio?: string }> }) {
  await requirePermission('tours.view');
  const sp = await searchParams;
  const month = /^\d{4}-\d{2}$/.test(sp.mes ?? '') ? sp.mes! : todayISO().slice(0, 7);
  const start = `${month}-01`;
  const endD = new Date(`${start}T12:00:00`); endD.setMonth(endD.getMonth() + 1);
  const end = endD.toISOString().slice(0, 10);
  const sb = await createClient();
  let q = sb.from('schedule_availability').select('id, tour_id, date, start_time, capacity, available, booked, pending, status').gte('date', start).lt('date', end).order('start_time');
  if (sp.passeio) q = q.eq('tour_id', sp.passeio);
  const [{ data: schedules }, { data: tours }, settings] = await Promise.all([q, sb.from('tours').select('id, name').neq('publication', 'arquivado').order('name'), getSettings()]);
  return (
    <>
      <PageHeader title="Calendário" description="Saídas do mês com vagas e reservas. Clique em um horário para gerenciar." />
      <CalendarView month={month} tourId={sp.passeio ?? ''} tours={(tours ?? []).map((t) => ({ value: t.id, label: t.name }))} schedules={schedules ?? []} threshold={settings.low_seats_threshold} />
    </>
  );
}
