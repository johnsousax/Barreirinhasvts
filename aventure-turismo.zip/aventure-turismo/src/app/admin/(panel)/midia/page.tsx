import { PageHeader } from '@/components/admin/Shell';
import { MediaLibrary } from '@/components/admin/MediaLibrary';
import { can, requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import type { MediaItem } from '@/actions/media';

export const metadata = { title: 'Mídia' };

export default async function MediaPage() {
  const staff = await requirePermission('content.manage');
  const sb = await createClient();
  const { data } = await sb.from('media').select('*').order('created_at', { ascending: false }).limit(500);
  return (
    <>
      <PageHeader title="Biblioteca de mídia" description="Fotos e vídeos usados no site, organizados por categoria." />
      <MediaLibrary items={(data ?? []) as MediaItem[]} canDelete={can(staff, 'content.manage')} />
    </>
  );
}
