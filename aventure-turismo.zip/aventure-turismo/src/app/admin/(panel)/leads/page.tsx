import { PageHeader } from '@/components/admin/Shell';
import { LeadsBoard } from '@/components/admin/LeadsBoard';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import type { Lead } from '@/lib/types';

export const metadata = { title: 'Leads' };

export default async function LeadsPage() {
  await requirePermission('leads.manage');
  const sb = await createClient();
  const [{ data: leads }, { data: tours }] = await Promise.all([
    sb.from('leads').select('*, tour:tours(name)').order('position', { ascending: false }).limit(500),
    sb.from('tours').select('id, name, price, promo_price').neq('publication', 'arquivado').order('name'),
  ]);
  return (
    <>
      <PageHeader title="Leads" description="Arraste os cards entre as etapas. Contatos do site entram automaticamente em “Novo lead”." />
      <LeadsBoard leads={(leads ?? []) as Lead[]} tours={(tours ?? []).map((t) => ({ value: t.id, label: t.name, price: t.promo_price ?? t.price }))} />
    </>
  );
}
