import { AdminShell } from '@/components/admin/Shell';
import { requireStaff } from '@/lib/auth';
import { getSettings } from '@/lib/data/public';

export const dynamic = 'force-dynamic';

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const [staff, settings] = await Promise.all([requireStaff(), getSettings()]);
  return <AdminShell staff={staff} logo={settings.logo_url || '/brand/logo.png'}>{children}</AdminShell>;
}
