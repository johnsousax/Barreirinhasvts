import { CalendarCheck, CircleDollarSign, Percent, Users } from 'lucide-react';
import { PageHeader } from '@/components/admin/Shell';
import { BarsChart, DonutChart, TrendChart } from '@/components/admin/Charts';
import { UrlFilters } from '@/components/admin/UrlFilters';
import { ExportCsv } from '@/components/admin/ExportCsv';
import { Card, CardHeader } from '@/components/ui/Card';
import { StatsCard } from '@/components/ui/StatsCard';
import { Table, Td, Th } from '@/components/ui/Table';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { BOOKING_STATUS, LEAD_STAGES, REVENUE_STATUSES } from '@/lib/tour-status';
import { SOURCES, sourceLabel } from '@/lib/constants';
import { addDaysISO, brl, fmtDate, num, todayISO } from '@/lib/format';
import type { BookingStatus } from '@/lib/types';

export const metadata = { title: 'Relatórios' };

type B = { id: string; code: string; status: BookingStatus; date: string; people: number; total_amount: number | null; source: string; tour_id: string; tour: { name: string } | null; customer: { name: string; city: string | null } | null };

export default async function ReportsPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  await requirePermission('reports.view');
  const sp = await searchParams;
  const today = todayISO();
  const from = sp.de ?? addDaysISO(today, -89);
  const to = sp.ate ?? today;
  const sb = await createClient();
  let bq = sb.from('bookings').select('id, code, status, date, people, total_amount, source, tour_id, tour:tours(name), customer:customers(name, city)').gte('date', from).lte('date', to).limit(10000);
  if (sp.passeio) bq = bq.eq('tour_id', sp.passeio);
  if (sp.status) bq = bq.eq('status', sp.status);
  if (sp.origem) bq = bq.eq('source', sp.origem);
  const [{ data: bData }, { data: leads }, { data: tours }] = await Promise.all([
    bq,
    sb.from('leads').select('stage, source, created_at').gte('created_at', `${from}T00:00:00`).lte('created_at', `${to}T23:59:59`).limit(10000),
    sb.from('tours').select('id, name').order('name'),
  ]);
  const bookings = (bData ?? []) as unknown as B[];
  const valid = bookings.filter((b) => b.status !== 'cancelada');
  const paid = bookings.filter((b) => REVENUE_STATUSES.includes(b.status));
  const revenue = paid.reduce((a, b) => a + Number(b.total_amount ?? 0), 0);
  const people = valid.reduce((a, b) => a + b.people, 0);
  const cancelRate = bookings.length ? Math.round((bookings.filter((b) => b.status === 'cancelada').length / bookings.length) * 100) : 0;
  const lds = leads ?? [];
  const conv = lds.length ? Math.round((lds.filter((l) => ['reservado', 'concluido'].includes(l.stage)).length / lds.length) * 100) : 0;

  const days = Math.min(400, Math.round((new Date(`${to}T12:00:00`).getTime() - new Date(`${from}T12:00:00`).getTime()) / 864e5) + 1);
  const weekly = days > 62;
  const trend: { label: string; value: number }[] = [];
  for (let i = 0; i < days; i += weekly ? 7 : 1) {
    const s = addDaysISO(from, i);
    const e = addDaysISO(from, i + (weekly ? 6 : 0));
    trend.push({ label: fmtDate(s, { day: '2-digit', month: '2-digit' }), value: paid.filter((b) => b.date >= s && b.date <= e).reduce((a, b) => a + Number(b.total_amount ?? 0), 0) });
  }
  const group = <T,>(arr: T[], key: (x: T) => string, val: (x: T) => number = () => 1) =>
    Object.entries(arr.reduce<Record<string, number>>((acc, x) => { const k = key(x); acc[k] = (acc[k] ?? 0) + val(x); return acc; }, {}))
      .map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);

  const byTour = group(valid, (b) => b.tour?.name ?? '—');
  const revByTour = group(paid, (b) => b.tour?.name ?? '—', (b) => Number(b.total_amount ?? 0));
  const byStatus = Object.entries(BOOKING_STATUS).map(([k, m]) => ({ label: m.label, value: bookings.filter((b) => b.status === k).length })).filter((x) => x.value);
  const bySource = group(valid, (b) => sourceLabel(b.source));
  const leadsByStage = LEAD_STAGES.map((s) => ({ label: s.label, value: lds.filter((l) => l.stage === s.key).length })).filter((x) => x.value);
  const topCustomers = group(paid, (b) => b.customer?.name ?? '—', (b) => Number(b.total_amount ?? 0)).slice(0, 10);
  const weekdays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((label, i) => ({ label, value: valid.filter((b) => new Date(`${b.date}T12:00:00`).getDay() === i).length }));
  const csv = bookings.map((b) => ({ codigo: b.code, data: b.date, passeio: b.tour?.name, cliente: b.customer?.name, cidade: b.customer?.city, pessoas: b.people, valor: b.total_amount ?? '', status: BOOKING_STATUS[b.status].label, origem: sourceLabel(b.source) }));

  return (
    <>
      <PageHeader title="Relatórios" description={`Período de ${fmtDate(from)} a ${fmtDate(to)}.`} actions={<ExportCsv rows={csv} filename="relatorio-reservas" />} />
      <Card className="mb-6">
        <UrlFilters filters={[
          { name: 'de', type: 'date', label: 'De' }, { name: 'ate', type: 'date', label: 'Até' },
          { name: 'passeio', type: 'select', label: 'Passeio', options: (tours ?? []).map((t) => ({ value: t.id, label: t.name })) },
          { name: 'status', type: 'select', label: 'Status', options: Object.entries(BOOKING_STATUS).map(([k, m]) => ({ value: k, label: m.label })) },
          { name: 'origem', type: 'select', label: 'Origem', options: SOURCES },
        ]} />
      </Card>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatsCard label="Receita (pagas + concluídas)" value={brl(revenue)} hint={`Ticket médio ${brl(paid.length ? revenue / paid.length : 0)}`} icon={CircleDollarSign} tone="green" />
        <StatsCard label="Reservas válidas" value={num(valid.length)} hint={`${cancelRate}% de cancelamento`} icon={CalendarCheck} />
        <StatsCard label="Pessoas atendidas" value={num(people)} icon={Users} tone="navy" />
        <StatsCard label="Conversão de leads" value={`${conv}%`} hint={`${lds.length} leads no período`} icon={Percent} tone="orange" />
      </div>
      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2"><CardHeader title="Receita" description={weekly ? 'Por semana' : 'Por dia'} /><div className="p-3 pt-4"><TrendChart data={trend} money /></div></Card>
        <Card><CardHeader title="Reservas por status" /><div className="p-5"><DonutChart data={byStatus} /></div></Card>
        <Card className="xl:col-span-2"><CardHeader title="Passeios mais vendidos" description="Reservas válidas" /><div className="p-3 pt-4"><BarsChart data={byTour} horizontal /></div></Card>
        <Card><CardHeader title="Origem das reservas" /><div className="p-5"><DonutChart data={bySource} /></div></Card>
        <Card className="xl:col-span-2"><CardHeader title="Receita por passeio" /><div className="p-3 pt-4"><BarsChart data={revByTour} money horizontal /></div></Card>
        <Card><CardHeader title="Funil de leads" /><div className="p-5"><DonutChart data={leadsByStage} /></div></Card>
        <Card className="xl:col-span-2"><CardHeader title="Dias da semana mais procurados" /><div className="p-3 pt-4"><BarsChart data={weekdays} /></div></Card>
        <Card>
          <CardHeader title="Clientes que mais compraram" />
          {topCustomers.length === 0 ? <p className="px-5 py-6 text-sm text-ink-muted">Sem dados.</p> : (
            <Table className="mt-3"><thead><tr><Th>Cliente</Th><Th>Total</Th></tr></thead>
              <tbody>{topCustomers.map((c) => <tr key={c.label}><Td>{c.label}</Td><Td className="font-semibold">{brl(c.value)}</Td></tr>)}</tbody>
            </Table>
          )}
        </Card>
      </div>
    </>
  );
}
