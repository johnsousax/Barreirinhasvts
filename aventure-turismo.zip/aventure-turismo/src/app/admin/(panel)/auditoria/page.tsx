import { PageHeader } from '@/components/admin/Shell';
import { Pagination, UrlFilters } from '@/components/admin/UrlFilters';
import { Badge } from '@/components/ui/Badge';
import { Card } from '@/components/ui/Card';
import { EmptyState } from '@/components/ui/States';
import { Table, Td, Th } from '@/components/ui/Table';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { fmtDateTime } from '@/lib/format';

export const metadata = { title: 'Auditoria' };
const PER_PAGE = 50;
const ACTIONS: Record<string, { label: string; tone: string }> = {
  create: { label: 'Criou', tone: 'green' }, update: { label: 'Editou', tone: 'blue' }, delete: { label: 'Excluiu', tone: 'red' },
  status: { label: 'Status', tone: 'orange' }, publish: { label: 'Publicou', tone: 'navy' }, draft: { label: 'Rascunho', tone: 'amber' }, login: { label: 'Login', tone: 'gray' },
};
const ENTITIES = [
  ['tours', 'Passeios'], ['tour_schedules', 'Horários'], ['bookings', 'Reservas'], ['payments', 'Pagamentos'], ['customers', 'Clientes'], ['leads', 'Leads'],
  ['site_sections', 'Conteúdo'], ['site_settings', 'Configurações'], ['profiles', 'Usuários'], ['media', 'Mídia'], ['auth', 'Acesso'],
].map(([value, label]) => ({ value, label }));

export default async function AuditPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  await requirePermission('audit.view');
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page) || 1);
  const sb = await createClient();
  let q = sb.from('audit_logs').select('id, user_name, action, entity, summary, created_at', { count: 'exact' }).order('created_at', { ascending: false });
  if (sp.acao) q = q.eq('action', sp.acao);
  if (sp.entidade) q = q.eq('entity', sp.entidade);
  if (sp.de) q = q.gte('created_at', `${sp.de}T00:00:00`);
  if (sp.ate) q = q.lte('created_at', `${sp.ate}T23:59:59`);
  if (sp.q) q = q.ilike('summary', `%${sp.q.replace(/[%,]/g, '')}%`);
  const { data, count } = await q.range((page - 1) * PER_PAGE, page * PER_PAGE - 1);
  return (
    <>
      <PageHeader title="Auditoria" description="Quem alterou o quê e quando." />
      <Card>
        <UrlFilters filters={[
          { name: 'q', type: 'search', placeholder: 'Buscar na descrição' },
          { name: 'acao', type: 'select', label: 'Ação', options: Object.entries(ACTIONS).map(([value, m]) => ({ value, label: m.label })) },
          { name: 'entidade', type: 'select', label: 'Área', options: ENTITIES },
          { name: 'de', type: 'date', label: 'De' }, { name: 'ate', type: 'date', label: 'Até' },
        ]} />
        {!data?.length ? <EmptyState title="Nenhum registro." /> : (
          <Table>
            <thead><tr><Th>Quando</Th><Th>Ação</Th><Th>Descrição</Th></tr></thead>
            <tbody>{data.map((l) => (
              <tr key={l.id}>
                <Td className="whitespace-nowrap text-ink-muted">{fmtDateTime(l.created_at)}</Td>
                <Td><Badge tone={ACTIONS[l.action]?.tone ?? 'gray'}>{ACTIONS[l.action]?.label ?? l.action}</Badge></Td>
                <Td>{l.summary}</Td>
              </tr>
            ))}</tbody>
          </Table>
        )}
        <Pagination page={page} total={count ?? 0} perPage={PER_PAGE} />
      </Card>
    </>
  );
}
