import { PageHeader } from '@/components/admin/Shell';
import { TourForm } from '@/components/admin/TourForm';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';

export const metadata = { title: 'Novo passeio' };

export default async function NewTour() {
  await requirePermission('tours.manage');
  const sb = await createClient();
  const [{ data: cats }, { data: dests }] = await Promise.all([
    sb.from('tour_categories').select('id, name').order('sort_order'),
    sb.from('destinations').select('id, name').order('name'),
  ]);
  return (
    <>
      <PageHeader title="Novo passeio" back={{ href: '/admin/passeios', label: 'Passeios' }} description="Depois de salvar, cadastre as datas e vagas." />
      <TourForm tour={null} categories={(cats ?? []).map((c) => ({ value: c.id, label: c.name }))} destinations={(dests ?? []).map((d) => ({ value: d.id, label: d.name }))} />
    </>
  );
}
