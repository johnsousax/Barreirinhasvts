import Link from 'next/link';
import { Plus } from 'lucide-react';
import { PageHeader } from '@/components/admin/Shell';
import { TourRowActions, TourStatusSelect } from '@/components/admin/TourActions';
import { UrlFilters } from '@/components/admin/UrlFilters';
import { Badge, PlaceholderBadge } from '@/components/ui/Badge';
import { buttonClass } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Img } from '@/components/ui/Img';
import { EmptyState } from '@/components/ui/States';
import { Table, Td, Th } from '@/components/ui/Table';
import { can, requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { PUBLICATION, TOUR_STATUS } from '@/lib/tour-status';
import { brl, fmtDate } from '@/lib/format';
import type { Availability, Tour } from '@/lib/types';

export const metadata = { title: 'Passeios' };

export default async function ToursAdmin({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const staff = await requirePermission('tours.view');
  const sp = await searchParams;
  const sb = await createClient();
  let q = sb.from('tours').select('*, category:tour_categories(name), destination:destinations(name)').order('sort_order').order('name');
  if (sp.status) q = q.eq('status', sp.status);
  if (sp.publicacao) q = q.eq('publication', sp.publicacao);
  if (sp.q) q = q.ilike('name', `%${sp.q.replace(/[%,]/g, '')}%`);
  const [{ data }, { data: avail }] = await Promise.all([q, sb.rpc('get_tours_availability')]);
  const tours = (data ?? []) as Tour[];
  const availMap = new Map(((avail ?? []) as Availability[]).map((a) => [a.tour_id, a]));
  const editable = can(staff, 'tours.manage');

  return (
    <>
      <PageHeader title="Passeios" description="Mude o status aqui e o site é atualizado na hora."
        actions={editable && <Link href="/admin/passeios/novo" className={buttonClass()}><Plus className="size-4" />Novo passeio</Link>} />
      <Card>
        <UrlFilters filters={[
          { name: 'q', type: 'search', placeholder: 'Buscar passeio' },
          { name: 'status', type: 'select', label: 'Status', options: Object.entries(TOUR_STATUS).map(([k, m]) => ({ value: k, label: m.label })) },
          { name: 'publicacao', type: 'select', label: 'Publicação', options: Object.entries(PUBLICATION).map(([k, m]) => ({ value: k, label: m.label })) },
        ]} />
        {tours.length === 0 ? (
          <EmptyState title={Object.keys(sp).length ? 'Nenhum passeio com esses filtros.' : 'Nenhum passeio cadastrado.'} action={editable && !Object.keys(sp).length && <Link href="/admin/passeios/novo" className={buttonClass()}>Cadastrar passeio</Link>} />
        ) : (
          <Table>
            <thead><tr><Th>Passeio</Th><Th className="hidden lg:table-cell">Preço</Th><Th className="hidden md:table-cell">Vagas (próx.)</Th><Th>Status no site</Th><Th className="hidden sm:table-cell">Publicação</Th>{editable && <Th />}</tr></thead>
            <tbody>
              {tours.map((t) => {
                const a = availMap.get(t.id);
                return (
                  <tr key={t.id} className="hover:bg-slate-50/70">
                    <Td>
                      <Link href={`/admin/passeios/${t.id}`} className="flex items-center gap-3">
                        <span className="relative size-14 shrink-0 overflow-hidden rounded-xl bg-slate-100"><Img src={t.cover_url} alt="" fill sizes="56px" className="object-cover" /></span>
                        <span className="min-w-0">
                          <span className="block font-semibold hover:text-lagoa-600">{t.name}{t.featured && <span className="ml-1.5 text-sol-500" title="Destaque">★</span>}</span>
                          <span className="block text-xs text-ink-muted">{[t.category?.name, t.destination?.name].filter(Boolean).join(' · ')}</span>
                          {(t.is_placeholder || t.draft_data) && <span className="mt-1 flex gap-1">{t.is_placeholder && <PlaceholderBadge />}{t.draft_data && <Badge tone="amber">Rascunho pendente</Badge>}</span>}
                        </span>
                      </Link>
                    </Td>
                    <Td className="hidden whitespace-nowrap lg:table-cell">{t.price != null ? brl(t.promo_price ?? t.price) : <span className="text-ink-muted">A definir</span>}</Td>
                    <Td className="hidden md:table-cell">
                      {a && a.schedules > 0 ? <><span className="font-semibold">{a.available}</span><span className="text-ink-muted">/{a.capacity}</span><span className="block text-xs text-ink-muted">{a.next_date ? `próx. ${fmtDate(a.next_date, { day: '2-digit', month: '2-digit' })}` : ''}</span></> : <span className="text-xs text-ink-muted">Sem horários</span>}
                    </Td>
                    <Td>{editable ? <TourStatusSelect tour={t} /> : <Badge tone={TOUR_STATUS[t.status].tone}>{TOUR_STATUS[t.status].label}</Badge>}</Td>
                    <Td className="hidden sm:table-cell"><Badge tone={PUBLICATION[t.publication].tone}>{PUBLICATION[t.publication].label}</Badge></Td>
                    {editable && <Td><TourRowActions tour={t} /></Td>}
                  </tr>
                );
              })}
            </tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
