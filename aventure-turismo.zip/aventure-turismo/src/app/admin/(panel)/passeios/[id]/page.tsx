import { notFound } from 'next/navigation';
import { PageHeader } from '@/components/admin/Shell';
import { TourForm } from '@/components/admin/TourForm';
import { ScheduleManager } from '@/components/admin/ScheduleManager';
import { TourStatusSelect } from '@/components/admin/TourActions';
import { can, requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { getSettings } from '@/lib/data/public';
import { addDaysISO, todayISO } from '@/lib/format';
import type { ScheduleRow, Tour } from '@/lib/types';

export const metadata = { title: 'Editar passeio' };

export default async function EditTour({ params }: { params: Promise<{ id: string }> }) {
  const staff = await requirePermission('tours.view');
  const { id } = await params;
  const sb = await createClient();
  const [{ data: tour }, { data: cats }, { data: dests }, { data: schedules }, settings] = await Promise.all([
    sb.from('tours').select('*').eq('id', id).maybeSingle(),
    sb.from('tour_categories').select('id, name').order('sort_order'),
    sb.from('destinations').select('id, name').order('name'),
    sb.from('schedule_availability').select('*').eq('tour_id', id).gte('date', addDaysISO(todayISO(), -60)).order('date').order('start_time').limit(400),
    getSettings(),
  ]);
  if (!tour) notFound();
  const t = tour as Tour;
  const editable = can(staff, 'tours.manage');
  return (
    <>
      <PageHeader title={t.name} back={{ href: '/admin/passeios', label: 'Passeios' }} actions={editable && <TourStatusSelect tour={t} />} />
      <div className="space-y-6">
        <ScheduleManager tourId={t.id} schedules={(schedules ?? []) as ScheduleRow[]} defaultCapacity={t.capacity} defaultTimes={t.default_times} canEdit={editable} threshold={settings.low_seats_threshold} />
        {editable
          ? <TourForm tour={t} categories={(cats ?? []).map((c) => ({ value: c.id, label: c.name }))} destinations={(dests ?? []).map((d) => ({ value: d.id, label: d.name }))} />
          : <p className="text-sm text-ink-muted">Você tem acesso somente para visualização deste passeio.</p>}
      </div>
    </>
  );
}
