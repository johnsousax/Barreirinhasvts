import { PageHeader } from '@/components/admin/Shell';
import { ContentEditor } from '@/components/admin/ContentEditor';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';

export const metadata = { title: 'Conteúdo do site' };

export default async function ContentPage() {
  await requirePermission('content.manage');
  const sb = await createClient();
  const { data } = await sb.from('site_sections').select('key, draft, has_unpublished, published_at');
  return (
    <>
      <PageHeader title="Conteúdo do site" description="Edite textos e imagens. Salve como rascunho para revisar e publique quando estiver pronto." />
      <ContentEditor sections={data ?? []} />
    </>
  );
}
