import { PageHeader } from '@/components/admin/Shell';
import { SettingsForm } from '@/components/admin/SettingsForm';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { mergeSettings } from '@/lib/settings';

export const metadata = { title: 'Configurações' };

export default async function SettingsPage() {
  await requirePermission('settings.manage');
  const sb = await createClient();
  const { data } = await sb.from('site_settings').select('data').eq('id', 1).maybeSingle();
  return (
    <>
      <PageHeader title="Configurações" description="Dados da empresa, WhatsApp, redes sociais, SEO e regras de vagas. Aplicado ao site ao salvar." />
      <SettingsForm initial={mergeSettings(data?.data)} />
    </>
  );
}
