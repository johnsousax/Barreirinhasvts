import Link from 'next/link';
import { AlertTriangle, CalendarCheck, CircleDollarSign, Clock, Compass, Kanban, Ticket, UserPlus } from 'lucide-react';
import { PageHeader } from '@/components/admin/Shell';
import { BarsChart, DonutChart, TrendChart } from '@/components/admin/Charts';
import { Badge } from '@/components/ui/Badge';
import { Card, CardHeader } from '@/components/ui/Card';
import { StatsCard } from '@/components/ui/StatsCard';
import { EmptyState } from '@/components/ui/States';
import { Table, Td, Th } from '@/components/ui/Table';
import { requirePermission, can } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { BOOKING_STATUS, LEAD_STAGES, REVENUE_STATUSES } from '@/lib/tour-status';
import { addDaysISO, brl, fmtDate, fmtTime, num, todayISO } from '@/lib/format';
import { sourceLabel } from '@/lib/constants';
import { getSettings } from '@/lib/data/public';
import type { BookingStatus } from '@/lib/types';

export const metadata = { title: 'Dashboard' };

export default async function Dashboard({ searchParams }: { searchParams: Promise<{ acesso?: string }> }) {
  const staff = await requirePermission('dashboard.view');
  const sp = await searchParams;
  const sb = await createClient();
  const today = todayISO();
  const monthStart = `${today.slice(0, 7)}-01`;
  const since30 = addDaysISO(today, -29);
  const since180 = `${addDaysISO(monthStart, -155).slice(0, 7)}-01`;
  const settings = await getSettings();

  const [bookingsRes, leadsRes, toursRes, schedRes, recentRes] = await Promise.all([
    sb.from('bookings').select('id, status, date, people, total_amount, source, created_at, tour:tours(name)').gte('date', since180).limit(5000),
    sb.from('leads').select('id, stage, source, created_at').gte('created_at', `${since30}T00:00:00`).limit(5000),
    sb.from('tours').select('id, status, publication'),
    sb.from('schedule_availability').select('id, tour_id, date, start_time, capacity, available, booked, status').gte('date', today).lte('date', addDaysISO(today, 14)).eq('status', 'aberto').order('date').order('start_time').limit(200),
    sb.from('bookings').select('id, code, status, date, start_time, people, created_at, customer:customers(name), tour:tours(name)').order('created_at', { ascending: false }).limit(8),
  ]);
  type B = { id: string; status: BookingStatus; date: string; people: number; total_amount: number | null; source: string; created_at: string; tour: { name: string } | null };
  const bookings = (bookingsRes.data ?? []) as unknown as B[];
  const leads = leadsRes.data ?? [];
  const tours = toursRes.data ?? [];
  const schedules = schedRes.data ?? [];
  const recent = (recentRes.data ?? []) as unknown as { id: string; code: string; status: BookingStatus; date: string; start_time: string | null; people: number; customer: { name: string } | null; tour: { name: string } | null }[];
  const tourNames = new Map<string, string>();
  (await sb.from('tours').select('id, name')).data?.forEach((t) => tourNames.set(t.id, t.name));

  const active = bookings.filter((b) => b.status !== 'cancelada');
  const todayCount = active.filter((b) => b.date === today).length;
  const todayPeople = active.filter((b) => b.date === today).reduce((a, b) => a + b.people, 0);
  const monthBookings = active.filter((b) => b.date >= monthStart);
  const revenueMonth = bookings.filter((b) => b.date >= monthStart && REVENUE_STATUSES.includes(b.status)).reduce((a, b) => a + Number(b.total_amount ?? 0), 0);
  const pending = bookings.filter((b) => b.status === 'pendente').length;
  const lowSeats = schedules.filter((s) => s.capacity > 0 && s.available / s.capacity <= settings.low_seats_threshold);

  const perDay = Array.from({ length: 30 }, (_, i) => {
    const d = addDaysISO(since30, i);
    return { label: fmtDate(d, { day: '2-digit', month: '2-digit' }), value: bookings.filter((b) => b.created_at.slice(0, 10) === d).length };
  });
  const months = Array.from({ length: 6 }, (_, i) => {
    const d = new Date(`${monthStart}T12:00:00`); d.setMonth(d.getMonth() - 5 + i);
    const key = d.toISOString().slice(0, 7);
    return { label: fmtDate(`${key}-01`, { month: 'short' }).replace('.', ''), value: bookings.filter((b) => b.date.startsWith(key) && REVENUE_STATUSES.includes(b.status)).reduce((a, b) => a + Number(b.total_amount ?? 0), 0) };
  });
  const byTour = Object.entries(monthBookings.reduce<Record<string, number>>((acc, b) => { const n = b.tour?.name ?? '—'; acc[n] = (acc[n] ?? 0) + 1; return acc; }, {}))
    .map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value).slice(0, 6);
  const byStage = LEAD_STAGES.map((s) => ({ label: s.label, value: leads.filter((l) => l.stage === s.key).length })).filter((x) => x.value);
  const bySource = Object.entries(leads.reduce<Record<string, number>>((acc, l) => { acc[l.source] = (acc[l.source] ?? 0) + 1; return acc; }, {}))
    .map(([k, value]) => ({ label: sourceLabel(k), value })).sort((a, b) => b.value - a.value);
  const conversion = leads.length ? Math.round((leads.filter((l) => ['reservado', 'concluido'].includes(l.stage)).length / leads.length) * 100) : 0;

  return (
    <>
      <PageHeader title={`Olá, ${(staff.full_name || 'equipe').split(' ')[0]}`} description={`Resumo de ${fmtDate(today, { weekday: 'long', day: '2-digit', month: 'long' })}.`} />
      {sp.acesso === 'negado' && <p role="alert" className="mb-6 rounded-2xl bg-sol-50 px-4 py-3 text-sm text-sol-700 ring-1 ring-sol-500/20">Você não tem permissão para acessar aquela área. Fale com um administrador.</p>}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatsCard label="Reservas hoje" value={todayCount} hint={`${todayPeople} pessoas em passeio`} icon={CalendarCheck} href={`/admin/reservas?de=${today}&ate=${today}`} />
        <StatsCard label="Reservas no mês" value={num(monthBookings.length)} hint={`${monthBookings.reduce((a, b) => a + b.people, 0)} pessoas`} icon={Ticket} tone="navy" />
        <StatsCard label="Receita do mês" value={brl(revenueMonth)} hint="Reservas pagas e concluídas" icon={CircleDollarSign} tone="green" />
        <StatsCard label="Aguardando confirmação" value={pending} hint="Solicitações pendentes" icon={Clock} tone="orange" href="/admin/reservas?status=pendente" />
        <StatsCard label="Novos leads (30 dias)" value={leads.length} hint={`${conversion}% viraram reserva`} icon={UserPlus} href="/admin/leads" />
        <StatsCard label="Passeios publicados" value={tours.filter((t) => t.publication === 'publicado').length} hint={`${tours.filter((t) => t.status === 'esgotado').length} esgotados`} icon={Compass} tone="navy" href="/admin/passeios" />
        <StatsCard label="Saídas em 14 dias" value={schedules.length} hint={`${schedules.reduce((a, s) => a + s.available, 0)} vagas livres`} icon={Kanban} tone="green" href="/admin/calendario" />
        <StatsCard label="Com poucas vagas" value={lowSeats.length} hint="Próximos 14 dias" icon={AlertTriangle} tone="orange" href="/admin/calendario" />
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Card className="xl:col-span-2"><CardHeader title="Reservas criadas" description="Últimos 30 dias" /><div className="p-3 pt-4"><TrendChart data={perDay} /></div></Card>
        <Card><CardHeader title="Leads por etapa" description="Últimos 30 dias" /><div className="p-5"><DonutChart data={byStage} /></div></Card>
        {can(staff, 'reports.view') && <Card className="xl:col-span-2"><CardHeader title="Receita por mês" description="Reservas pagas e concluídas" /><div className="p-3 pt-4"><BarsChart data={months} money /></div></Card>}
        <Card><CardHeader title="Origem dos leads" /><div className="p-5"><DonutChart data={bySource} /></div></Card>
        <Card className="xl:col-span-2"><CardHeader title="Passeios mais reservados" description="Mês atual" /><div className="p-3 pt-4"><BarsChart data={byTour} horizontal /></div></Card>
        <Card>
          <CardHeader title="Atenção às vagas" description="Horários com poucas vagas" />
          {lowSeats.length === 0 ? <p className="px-5 py-8 text-sm text-ink-muted">Nenhum horário com poucas vagas nos próximos 14 dias.</p> : (
            <ul className="divide-y divide-duna-800/[.06] px-5 py-2">
              {lowSeats.slice(0, 8).map((s) => (
                <li key={s.id} className="flex items-center justify-between gap-2 py-2.5 text-sm">
                  <Link href={`/admin/passeios/${s.tour_id}#horarios`} className="min-w-0 hover:text-lagoa-600">
                    <span className="block truncate font-medium">{tourNames.get(s.tour_id)}</span>
                    <span className="text-ink-muted">{fmtDate(s.date, { weekday: 'short', day: '2-digit', month: '2-digit' })} {fmtTime(s.start_time)}</span>
                  </Link>
                  <Badge tone={s.available === 0 ? 'red' : 'orange'}>{s.available === 0 ? 'Lotado' : `${s.available} vagas`}</Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Card className="mt-6">
        <CardHeader title="Últimas reservas" actions={<Link href="/admin/reservas" className="text-sm font-semibold text-lagoa-600">Ver todas</Link>} />
        {recent.length === 0 ? <EmptyState title="Nenhuma reserva ainda." description="As solicitações feitas pelo site aparecem aqui." /> : (
          <Table className="mt-3">
            <thead><tr><Th>Código</Th><Th>Cliente</Th><Th className="hidden md:table-cell">Passeio</Th><Th>Data</Th><Th>Status</Th></tr></thead>
            <tbody>{recent.map((b) => (
              <tr key={b.id} className="hover:bg-slate-50/70">
                <Td><Link href={`/admin/reservas/${b.id}`} className="font-semibold text-lagoa-700 hover:underline">{b.code}</Link></Td>
                <Td>{b.customer?.name}</Td>
                <Td className="hidden md:table-cell">{b.tour?.name}</Td>
                <Td className="whitespace-nowrap">{fmtDate(b.date)} {fmtTime(b.start_time)}</Td>
                <Td><Badge tone={BOOKING_STATUS[b.status].tone}>{BOOKING_STATUS[b.status].label}</Badge></Td>
              </tr>
            ))}</tbody>
          </Table>
        )}
      </Card>
    </>
  );
}
