import Link from 'next/link';
import { EmptyState } from '@/components/ui/States';

export default function NotFound() {
  return <EmptyState title="Registro não encontrado." description="Ele pode ter sido excluído." action={<Link href="/admin" className="font-semibold text-lagoa-600">Voltar ao dashboard</Link>} />;
}
