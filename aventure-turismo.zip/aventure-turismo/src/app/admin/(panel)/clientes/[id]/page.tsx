import Link from 'next/link';
import { notFound } from 'next/navigation';
import { PageHeader } from '@/components/admin/Shell';
import { CustomerEditorButton, DeleteCustomerButton, InteractionForm } from '@/components/admin/Customers';
import { NewBookingButton } from '@/components/admin/Bookings';
import { Badge } from '@/components/ui/Badge';
import { ButtonLink } from '@/components/ui/Button';
import { Card, CardHeader } from '@/components/ui/Card';
import { StatsCard } from '@/components/ui/StatsCard';
import { Table, Td, Th } from '@/components/ui/Table';
import { WhatsAppIcon } from '@/components/ui/icons';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { BOOKING_STATUS, LEAD_STAGES, REVENUE_STATUSES } from '@/lib/tour-status';
import { CHANNELS, sourceLabel } from '@/lib/constants';
import { brl, fmtDate, fmtDateTime, formatPhone } from '@/lib/format';
import { whatsappUrl } from '@/lib/whatsapp';
import type { BookingStatus, Customer, LeadStage } from '@/lib/types';
import { CalendarCheck, CircleDollarSign, Users } from 'lucide-react';

export const metadata = { title: 'Cliente' };

export default async function CustomerDetail({ params }: { params: Promise<{ id: string }> }) {
  await requirePermission('customers.manage');
  const { id } = await params;
  const sb = await createClient();
  const [{ data: c }, { data: bookings }, { data: interactions }, { data: leads }, { data: tours }] = await Promise.all([
    sb.from('customers').select('*').eq('id', id).maybeSingle(),
    sb.from('bookings').select('id, code, date, people, status, total_amount, tour:tours(name)').eq('customer_id', id).order('date', { ascending: false }),
    sb.from('customer_interactions').select('id, channel, description, created_at, author:profiles(full_name)').eq('customer_id', id).order('created_at', { ascending: false }).limit(50),
    sb.from('leads').select('id, interest, stage, created_at').eq('customer_id', id).order('created_at', { ascending: false }),
    sb.from('tours').select('id, name, price, promo_price').neq('publication', 'arquivado').order('name'),
  ]);
  if (!c) notFound();
  const customer = c as Customer;
  const bs = (bookings ?? []) as unknown as { id: string; code: string; date: string; people: number; status: BookingStatus; total_amount: number | null; tour: { name: string } | null }[];
  const ints = (interactions ?? []) as unknown as { id: string; channel: string; description: string; created_at: string; author: { full_name: string } | null }[];
  const phone = customer.whatsapp || customer.phone;
  const paid = bs.filter((b) => REVENUE_STATUSES.includes(b.status)).reduce((a, b) => a + Number(b.total_amount ?? 0), 0);

  return (
    <>
      <PageHeader title={customer.name} back={{ href: '/admin/clientes', label: 'Clientes' }}
        description={`Cliente desde ${fmtDate(customer.first_contact_at ?? customer.created_at)} · origem: ${sourceLabel(customer.source)}`}
        actions={<>
          {phone && <ButtonLink href={whatsappUrl(phone, `Olá, ${customer.name.split(' ')[0]}! Aqui é da Aventure Turismo.`)} variant="whatsapp"><WhatsAppIcon className="size-4" />WhatsApp</ButtonLink>}
          <NewBookingButton variant="secondary" tours={(tours ?? []).map((t) => ({ value: t.id, label: t.name, price: t.promo_price ?? t.price }))} prefill={{ customer_id: customer.id, customer_label: customer.name }} />
          <CustomerEditorButton customer={customer} label="Editar" variant="secondary" />
          <DeleteCustomerButton id={customer.id} name={customer.name} />
        </>} />
      <div className="grid gap-4 sm:grid-cols-3">
        <StatsCard label="Reservas" value={bs.filter((b) => b.status !== 'cancelada').length} icon={CalendarCheck} />
        <StatsCard label="Pessoas levadas" value={bs.filter((b) => b.status !== 'cancelada').reduce((a, b) => a + b.people, 0)} icon={Users} tone="navy" />
        <StatsCard label="Total pago" value={brl(paid)} icon={CircleDollarSign} tone="green" />
      </div>
      <div className="mt-6 grid gap-6 xl:grid-cols-[1fr_380px]">
        <div className="space-y-6">
          <Card>
            <CardHeader title="Histórico de reservas" />
            {bs.length === 0 ? <p className="px-5 py-6 text-sm text-ink-muted">Nenhuma reserva.</p> : (
              <Table className="mt-3"><thead><tr><Th>Código</Th><Th>Passeio</Th><Th>Data</Th><Th className="hidden sm:table-cell">Valor</Th><Th>Status</Th></tr></thead>
                <tbody>{bs.map((b) => (
                  <tr key={b.id}><Td><Link href={`/admin/reservas/${b.id}`} className="font-semibold text-lagoa-700 hover:underline">{b.code}</Link></Td><Td>{b.tour?.name}</Td><Td>{fmtDate(b.date)}</Td><Td className="hidden sm:table-cell">{b.total_amount != null ? brl(b.total_amount) : '—'}</Td><Td><Badge tone={BOOKING_STATUS[b.status].tone}>{BOOKING_STATUS[b.status].label}</Badge></Td></tr>
                ))}</tbody>
              </Table>
            )}
          </Card>
          <Card className="p-5">
            <h2 className="font-display text-base font-semibold">Contatos e anotações</h2>
            <div className="mt-4"><InteractionForm customerId={customer.id} /></div>
            <ol className="mt-6 space-y-4">
              {ints.length === 0 && <li className="text-sm text-ink-muted">Nenhum contato registrado.</li>}
              {ints.map((i) => (
                <li key={i.id} className="rounded-2xl bg-slate-50 p-3 text-sm">
                  <p className="flex items-center justify-between gap-2 text-xs text-ink-muted"><span className="font-semibold text-ink">{CHANNELS.find((x) => x.value === i.channel)?.label}</span>{fmtDateTime(i.created_at)}{i.author ? ` · ${i.author.full_name}` : ''}</p>
                  <p className="mt-1 whitespace-pre-line">{i.description}</p>
                </li>
              ))}
            </ol>
          </Card>
        </div>
        <aside className="space-y-6">
          <Card className="p-5 text-sm">
            <h2 className="font-semibold">Dados</h2>
            <dl className="mt-3 space-y-2">
              <div><dt className="text-ink-muted">WhatsApp</dt><dd>{formatPhone(customer.whatsapp) || '—'}</dd></div>
              <div><dt className="text-ink-muted">Telefone</dt><dd>{formatPhone(customer.phone) || '—'}</dd></div>
              <div><dt className="text-ink-muted">E-mail</dt><dd className="break-all">{customer.email || '—'}</dd></div>
              <div><dt className="text-ink-muted">Cidade</dt><dd>{[customer.city, customer.state].filter(Boolean).join(' - ') || '—'}</dd></div>
              {customer.notes && <div><dt className="text-ink-muted">Observações</dt><dd className="whitespace-pre-line">{customer.notes}</dd></div>}
            </dl>
          </Card>
          <Card className="p-5 text-sm">
            <h2 className="font-semibold">Leads</h2>
            <ul className="mt-3 space-y-2">
              {(leads ?? []).length === 0 && <li className="text-ink-muted">Nenhum lead vinculado.</li>}
              {(leads ?? []).map((l) => {
                const st = LEAD_STAGES.find((s) => s.key === (l.stage as LeadStage))!;
                return <li key={l.id} className="flex items-center justify-between gap-2"><span>{l.interest || 'Contato'}<span className="block text-xs text-ink-muted">{fmtDate(l.created_at)}</span></span><Badge tone={st.tone}>{st.label}</Badge></li>;
              })}
            </ul>
          </Card>
        </aside>
      </div>
    </>
  );
}
