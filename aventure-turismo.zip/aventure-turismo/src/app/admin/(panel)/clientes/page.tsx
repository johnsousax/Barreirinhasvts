import Link from 'next/link';
import { PageHeader } from '@/components/admin/Shell';
import { CustomerEditorButton } from '@/components/admin/Customers';
import { Pagination, UrlFilters } from '@/components/admin/UrlFilters';
import { ExportCsv } from '@/components/admin/ExportCsv';
import { Card } from '@/components/ui/Card';
import { EmptyState } from '@/components/ui/States';
import { Table, Td, Th } from '@/components/ui/Table';
import { WhatsAppIcon } from '@/components/ui/icons';
import { requirePermission } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';
import { SOURCES, sourceLabel } from '@/lib/constants';
import { brl, fmtDate, formatPhone } from '@/lib/format';
import { REVENUE_STATUSES } from '@/lib/tour-status';
import { whatsappUrl } from '@/lib/whatsapp';

export const metadata = { title: 'Clientes' };
const PER_PAGE = 30;

export default async function CustomersPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  await requirePermission('customers.manage');
  const sp = await searchParams;
  const page = Math.max(1, Number(sp.page) || 1);
  const sb = await createClient();
  let q = sb.from('customers').select('*, bookings(date, status, total_amount)', { count: 'exact' }).order('created_at', { ascending: false });
  if (sp.origem) q = q.eq('source', sp.origem);
  if (sp.q) { const t = sp.q.replace(/[%,()]/g, ''); q = q.or(`name.ilike.%${t}%,phone.ilike.%${t}%,whatsapp.ilike.%${t}%,email.ilike.%${t}%,city.ilike.%${t}%`); }
  const { data, count } = await q.range((page - 1) * PER_PAGE, page * PER_PAGE - 1);
  type Row = { id: string; name: string; phone: string | null; whatsapp: string | null; email: string | null; city: string | null; state: string | null; source: string; created_at: string; bookings: { date: string; status: string; total_amount: number | null }[] };
  const rows = (data ?? []) as Row[];
  const summary = (r: Row) => {
    const valid = r.bookings.filter((b) => b.status !== 'cancelada');
    return {
      count: valid.length,
      total: r.bookings.filter((b) => (REVENUE_STATUSES as string[]).includes(b.status)).reduce((a, b) => a + Number(b.total_amount ?? 0), 0),
      last: valid.map((b) => b.date).sort().at(-1),
    };
  };
  return (
    <>
      <PageHeader title="Clientes" description="Todos que já reservaram ou entraram em contato."
        actions={<><ExportCsv rows={rows.map((r) => ({ nome: r.name, whatsapp: r.whatsapp ?? r.phone, email: r.email, cidade: r.city, origem: sourceLabel(r.source), reservas: summary(r).count, total_pago: summary(r).total }))} filename="clientes" /><CustomerEditorButton label="Novo cliente" /></>} />
      <Card>
        <UrlFilters filters={[{ name: 'q', type: 'search', placeholder: 'Nome, telefone, e-mail ou cidade' }, { name: 'origem', type: 'select', label: 'Origem', options: SOURCES }]} />
        {rows.length === 0 ? <EmptyState title="Nenhum cliente encontrado." /> : (
          <Table>
            <thead><tr><Th>Cliente</Th><Th className="hidden md:table-cell">Cidade</Th><Th>Reservas</Th><Th className="hidden lg:table-cell">Total pago</Th><Th className="hidden lg:table-cell">Último passeio</Th><Th className="hidden xl:table-cell">Origem</Th><Th /></tr></thead>
            <tbody>{rows.map((r) => {
              const s = summary(r);
              const phone = r.whatsapp || r.phone;
              return (
                <tr key={r.id} className="hover:bg-slate-50/70">
                  <Td><Link href={`/admin/clientes/${r.id}`} className="block font-semibold hover:text-lagoa-600">{r.name}</Link><span className="text-xs text-ink-muted">{formatPhone(phone) || r.email}</span></Td>
                  <Td className="hidden md:table-cell">{[r.city, r.state].filter(Boolean).join(' - ') || '—'}</Td>
                  <Td>{s.count}</Td>
                  <Td className="hidden lg:table-cell">{brl(s.total)}</Td>
                  <Td className="hidden lg:table-cell">{s.last ? fmtDate(s.last) : '—'}</Td>
                  <Td className="hidden xl:table-cell">{sourceLabel(r.source)}</Td>
                  <Td>{phone && <a href={whatsappUrl(phone, `Olá, ${r.name.split(' ')[0]}! Aqui é da Aventure Turismo.`)} target="_blank" rel="noopener noreferrer" className="grid size-8 place-items-center rounded-full text-[#1FAF55] hover:bg-emerald-50" aria-label="WhatsApp"><WhatsAppIcon className="size-4" /></a>}</Td>
                </tr>
              );
            })}</tbody>
          </Table>
        )}
        <Pagination page={page} total={count ?? 0} perPage={PER_PAGE} />
      </Card>
    </>
  );
}
