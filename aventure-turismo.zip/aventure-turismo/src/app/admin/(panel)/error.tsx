'use client';
import { ErrorState } from '@/components/ui/States';
import { Button } from '@/components/ui/Button';

export default function PanelError({ error, reset }: { error: Error; reset: () => void }) {
  return <ErrorState description={error.message.length < 200 ? error.message : undefined} action={<Button onClick={reset}>Tentar novamente</Button>} />;
}
