import { PageHeader } from '@/components/admin/Shell';
import { ProfileForm } from '@/components/admin/ProfileForm';
import { requireStaff } from '@/lib/auth';
import { ROLE_LABEL } from '@/lib/permissions';

export const metadata = { title: 'Meu perfil' };

export default async function ProfilePage() {
  const staff = await requireStaff();
  return (
    <>
      <PageHeader title="Meu perfil" />
      <ProfileForm name={staff.full_name} email={staff.email ?? ''} role={ROLE_LABEL[staff.role]} />
    </>
  );
}
