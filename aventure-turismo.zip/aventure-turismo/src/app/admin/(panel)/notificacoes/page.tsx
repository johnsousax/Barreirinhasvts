import { PageHeader } from '@/components/admin/Shell';
import { NotificationsList } from '@/components/admin/NotificationsList';
import { listNotifications } from '@/actions/notifications';
import { requirePermission } from '@/lib/auth';

export const metadata = { title: 'Notificações' };

export default async function NotificationsPage() {
  await requirePermission('notifications.view');
  const { items } = await listNotifications(200);
  return (
    <>
      <PageHeader title="Notificações" />
      <NotificationsList items={items} />
    </>
  );
}
