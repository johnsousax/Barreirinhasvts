import Image from 'next/image';
import { Img } from '@/components/ui/Img';

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="relative hidden lg:block">
        <Img src="/images/lagoa-bandeira.webp" alt="" fill priority sizes="50vw" className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-duna-950/80 to-duna-950/10" />
        <p className="absolute bottom-10 left-10 max-w-sm font-display text-3xl font-semibold leading-tight text-white">Painel de gestão da Aventure Turismo</p>
      </div>
      <div className="flex items-center justify-center bg-white px-6 py-12">
        <div className="w-full max-w-sm">
          <Image src="/brand/logo.png" alt="Aventure Turismo" width={769} height={378} className="mb-10 h-14 w-auto" priority />
          {children}
        </div>
      </div>
    </div>
  );
}
