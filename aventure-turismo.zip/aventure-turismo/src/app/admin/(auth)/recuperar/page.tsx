'use client';
import { useActionState } from 'react';
import Link from 'next/link';
import { requestPasswordReset } from '@/actions/auth';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';

export default function RecoverPage() {
  const [state, action, pending] = useActionState(requestPasswordReset, null);
  return (
    <>
      <h1 className="font-display text-2xl font-semibold text-ink">Recuperar senha</h1>
      <p className="mt-1 text-sm text-ink-muted">Enviaremos um link para você criar uma nova senha.</p>
      {state?.ok ? (
        <p role="status" className="mt-8 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{state.message}</p>
      ) : (
        <form action={action} className="mt-8 space-y-4">
          <Field label="E-mail" htmlFor="email"><Input id="email" name="email" type="email" autoComplete="email" required autoFocus /></Field>
          {state && !state.ok && <p role="alert" className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">{state.error}</p>}
          <Button type="submit" size="lg" loading={pending} className="w-full">Enviar link</Button>
        </form>
      )}
      <Link href="/admin/login" className="mt-6 block text-center text-sm font-medium text-lagoa-600 hover:underline">Voltar para o login</Link>
    </>
  );
}
