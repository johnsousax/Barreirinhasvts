'use client';
import { useActionState } from 'react';
import { updatePassword } from '@/actions/auth';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';

export default function ResetPage() {
  const [state, action, pending] = useActionState(updatePassword, null);
  return (
    <>
      <h1 className="font-display text-2xl font-semibold text-ink">Criar nova senha</h1>
      <p className="mt-1 text-sm text-ink-muted">Use pelo menos 8 caracteres.</p>
      <form action={action} className="mt-8 space-y-4">
        <Field label="Nova senha" htmlFor="password"><Input id="password" name="password" type="password" autoComplete="new-password" minLength={8} required autoFocus /></Field>
        <Field label="Confirme a senha" htmlFor="confirm"><Input id="confirm" name="confirm" type="password" autoComplete="new-password" required /></Field>
        {state && !state.ok && <p role="alert" className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">{state.error}</p>}
        <Button type="submit" size="lg" loading={pending} className="w-full">Salvar senha</Button>
      </form>
    </>
  );
}
