import { LoginForm } from './LoginForm';

export const metadata = { title: 'Entrar' };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ next?: string; erro?: string }> }) {
  const sp = await searchParams;
  return (
    <>
      <h1 className="font-display text-2xl font-semibold text-ink">Entrar no painel</h1>
      <p className="mt-1 text-sm text-ink-muted">Acesso restrito à equipe.</p>
      {sp.erro === 'link' && <p role="alert" className="mt-4 rounded-xl bg-red-50 px-3 py-2 text-sm text-red-700">O link expirou ou é inválido. Solicite um novo.</p>}
      <LoginForm next={sp.next ?? ''} />
    </>
  );
}
