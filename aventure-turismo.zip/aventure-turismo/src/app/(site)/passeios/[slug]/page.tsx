import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { AlertTriangle, CalendarDays, Check, ChevronLeft, Clock, MapPin, Play, Sun, Users, X } from 'lucide-react';
import { TourGallery } from '@/components/site/GalleryGrid';
import { BookingForm } from '@/components/site/BookingForm';
import { StatusBadge, TourCard, TourPrice } from '@/components/site/TourCard';
import { JsonLd } from '@/components/site/Blocks';
import { Badge } from '@/components/ui/Badge';
import { buttonClass } from '@/components/ui/Button';
import { getSettings, getTourBySlug, getTours } from '@/lib/data/public';
import { TOUR_STATUS, TOUR_TYPE } from '@/lib/tour-status';
import { fmtDate, fmtTime } from '@/lib/format';
import { SITE_URL } from '@/lib/supabase/env';

export const revalidate = 60;

export async function generateStaticParams() {
  const tours = await getTours();
  return tours.map((t) => ({ slug: t.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const data = await getTourBySlug(slug);
  if (!data) return { title: 'Passeio não encontrado' };
  const t = data.tour;
  const desc = t.seo_description || t.short_description || undefined;
  return {
    title: t.seo_title || `${t.name} em ${t.destination?.name ?? 'Barreirinhas'}`,
    description: desc,
    alternates: { canonical: `/passeios/${t.slug}` },
    openGraph: { title: t.name, description: desc, images: t.cover_url ? [{ url: t.cover_url }] : undefined },
  };
}

function List({ title, items, icon: Icon, tone }: { title: string; items: string[]; icon: typeof Check; tone: string }) {
  if (!items.length) return null;
  return (
    <div>
      <h3 className="text-lg font-semibold text-ink">{title}</h3>
      <ul className="mt-3 space-y-2">
        {items.map((i) => <li key={i} className="flex gap-2.5 text-ink-soft"><Icon className={`mt-0.5 size-5 shrink-0 ${tone}`} />{i}</li>)}
      </ul>
    </div>
  );
}

function videoEmbed(url: string) {
  const yt = url.match(/(?:youtu\.be\/|v=|shorts\/)([\w-]{11})/);
  return yt ? `https://www.youtube-nocookie.com/embed/${yt[1]}` : null;
}

export default async function TourPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [data, settings, all] = await Promise.all([getTourBySlug(slug), getSettings(), getTours()]);
  if (!data) notFound();
  const { tour: t, slots } = data;
  const meta = TOUR_STATUS[t.display_status];
  const photos = Array.from(new Set([t.cover_url, ...t.photos].filter(Boolean) as string[]));
  const related = all.filter((x) => x.id !== t.id && (x.destination_id === t.destination_id || x.category_id === t.category_id)).slice(0, 3);
  const times = Array.from(new Set(slots.map((s) => fmtTime(s.start_time)).filter(Boolean)));
  const embed = t.video_url ? videoEmbed(t.video_url) : null;
  const price = t.promo_price ?? t.price;

  return (
    <>
      <JsonLd data={{
        '@context': 'https://schema.org', '@type': 'TouristTrip', name: t.name, description: t.short_description ?? t.description,
        image: photos.map((p) => (p.startsWith('/') ? `${SITE_URL}${p}` : p)), url: `${SITE_URL}/passeios/${t.slug}`,
        touristType: TOUR_TYPE[t.tour_type],
        provider: { '@type': 'TravelAgency', name: settings.company_name, url: SITE_URL },
        ...(price != null ? { offers: { '@type': 'Offer', price, priceCurrency: 'BRL', availability: meta.bookable ? 'https://schema.org/InStock' : 'https://schema.org/SoldOut', url: `${SITE_URL}/passeios/${t.slug}` } } : {}),
      }} />

      <div className="container pt-6 sm:pt-8">
        <nav aria-label="Trilha" className="mb-5 text-sm">
          <Link href="/passeios" className="inline-flex items-center gap-1 font-medium text-lagoa-600 hover:underline"><ChevronLeft className="size-4" />Todos os passeios</Link>
        </nav>
        <TourGallery photos={photos} name={t.name} />
      </div>

      <div className="container grid grid-cols-1 gap-12 py-10 lg:grid-cols-[minmax(0,1fr)_400px] lg:gap-16 lg:py-14">
        <article className="min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={t.display_status} />
            {t.category && <Badge tone="navy">{t.category.name}</Badge>}
          </div>
          <h1 className="display-lg mt-3 break-words text-ink">{t.name}</h1>
          <ul className="mt-5 flex flex-wrap gap-x-6 gap-y-2 text-ink-soft">
            {t.destination && <li className="flex items-center gap-2"><MapPin className="size-5 text-lagoa-600" /><Link href={`/destinos/${t.destination.slug}`} className="hover:underline">{t.destination.name}</Link></li>}
            <li className="flex items-center gap-2"><Clock className="size-5 text-lagoa-600" />{t.duration_label || 'Duração a confirmar'}</li>
            <li className="flex items-center gap-2"><Users className="size-5 text-lagoa-600" />{TOUR_TYPE[t.tour_type]}</li>
            {times.length > 0 && <li className="flex items-center gap-2"><Sun className="size-5 text-lagoa-600" />Saídas às {times.join(', ')}</li>}
          </ul>

          {t.short_description && <p className="lead mt-8">{t.short_description}</p>}
          {t.description && <div className="mt-5 space-y-4 text-[17px] leading-relaxed text-ink-soft">{t.description.split(/\n+/).map((p, i) => <p key={i}>{p}</p>)}</div>}

          {t.important_info.length > 0 && (
            <div className="mt-10 rounded-3xl bg-sol-50 p-5 ring-1 ring-sol-500/20 sm:p-6">
              <h2 className="flex items-center gap-2 text-lg font-semibold text-ink"><AlertTriangle className="size-5 text-sol-600" />Informações importantes</h2>
              <ul className="mt-3 list-disc space-y-1.5 pl-5 text-ink-soft marker:text-sol-500">{t.important_info.map((i) => <li key={i}>{i}</li>)}</ul>
            </div>
          )}

          {t.itinerary.length > 0 && (
            <section className="mt-12" aria-labelledby="roteiro">
              <h2 id="roteiro" className="display-md text-ink">Roteiro</h2>
              <ol className="mt-6 space-y-0">
                {t.itinerary.map((step, i) => (
                  <li key={i} className="relative flex gap-5 pb-8 last:pb-0">
                    {i < t.itinerary.length - 1 && <span className="absolute left-[1.1rem] top-10 h-[calc(100%-2.5rem)] w-px bg-lagoa-300" aria-hidden />}
                    <span className="grid size-9 shrink-0 place-items-center rounded-full bg-lagoa-500 font-display text-sm font-semibold text-white">{i + 1}</span>
                    <div className="pt-1">
                      {step.time && <p className="text-sm font-semibold text-sol-600">{step.time}</p>}
                      <h3 className="font-semibold text-ink">{step.title}</h3>
                      {step.description && <p className="mt-1 text-ink-soft">{step.description}</p>}
                    </div>
                  </li>
                ))}
              </ol>
            </section>
          )}

          <section className="mt-12 grid gap-8 rounded-3xl bg-areia-50 p-6 sm:grid-cols-2 sm:p-8" aria-label="Detalhes">
            <List title="O que está incluso" items={t.included} icon={Check} tone="text-emerald-600" />
            <List title="Não incluso" items={t.not_included} icon={X} tone="text-red-500" />
            <List title="Recomendações" items={t.recommendations} icon={Sun} tone="text-sol-600" />
            <div>
              <h3 className="text-lg font-semibold text-ink">Ponto de encontro</h3>
              <p className="mt-3 flex gap-2.5 text-ink-soft"><MapPin className="mt-0.5 size-5 shrink-0 text-lagoa-600" />{t.meeting_point || 'Informado na confirmação da reserva.'}</p>
              {slots.length > 0 && (
                <>
                  <h3 className="mt-6 text-lg font-semibold text-ink">Próximas datas</h3>
                  <ul className="mt-3 space-y-1.5 text-ink-soft">
                    {slots.slice(0, 5).map((s) => (
                      <li key={s.schedule_id} className="flex items-center gap-2.5"><CalendarDays className="size-5 text-lagoa-600" />
                        {fmtDate(s.date, { weekday: 'short', day: '2-digit', month: 'short' })} {fmtTime(s.start_time)}
                        <span className={s.available > 0 ? 'text-emerald-700' : 'text-red-600'}>{s.available > 0 ? `${s.available} vagas` : 'esgotado'}</span>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          </section>

          {t.video_url && (
            <section className="mt-12" aria-label="Vídeo">
              {embed
                ? <div className="aspect-video overflow-hidden rounded-3xl"><iframe src={embed} title={`Vídeo: ${t.name}`} loading="lazy" allowFullScreen className="size-full" /></div>
                : <a href={t.video_url} target="_blank" rel="noopener noreferrer" className={buttonClass('secondary')}><Play className="size-4" />Assistir ao vídeo</a>}
            </section>
          )}
        </article>

        <aside id="reservar" className="min-w-0 scroll-mt-24 lg:sticky lg:top-24 lg:self-start">
          <div className="mb-4 flex items-end justify-between gap-4 rounded-3xl bg-duna-800/[.04] px-5 py-4">
            <TourPrice tour={t} />
            {!meta.bookable && <Badge tone={meta.tone}>{meta.label}</Badge>}
          </div>
          <BookingForm
            tourId={t.id} tourName={t.name} slots={slots} bookable={meta.bookable} blockedLabel={meta.cta}
            whatsapp={settings.whatsapp} whatsappMessage={t.whatsapp_message || settings.whatsapp_tour_message}
            defaultTimes={t.default_times}
          />
        </aside>
      </div>

      {related.length > 0 && (
        <section className="bg-areia-50 py-16" aria-labelledby="rel">
          <div className="container">
            <h2 id="rel" className="display-md mb-8 text-ink">Combine com outros passeios</h2>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{related.map((r) => <TourCard key={r.id} tour={r} />)}</div>
          </div>
        </section>
      )}

      {meta.bookable && (
        <div className="fixed inset-x-0 bottom-0 z-40 flex items-center justify-between gap-3 border-t border-duna-800/10 bg-white/95 px-4 py-3 backdrop-blur lg:hidden">
          <TourPrice tour={t} className="[&_p:last-child]:text-lg" />
          <a href="#reservar" className={buttonClass('accent')}>Reservar</a>
        </div>
      )}
    </>
  );
}
