import type { Metadata } from 'next';
import { Suspense } from 'react';
import { TourCard } from '@/components/site/TourCard';
import { TourFilters } from '@/components/site/TourFilters';
import { BannerStrip, PageHero } from '@/components/site/Blocks';
import { EmptyState } from '@/components/ui/States';
import { ButtonLink } from '@/components/ui/Button';
import { WhatsAppIcon } from '@/components/ui/icons';
import { getBanners, getCategories, getDestinations, getSettings, getTours, type TourFilters as F } from '@/lib/data/public';
import { whatsappUrl } from '@/lib/whatsapp';

export const metadata: Metadata = {
  title: 'Passeios nos Lençóis Maranhenses',
  description: 'Veja os passeios da Aventure Turismo em Barreirinhas: lagoas, dunas, quadriciclo e experiências. Consulte datas, vagas e reserve.',
  alternates: { canonical: '/passeios' },
};

export default async function ToursPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const filters: F = { categoria: sp.categoria, destino: sp.destino, tipo: sp.tipo, duracao: sp.duracao, preco: sp.preco, disponibilidade: sp.disponibilidade, q: sp.q };
  const [tours, categories, destinations, settings, banners] = await Promise.all([getTours(filters), getCategories(), getDestinations(), getSettings(), getBanners('passeios')]);
  const hasFilters = Object.values(filters).some(Boolean);
  const wa = whatsappUrl(settings.whatsapp, settings.whatsapp_message);

  return (
    <>
      <PageHero title="Passeios" subtitle="Escolha a experiência, veja as datas com vagas e solicite sua reserva em poucos passos." image="/images/grupo-dunas.webp" />
      <div className="container relative z-10 -mt-8">
        <Suspense>
          <TourFilters categories={categories.map((c) => ({ value: c.slug, label: c.name }))} destinations={destinations.map((d) => ({ value: d.slug, label: d.name }))} />
        </Suspense>
      </div>
      {banners.length > 0 && <div className="mt-10"><BannerStrip banners={banners} /></div>}
      <section id="lista" className="container scroll-mt-24 py-12 sm:py-16" aria-live="polite">
        <p className="mb-6 text-sm text-ink-muted">{tours.length} {tours.length === 1 ? 'passeio encontrado' : 'passeios encontrados'}</p>
        {tours.length ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {tours.map((t, i) => <TourCard key={t.id} tour={t} priority={i < 3} />)}
          </div>
        ) : (
          <EmptyState
            title={hasFilters ? 'Nenhum passeio com esses filtros.' : 'Nenhum passeio disponível no momento.'}
            description={hasFilters ? 'Tente remover algum filtro ou fale com a gente para montar um roteiro.' : 'Novos passeios em breve. Fale com a gente para montar o seu roteiro.'}
            action={wa && <ButtonLink href={wa} variant="whatsapp"><WhatsAppIcon />Falar no WhatsApp</ButtonLink>}
          />
        )}
      </section>
    </>
  );
}
