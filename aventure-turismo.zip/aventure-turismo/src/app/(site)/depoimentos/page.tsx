import type { Metadata } from 'next';
import { PageHero, ReviewCard } from '@/components/site/Blocks';
import { EmptyState } from '@/components/ui/States';
import { ButtonLink } from '@/components/ui/Button';
import { getReviews, getSections } from '@/lib/data/public';

export const revalidate = 300;
export const metadata: Metadata = { title: 'Depoimentos', description: 'O que dizem os clientes que viveram os Lençóis Maranhenses com a Aventure Turismo.', alternates: { canonical: '/depoimentos' } };

export default async function ReviewsPage() {
  const [reviews, section] = await Promise.all([getReviews(), getSections()]);
  const r = section('reviews_section');
  const avg = reviews.length ? reviews.reduce((a, x) => a + x.rating, 0) / reviews.length : 0;
  return (
    <>
      <PageHero title={r.title} subtitle={r.subtitle} image="/images/familia-lagoa.webp">
        {reviews.length > 0 && <p className="mt-6 text-white/85"><span className="font-display text-3xl font-semibold text-white">{avg.toFixed(1).replace('.', ',')}</span> de 5, com base em {reviews.length} {reviews.length > 1 ? 'avaliações' : 'avaliação'} publicadas aqui</p>}
      </PageHero>
      <section className="container py-14 sm:py-20">
        {reviews.length
          ? <div className="columns-1 gap-6 space-y-6 md:columns-2 lg:columns-3">{reviews.map((x) => <div key={x.id} className="break-inside-avoid"><ReviewCard review={x} /></div>)}</div>
          : <EmptyState title="Os primeiros depoimentos chegam em breve." description="Viajou com a gente? Conte como foi a sua experiência." action={<ButtonLink href="/contato">Enviar meu depoimento</ButtonLink>} />}
      </section>
    </>
  );
}
