import type { Metadata } from 'next';
import { GalleryGrid } from '@/components/site/GalleryGrid';
import { PageHero } from '@/components/site/Blocks';
import { getGallery, getSections } from '@/lib/data/public';

export const revalidate = 300;
export const metadata: Metadata = { title: 'Galeria', description: 'Fotos dos passeios da Aventure Turismo: lagoas, dunas, quadriciclo e clientes nos Lençóis Maranhenses.', alternates: { canonical: '/galeria' } };

export default async function GalleryPage() {
  const [items, section] = await Promise.all([getGallery(), getSections()]);
  const g = section('gallery_section');
  return (
    <>
      <PageHero title={g.title} subtitle={g.subtitle} image="/images/por-do-sol.webp" />
      <section className="container py-14 sm:py-20"><GalleryGrid items={items} /></section>
    </>
  );
}
