import type { Metadata } from 'next';
import Link from 'next/link';
import { MapPin } from 'lucide-react';
import { PageHero } from '@/components/site/Blocks';
import { Img } from '@/components/ui/Img';
import { EmptyState } from '@/components/ui/States';
import { getDestinations, getTours } from '@/lib/data/public';

export const revalidate = 300;
export const metadata: Metadata = { title: 'Destinos', description: 'Barreirinhas, Lençóis Maranhenses, Santo Amaro e Lagoa Azul: conheça os destinos atendidos pela Aventure Turismo.', alternates: { canonical: '/destinos' } };

export default async function DestinationsPage() {
  const [destinations, tours] = await Promise.all([getDestinations(), getTours()]);
  return (
    <>
      <PageHero title="Destinos" subtitle="De Barreirinhas para as lagoas e dunas mais bonitas do Maranhão." image="/images/casal-dunas.webp" />
      <section className="container py-14 sm:py-20">
        {destinations.length ? (
          <ul className="grid gap-6 sm:grid-cols-2">
            {destinations.map((d, i) => {
              const count = tours.filter((t) => t.destination_id === d.id).length;
              return (
                <li key={d.id} className={i === 0 ? 'sm:col-span-2' : ''}>
                  <Link href={`/destinos/${d.slug}`} className="group relative flex aspect-[4/3] items-end overflow-hidden rounded-3xl sm:aspect-[16/9]">
                    <Img src={d.image_url} alt="" fill sizes={i === 0 ? '100vw' : '50vw'} className="object-cover transition-transform duration-700 group-hover:scale-[1.04]" />
                    <div className="absolute inset-0 bg-gradient-to-t from-duna-950/85 via-duna-950/10 to-transparent" />
                    <div className="relative p-6 text-white sm:p-8">
                      <p className="flex items-center gap-1.5 text-sm text-white/80"><MapPin className="size-4" />{d.location}</p>
                      <h2 className={i === 0 ? 'display-lg' : 'display-md'}>{d.name}</h2>
                      {d.short_description && <p className="mt-2 max-w-lg text-white/85">{d.short_description}</p>}
                      <p className="mt-3 text-sm font-semibold text-sol-400">{count ? `${count} ${count > 1 ? 'passeios' : 'passeio'}` : 'Consulte passeios'}</p>
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        ) : <EmptyState title="Nenhum destino publicado." />}
      </section>
    </>
  );
}
