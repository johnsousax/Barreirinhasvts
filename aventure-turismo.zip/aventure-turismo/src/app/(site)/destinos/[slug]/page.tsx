import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { PageHero } from '@/components/site/Blocks';
import { TourCard } from '@/components/site/TourCard';
import { EmptyState } from '@/components/ui/States';
import { ButtonLink } from '@/components/ui/Button';
import { WhatsAppIcon } from '@/components/ui/icons';
import { getDestinationBySlug, getDestinations, getSettings, getTours } from '@/lib/data/public';
import { whatsappUrl } from '@/lib/whatsapp';

export const revalidate = 300;

export async function generateStaticParams() {
  return (await getDestinations()).map((d) => ({ slug: d.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const d = await getDestinationBySlug((await params).slug);
  if (!d) return { title: 'Destino não encontrado' };
  return { title: `Passeios em ${d.name}`, description: d.short_description ?? undefined, alternates: { canonical: `/destinos/${d.slug}` }, openGraph: { images: d.image_url ? [d.image_url] : undefined } };
}

export default async function DestinationPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [d, settings] = await Promise.all([getDestinationBySlug(slug), getSettings()]);
  if (!d) notFound();
  const tours = await getTours({ destino: slug });
  const wa = whatsappUrl(settings.whatsapp, `Olá! Vim pelo site e quero conhecer ${d.name}.`);
  return (
    <>
      <PageHero title={d.name} subtitle={d.short_description ?? undefined} image={d.image_url ?? undefined} />
      <div className="container grid gap-12 py-14 sm:py-20 lg:grid-cols-[1fr_1.6fr]">
        <div>
          <p className="text-sm font-semibold text-lagoa-600">{d.location}</p>
          <div className="mt-3 space-y-4 text-lg leading-relaxed text-ink-soft">{(d.description ?? '').split(/\n+/).map((p, i) => <p key={i}>{p}</p>)}</div>
          {wa && <ButtonLink href={wa} variant="whatsapp" className="mt-8"><WhatsAppIcon />Tirar dúvidas</ButtonLink>}
        </div>
        <div>
          <h2 className="display-md mb-6 text-ink">Passeios em {d.name}</h2>
          {tours.length
            ? <div className="grid gap-6 sm:grid-cols-2">{tours.map((t) => <TourCard key={t.id} tour={t} />)}</div>
            : <EmptyState title="Nenhum passeio disponível no momento." description="Fale com a gente para montar um roteiro para este destino." />}
        </div>
      </div>
    </>
  );
}
