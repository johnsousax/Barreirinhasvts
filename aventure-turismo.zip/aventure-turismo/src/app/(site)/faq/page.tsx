import type { Metadata } from 'next';
import { FaqList, JsonLd, PageHero } from '@/components/site/Blocks';
import { EmptyState } from '@/components/ui/States';
import { ButtonLink } from '@/components/ui/Button';
import { WhatsAppIcon } from '@/components/ui/icons';
import { getFaqs, getSections, getSettings } from '@/lib/data/public';
import { whatsappUrl } from '@/lib/whatsapp';

export const revalidate = 300;
export const metadata: Metadata = { title: 'Perguntas frequentes', description: 'Como reservar, o que levar, transporte e melhor época para visitar os Lençóis Maranhenses.', alternates: { canonical: '/faq' } };

export default async function FaqPage() {
  const [faqs, section, s] = await Promise.all([getFaqs(), getSections(), getSettings()]);
  const f = section('faq_section');
  const wa = whatsappUrl(s.whatsapp, s.whatsapp_message);
  return (
    <>
      {faqs.length > 0 && <JsonLd data={{ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faqs.map((q) => ({ '@type': 'Question', name: q.question, acceptedAnswer: { '@type': 'Answer', text: q.answer } })) }} />}
      <PageHero title={f.title} subtitle={f.subtitle} image="/images/lagoa-casal.webp" />
      <section className="container max-w-3xl py-14 sm:py-20">
        {faqs.length ? <FaqList faqs={faqs} /> : <EmptyState title="Nenhuma pergunta publicada ainda." />}
        {wa && (
          <div className="mt-10 flex flex-col items-start justify-between gap-4 rounded-3xl bg-lagoa-50 p-6 sm:flex-row sm:items-center">
            <p className="font-display text-lg font-semibold">Ficou alguma dúvida?</p>
            <ButtonLink href={wa} variant="whatsapp"><WhatsAppIcon />Perguntar no WhatsApp</ButtonLink>
          </div>
        )}
      </section>
    </>
  );
}
