import Link from 'next/link';
import { CalendarDays, Compass, Headphones, Heart, Map, MapPin, ShieldCheck, Sparkles, Sun, Users, Waves } from 'lucide-react';
import { Img } from '@/components/ui/Img';
import { ButtonLink, buttonClass } from '@/components/ui/Button';
import { DuneDivider, InstagramIcon, WhatsAppIcon } from '@/components/ui/icons';
import { EmptyState } from '@/components/ui/States';
import { TourCard } from '@/components/site/TourCard';
import { TourFilters } from '@/components/site/TourFilters';
import { GalleryGrid } from '@/components/site/GalleryGrid';
import { Reveal } from '@/components/site/Reveal';
import { BannerStrip, FaqList, JsonLd, ReviewCard, SectionHeading } from '@/components/site/Blocks';
import { getBanners, getCategories, getDestinations, getFaqs, getGallery, getReviews, getSections, getSettings, getTours } from '@/lib/data/public';
import { instagramUrl } from '@/lib/settings';
import { whatsappUrl } from '@/lib/whatsapp';

export const revalidate = 300;

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  sparkles: Sparkles, heart: Heart, compass: Compass, users: Users, calendar: CalendarDays,
  headphones: Headphones, shield: ShieldCheck, sun: Sun, waves: Waves, map: Map,
};

type Item = { title: string; text: string; image_url?: string; icon?: string };

export default async function HomePage() {
  const [s, section, tours, categories, destinations, reviews, gallery, faqs, bannersTop, bannersMid] = await Promise.all([
    getSettings(), getSections(), getTours(), getCategories(), getDestinations(), getReviews(true), getGallery(), getFaqs(),
    getBanners('home_topo'), getBanners('home_meio'),
  ]);
  const hero = section('hero');
  const toursSec = section('tours_section');
  const exp = section<{ title: string; subtitle: string; items: Item[] }>('experiences');
  const about = section<{ title: string; text: string; image_url: string; image_url_2: string; highlights: Item[] }>('about');
  const benefits = section<{ title: string; items: Item[] }>('benefits');
  const reviewsSec = section('reviews_section');
  const gallerySec = section('gallery_section');
  const insta = section<{ title: string; subtitle: string; images: string[] }>('instagram');
  const faqSec = section('faq_section');
  const cta = section('cta');
  const wa = whatsappUrl(s.whatsapp, s.whatsapp_message);
  const featured = tours.filter((t) => t.featured);
  const showcase = (featured.length ? featured : tours).slice(0, 4);
  const [lead, ...rest] = showcase;

  return (
    <>
      {faqs.length > 0 && <JsonLd data={{ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faqs.slice(0, 5).map((f) => ({ '@type': 'Question', name: f.question, acceptedAnswer: { '@type': 'Answer', text: f.answer } })) }} />}

      {/* HERO */}
      <section className="relative isolate -mt-[4.5rem] flex min-h-[92svh] items-end overflow-hidden bg-duna-900 lg:-mt-20">
        <Img src={hero.image_url} alt="Lagoa de água azul entre as dunas dos Lençóis Maranhenses" fill priority sizes="100vw"
          className="-z-20 animate-hero-zoom object-cover object-[62%_center]" />
        <div className="absolute inset-0 -z-10 bg-[linear-gradient(90deg,rgba(6,26,51,.78)_0%,rgba(6,26,51,.35)_48%,rgba(6,26,51,0)_75%),linear-gradient(0deg,rgba(6,26,51,.55)_0%,rgba(6,26,51,0)_40%)]" />
        <div className="container pb-32 pt-40 sm:pb-40">
          <p className="inline-flex animate-rise items-center gap-2 rounded-full bg-white/15 px-3.5 py-1.5 text-sm font-medium text-white ring-1 ring-white/30 backdrop-blur">
            <MapPin className="size-4 text-sol-400" />{hero.location_label}
          </p>
          <h1 className="display-xl mt-6 max-w-[14ch] animate-rise text-white [animation-delay:120ms]">{hero.title}</h1>
          <p className="mt-6 max-w-xl animate-rise text-lg text-white/85 [animation-delay:240ms] sm:text-xl">{hero.subtitle}</p>
          <div className="mt-9 flex animate-rise flex-wrap gap-3 [animation-delay:360ms]">
            <ButtonLink href="#passeios" variant="accent" size="lg">{hero.primary_label}</ButtonLink>
            <ButtonLink href="/passeios" variant="light" size="lg">{hero.secondary_label}</ButtonLink>
          </div>
        </div>
        <DuneDivider className="absolute inset-x-0 bottom-0 h-16 w-full sm:h-24" fill="#ffffff" />
      </section>

      {/* BUSCA */}
      <section aria-label="Encontre seu passeio" className="container relative z-10 -mt-6 sm:-mt-10">
        <TourFilters variant="hero"
          categories={categories.map((c) => ({ value: c.slug, label: c.name }))}
          destinations={destinations.map((d) => ({ value: d.slug, label: d.name }))} />
      </section>

      {bannersTop.length > 0 && <div className="mt-12"><BannerStrip banners={bannersTop} /></div>}

      {/* PASSEIOS */}
      <section id="passeios" className="section scroll-mt-20" aria-labelledby="t-passeios">
        <div className="container">
          <SectionHeading id="t-passeios" title={toursSec.title} subtitle={toursSec.subtitle}
            action={<Link href="/passeios" className={buttonClass('secondary')}>Ver todos os passeios</Link>} />
          {!lead ? (
            <EmptyState title="Nenhum passeio disponível no momento." description="Fale com a gente pelo WhatsApp para montar o seu roteiro." action={wa && <ButtonLink href={wa} variant="whatsapp"><WhatsAppIcon />Falar no WhatsApp</ButtonLink>} />
          ) : (
            <div className="space-y-6">
              <Reveal><TourCard tour={lead} variant="wide" priority /></Reveal>
              {rest.length > 0 && (
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {rest.map((t, i) => <Reveal key={t.id} delay={i * 80}><TourCard tour={t} /></Reveal>)}
                </div>
              )}
            </div>
          )}
        </div>
      </section>

      {/* EXPERIÊNCIAS */}
      <section id="experiencias" className="section scroll-mt-20 bg-duna-950 text-white" aria-labelledby="t-exp">
        <div className="container">
          <div className="mb-10 max-w-2xl sm:mb-14">
            <h2 id="t-exp" className="display-lg">{exp.title}</h2>
            <p className="mt-4 text-lg text-white/70 sm:text-xl">{exp.subtitle}</p>
          </div>
          <ul className="scrollbar-none -mx-5 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-2 md:mx-0 md:grid md:grid-cols-4 md:grid-rows-[16rem_16rem] md:overflow-visible md:px-0">
            {exp.items.map((e, i) => (
              <li key={e.title + i} className={[
                'relative w-[78%] shrink-0 snap-start overflow-hidden rounded-3xl max-md:aspect-[4/5] md:w-auto',
                ['md:col-span-2 md:row-span-2', 'md:col-span-2', 'md:col-span-1', 'md:col-span-1', 'md:hidden', 'md:hidden'][i] ?? 'md:hidden',
              ].join(' ')}>
                <Img src={e.image_url} alt="" fill sizes="(min-width:768px) 50vw, 80vw" className="object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-duna-950/85 via-duna-950/10 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5 sm:p-6">
                  <h3 className={i === 0 ? 'display-md' : 'text-xl font-semibold'}>{e.title}</h3>
                  <p className="mt-1 text-white/80">{e.text}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* SOBRE */}
      <section className="section overflow-hidden" aria-labelledby="t-sobre">
        <div className="container grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          <Reveal className="relative order-last lg:order-first">
            <div className="relative aspect-[4/5] w-[82%] overflow-hidden rounded-3xl">
              <Img src={about.image_url} alt="Clientes da Aventure Turismo nas dunas" fill sizes="(min-width:1024px) 480px, 80vw" className="object-cover" />
            </div>
            <div className="absolute -bottom-8 right-0 aspect-square w-[46%] overflow-hidden rounded-3xl ring-8 ring-white">
              <Img src={about.image_url_2} alt="Passeio de quadriciclo" fill sizes="(min-width:1024px) 280px, 45vw" className="object-cover" />
            </div>
          </Reveal>
          <div>
            <h2 id="t-sobre" className="display-lg text-ink">{about.title}</h2>
            <p className="lead mt-6">{about.text}</p>
            <ul className="mt-10 grid gap-6 sm:grid-cols-2">
              {about.highlights.map((h) => (
                <li key={h.title} className="border-l-2 border-sol-500 pl-4">
                  <h3 className="font-semibold text-ink">{h.title}</h3>
                  <p className="mt-1 text-[15px] text-ink-soft">{h.text}</p>
                </li>
              ))}
            </ul>
            <Link href="/sobre" className={buttonClass('secondary', 'md', 'mt-10')}>Conheça a Aventure</Link>
          </div>
        </div>
      </section>

      {/* BENEFÍCIOS */}
      <section className="section bg-areia-50" aria-labelledby="t-ben">
        <div className="container">
          <SectionHeading id="t-ben" title={benefits.title} />
          <ul className="grid gap-x-10 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
            {benefits.items.map((b) => {
              const Icon = ICONS[b.icon ?? ''] ?? Sparkles;
              return (
                <li key={b.title} className="flex gap-4">
                  <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-white text-lagoa-600 shadow-soft"><Icon className="size-6" /></span>
                  <div>
                    <h3 className="text-lg font-semibold text-ink">{b.title}</h3>
                    <p className="mt-1 text-ink-soft">{b.text}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </section>

      {bannersMid.length > 0 && <div className="mt-16"><BannerStrip banners={bannersMid} /></div>}

      {/* DEPOIMENTOS */}
      {reviews.length > 0 && (
        <section className="section" aria-labelledby="t-dep">
          <div className="container">
            <SectionHeading id="t-dep" title={reviewsSec.title} subtitle={reviewsSec.subtitle}
              action={<Link href="/depoimentos" className={buttonClass('secondary')}>Ver todos</Link>} />
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {reviews.slice(0, 3).map((r) => <ReviewCard key={r.id} review={r} />)}
            </div>
          </div>
        </section>
      )}

      {/* GALERIA */}
      <section className={reviews.length ? 'pb-16 sm:pb-24' : 'section'} aria-labelledby="t-gal">
        <div className="container">
          <SectionHeading id="t-gal" title={gallerySec.title} subtitle={gallerySec.subtitle}
            action={<Link href="/galeria" className={buttonClass('secondary')}>Abrir galeria</Link>} />
          <GalleryGrid items={gallery} filterable={false} limit={8} />
        </div>
      </section>

      {/* INSTAGRAM */}
      {s.instagram && (
        <section className="section bg-lagoa-50" aria-labelledby="t-ig">
          <div className="container grid items-center gap-10 lg:grid-cols-[1fr_1.4fr]">
            <div>
              <p className="flex items-center gap-2 font-semibold text-lagoa-700"><InstagramIcon />@{s.instagram}</p>
              <h2 id="t-ig" className="display-lg mt-3 text-ink">{insta.title}</h2>
              <p className="lead mt-4">{insta.subtitle}</p>
              <ButtonLink href={instagramUrl(s.instagram)} className="mt-8"><InstagramIcon />Seguir no Instagram</ButtonLink>
            </div>
            <ul className="grid grid-cols-3 gap-2 sm:gap-3">
              {insta.images.slice(0, 6).map((src, i) => (
                <li key={src + i} className="relative aspect-square overflow-hidden rounded-2xl">
                  <a href={instagramUrl(s.instagram)} target="_blank" rel="noopener noreferrer" aria-label="Ver no Instagram" className="group block size-full">
                    <Img src={src} alt="" fill sizes="(min-width:1024px) 220px, 33vw" className="object-cover transition-transform duration-500 group-hover:scale-105" />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {/* FAQ */}
      {faqs.length > 0 && (
        <section className="section" aria-labelledby="t-faq">
          <div className="container grid gap-10 lg:grid-cols-[1fr_1.5fr]">
            <div>
              <h2 id="t-faq" className="display-lg text-ink">{faqSec.title}</h2>
              <p className="lead mt-4">{faqSec.subtitle}</p>
              <Link href="/faq" className={buttonClass('secondary', 'md', 'mt-8')}>Todas as perguntas</Link>
            </div>
            <FaqList faqs={faqs.slice(0, 5)} />
          </div>
        </section>
      )}

      {/* CTA FINAL */}
      <section className="relative isolate overflow-hidden bg-duna-900" aria-labelledby="t-cta">
        <Img src={cta.image_url} alt="" fill sizes="100vw" className="-z-10 object-cover opacity-60" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-duna-950/85 to-duna-950/30" />
        <div className="container py-24 sm:py-32">
          <h2 id="t-cta" className="display-xl max-w-[16ch] text-white">{cta.title}</h2>
          <p className="mt-6 max-w-xl text-lg text-white/85 sm:text-xl">{cta.subtitle}</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <ButtonLink href="/passeios" variant="accent" size="lg">{cta.primary_label}</ButtonLink>
            {wa && <ButtonLink href={wa} variant="whatsapp" size="lg"><WhatsAppIcon />{cta.secondary_label}</ButtonLink>}
          </div>
        </div>
      </section>
    </>
  );
}
