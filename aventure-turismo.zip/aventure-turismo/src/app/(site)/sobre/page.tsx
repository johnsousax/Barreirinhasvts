import type { Metadata } from 'next';
import { CalendarDays, Compass, Headphones, Heart, Map, ShieldCheck, Sparkles, Sun, Users, Waves } from 'lucide-react';
import { PageHero } from '@/components/site/Blocks';
import { Img } from '@/components/ui/Img';
import { ButtonLink } from '@/components/ui/Button';
import { WhatsAppIcon } from '@/components/ui/icons';
import { getSections, getSettings } from '@/lib/data/public';
import { whatsappUrl } from '@/lib/whatsapp';

export const revalidate = 300;
export const metadata: Metadata = { title: 'Sobre nós', description: 'Conheça a Aventure Turismo, agência de passeios e experiências em Barreirinhas e nos Lençóis Maranhenses.', alternates: { canonical: '/sobre' } };

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = { sparkles: Sparkles, heart: Heart, compass: Compass, users: Users, calendar: CalendarDays, headphones: Headphones, shield: ShieldCheck, sun: Sun, waves: Waves, map: Map };
type Item = { title: string; text: string; icon?: string };

export default async function AboutPage() {
  const [section, s] = await Promise.all([getSections(), getSettings()]);
  const about = section<{ title: string; text: string; image_url: string; image_url_2: string; highlights: Item[] }>('about');
  const benefits = section<{ title: string; items: Item[] }>('benefits');
  const wa = whatsappUrl(s.whatsapp, s.whatsapp_message);
  return (
    <>
      <PageHero title={about.title} subtitle={s.tagline} image={about.image_url} />
      <section className="container grid items-center gap-12 py-16 sm:py-24 lg:grid-cols-2">
        <div>
          <p className="lead">{about.text}</p>
          <ul className="mt-10 space-y-6">
            {about.highlights.map((h) => (
              <li key={h.title} className="border-l-2 border-sol-500 pl-4">
                <h2 className="text-lg font-semibold text-ink">{h.title}</h2>
                <p className="mt-1 text-ink-soft">{h.text}</p>
              </li>
            ))}
          </ul>
          {wa && <ButtonLink href={wa} variant="whatsapp" size="lg" className="mt-10"><WhatsAppIcon />Falar com a equipe</ButtonLink>}
        </div>
        <div className="relative aspect-[4/5] overflow-hidden rounded-3xl">
          <Img src={about.image_url_2} alt="Passeio da Aventure Turismo" fill sizes="(min-width:1024px) 50vw, 100vw" className="object-cover" />
        </div>
      </section>
      <section className="bg-areia-50 py-16 sm:py-24">
        <div className="container">
          <h2 className="display-lg mb-12 text-ink">{benefits.title}</h2>
          <ul className="grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {benefits.items.map((b) => {
              const Icon = ICONS[b.icon ?? ''] ?? Sparkles;
              return (
                <li key={b.title} className="flex gap-4">
                  <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-white text-lagoa-600 shadow-soft"><Icon className="size-6" /></span>
                  <div><h3 className="text-lg font-semibold">{b.title}</h3><p className="mt-1 text-ink-soft">{b.text}</p></div>
                </li>
              );
            })}
          </ul>
        </div>
      </section>
    </>
  );
}
