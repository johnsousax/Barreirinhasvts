import type { Metadata } from 'next';
import { LegalText } from '@/components/site/Blocks';
import { getSections, getSettings } from '@/lib/data/public';

export const revalidate = 3600;
export const metadata: Metadata = { title: 'Política de privacidade', alternates: { canonical: '/politica-de-privacidade' } };

export default async function PrivacyPage() {
  const [section, s] = await Promise.all([getSections(), getSettings()]);
  return (
    <section className="container max-w-3xl py-14 sm:py-20">
      <h1 className="display-lg text-ink">Política de privacidade</h1>
      <p className="mt-3 text-ink-muted">{s.company_name}</p>
      <LegalText text={section<{ privacy: string }>('legal').privacy} />
    </section>
  );
}
