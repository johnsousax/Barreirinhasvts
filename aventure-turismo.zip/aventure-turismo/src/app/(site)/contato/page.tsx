import type { Metadata } from 'next';
import { Clock, Mail, MapPin, Phone } from 'lucide-react';
import { ContactForm } from '@/components/site/ContactForm';
import { PageHero } from '@/components/site/Blocks';
import { ButtonLink } from '@/components/ui/Button';
import { InstagramIcon, WhatsAppIcon } from '@/components/ui/icons';
import { getSections, getSettings, getTours } from '@/lib/data/public';
import { formatPhone } from '@/lib/format';
import { instagramUrl } from '@/lib/settings';
import { whatsappUrl } from '@/lib/whatsapp';

export const revalidate = 300;
export const metadata: Metadata = { title: 'Contato', description: 'Fale com a Aventure Turismo pelo WhatsApp, Instagram ou formulário e planeje seu passeio nos Lençóis Maranhenses.', alternates: { canonical: '/contato' } };

export default async function ContactPage() {
  const [s, section, tours] = await Promise.all([getSettings(), getSections(), getTours()]);
  const c = section('contact_page');
  const wa = whatsappUrl(s.whatsapp, s.whatsapp_message);
  const location = [s.address, [s.city, s.state].filter(Boolean).join(' - ')].filter(Boolean).join(', ');
  return (
    <>
      <PageHero title={c.title} subtitle={c.text} image="/images/quadriciclo-casal.webp" />
      <section className="container grid gap-10 py-14 sm:py-20 lg:grid-cols-[1fr_1.4fr]">
        <div className="space-y-6">
          {wa && <ButtonLink href={wa} variant="whatsapp" size="lg" className="w-full sm:w-auto"><WhatsAppIcon />Conversar no WhatsApp</ButtonLink>}
          <ul className="space-y-4 text-ink-soft">
            {s.whatsapp && <li className="flex gap-3"><WhatsAppIcon className="size-5 text-lagoa-600" />{formatPhone(s.whatsapp)}</li>}
            {s.phone && <li className="flex gap-3"><Phone className="size-5 text-lagoa-600" /><a href={`tel:${s.phone.replace(/\D/g, '')}`}>{formatPhone(s.phone)}</a></li>}
            {s.email && <li className="flex gap-3"><Mail className="size-5 text-lagoa-600" /><a href={`mailto:${s.email}`}>{s.email}</a></li>}
            {s.instagram && <li className="flex gap-3"><InstagramIcon className="size-5 text-lagoa-600" /><a href={instagramUrl(s.instagram)} target="_blank" rel="noopener noreferrer">@{s.instagram}</a></li>}
            {location && <li className="flex gap-3"><MapPin className="size-5 shrink-0 text-lagoa-600" />{s.maps_url ? <a href={s.maps_url} target="_blank" rel="noopener noreferrer" className="underline">{location}</a> : location}</li>}
            {s.business_hours && <li className="flex gap-3"><Clock className="size-5 text-lagoa-600" />{s.business_hours}</li>}
          </ul>
        </div>
        <ContactForm tours={tours.map((t) => ({ value: t.name, label: t.name }))} />
      </section>
    </>
  );
}
