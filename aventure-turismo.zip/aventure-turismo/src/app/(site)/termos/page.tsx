import type { Metadata } from 'next';
import { LegalText } from '@/components/site/Blocks';
import { getSections, getSettings } from '@/lib/data/public';

export const revalidate = 3600;
export const metadata: Metadata = { title: 'Termos de uso', alternates: { canonical: '/termos' } };

export default async function TermsPage() {
  const [section, s] = await Promise.all([getSections(), getSettings()]);
  return (
    <section className="container max-w-3xl py-14 sm:py-20">
      <h1 className="display-lg text-ink">Termos de uso</h1>
      <p className="mt-3 text-ink-muted">{s.company_name}</p>
      <LegalText text={section<{ terms: string }>('legal').terms} />
    </section>
  );
}
