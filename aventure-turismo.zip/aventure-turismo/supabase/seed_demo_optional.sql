-- OPCIONAL — horários de TESTE para validar calendário e controle de vagas.
-- Não use em produção sem revisar: datas e capacidades são fictícias.
insert into public.tour_schedules (tour_id, date, start_time, capacity, notes)
select t.id, (current_date + d)::date, h::time, 12, 'DEMONSTRATIVO — apagar antes de publicar'
  from public.tours t
  cross join generate_series(2, 20, 3) d
  cross join unnest(array['08:00', '14:00']) h
 where t.is_placeholder
on conflict do nothing;
