-- =====================================================================
-- AVENTURE TURISMO — Estrutura do banco (Supabase / PostgreSQL 15+)
-- Ordem de execução: 0001_schema → 0002_functions → 0003_policies → seed
-- =====================================================================

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;
create extension if not exists unaccent with schema extensions;

-- ─── Tipos ────────────────────────────────────────────────────────────
create type public.app_role           as enum ('admin', 'gerente', 'atendente');
create type public.publication_status as enum ('rascunho', 'publicado', 'arquivado');
create type public.tour_status        as enum ('disponivel', 'poucas_vagas', 'ultimas_vagas', 'esgotado', 'encerrado', 'em_breve', 'oculto');
create type public.schedule_status    as enum ('aberto', 'fechado', 'cancelado', 'realizado');
create type public.booking_status     as enum ('pendente', 'confirmada', 'aguardando_pagamento', 'pago', 'cancelada', 'concluida', 'nao_compareceu');
create type public.lead_stage         as enum ('novo', 'em_atendimento', 'proposta_enviada', 'aguardando', 'reservado', 'concluido', 'perdido');
create type public.payment_status     as enum ('pendente', 'pago', 'estornado', 'cancelado');
create type public.idea_status        as enum ('ideia', 'planejada', 'em_andamento', 'concluida', 'arquivada');
create type public.priority_level     as enum ('baixa', 'media', 'alta');

-- Função utilitária de updated_at
create or replace function public.touch_updated_at() returns trigger
language plpgsql set search_path = public as $$ begin new.updated_at := now(); return new; end $$;

-- ─── Usuários, papéis e permissões ───────────────────────────────────
-- "users" = auth.users (Supabase Auth). "profiles" guarda os dados da equipe.
create table public.roles (
  key         public.app_role primary key,
  name        text not null,
  description text
);

create table public.permissions (
  key         text primary key,
  description text not null
);

create table public.role_permissions (
  role       public.app_role not null references public.roles(key) on delete cascade,
  permission text not null references public.permissions(key) on delete cascade,
  primary key (role, permission)
);

create table public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null default '',
  email       text,
  role        public.app_role not null default 'atendente',
  active      boolean not null default false,
  avatar_url  text,
  last_seen_at timestamptz,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger trg_profiles_updated before update on public.profiles for each row execute function public.touch_updated_at();

-- ─── Catálogo ────────────────────────────────────────────────────────
create table public.tour_categories (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  slug        text not null unique,
  sort_order  int  not null default 0,
  active      boolean not null default true,
  created_at  timestamptz not null default now()
);

create table public.destinations (
  id                uuid primary key default gen_random_uuid(),
  name              text not null,
  slug              text not null unique,
  short_description text,
  description       text,
  image_url         text,
  location          text,
  latitude          numeric(9,6),
  longitude         numeric(9,6),
  status            public.publication_status not null default 'publicado',
  sort_order        int not null default 0,
  is_placeholder    boolean not null default false,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create trigger trg_destinations_updated before update on public.destinations for each row execute function public.touch_updated_at();
create index idx_destinations_status on public.destinations(status, sort_order);

create table public.tours (
  id                 uuid primary key default gen_random_uuid(),
  slug               text not null unique,
  name               text not null,
  short_description  text,
  description        text,
  category_id        uuid references public.tour_categories(id) on delete set null,
  destination_id     uuid references public.destinations(id) on delete set null,
  tour_type          text not null default 'compartilhado' check (tour_type in ('compartilhado', 'privativo', 'ambos')),
  duration_label     text,                         -- ex.: "Meio período (aprox. 4h)"
  duration_minutes   int check (duration_minutes is null or duration_minutes > 0),
  price              numeric(10,2) check (price is null or price >= 0),          -- null = "Consulte"
  promo_price        numeric(10,2) check (promo_price is null or promo_price >= 0),
  price_note         text,                         -- ex.: "por pessoa"
  capacity           int not null default 0 check (capacity >= 0),              -- capacidade padrão p/ novos horários
  default_times      text[] not null default '{}', -- ex.: {08:00,14:00}
  meeting_point      text,
  itinerary          jsonb not null default '[]'::jsonb,  -- [{time,title,description}]
  included           text[] not null default '{}',
  not_included       text[] not null default '{}',
  recommendations    text[] not null default '{}',
  important_info     text[] not null default '{}',
  cover_url          text,
  photos             text[] not null default '{}',
  video_url          text,
  status             public.tour_status not null default 'disponivel',
  publication        public.publication_status not null default 'rascunho',
  featured           boolean not null default false,
  sort_order         int not null default 0,
  whatsapp_message   text,
  seo_title          text,
  seo_description    text,
  draft_data         jsonb,                        -- alterações salvas como rascunho de um passeio já publicado
  is_placeholder     boolean not null default false,
  published_at       timestamptz,
  created_by         uuid references public.profiles(id) on delete set null,
  updated_by         uuid references public.profiles(id) on delete set null,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create trigger trg_tours_updated before update on public.tours for each row execute function public.touch_updated_at();
create index idx_tours_public   on public.tours(publication, status, featured desc, sort_order);
create index idx_tours_category on public.tours(category_id);
create index idx_tours_dest     on public.tours(destination_id);

create table public.tour_schedules (
  id               uuid primary key default gen_random_uuid(),
  tour_id          uuid not null references public.tours(id) on delete cascade,
  date             date not null,
  start_time       time,
  capacity         int  not null check (capacity >= 0),
  manual_occupied  int  not null default 0 check (manual_occupied >= 0),  -- vagas vendidas fora do sistema
  status           public.schedule_status not null default 'aberto',
  notes            text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create unique index uq_schedule_slot on public.tour_schedules(tour_id, date, coalesce(start_time, '00:00'::time));
create index idx_schedules_date on public.tour_schedules(date, status);
create trigger trg_schedules_updated before update on public.tour_schedules for each row execute function public.touch_updated_at();

-- ─── CRM ─────────────────────────────────────────────────────────────
create table public.customers (
  id               uuid primary key default gen_random_uuid(),
  name             text not null,
  phone            text,
  whatsapp         text,
  email            text,
  city             text,
  state            text,
  notes            text,
  source           text not null default 'site',
  first_contact_at timestamptz not null default now(),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create trigger trg_customers_updated before update on public.customers for each row execute function public.touch_updated_at();
create index idx_customers_phone on public.customers(phone);
create index idx_customers_email on public.customers(lower(email));
create index idx_customers_name  on public.customers(lower(name));

create table public.customer_interactions (
  id           uuid primary key default gen_random_uuid(),
  customer_id  uuid not null references public.customers(id) on delete cascade,
  channel      text not null default 'nota' check (channel in ('whatsapp', 'ligacao', 'email', 'presencial', 'instagram', 'nota')),
  description  text not null,
  created_by   uuid references public.profiles(id) on delete set null,
  created_at   timestamptz not null default now()
);
create index idx_interactions_customer on public.customer_interactions(customer_id, created_at desc);

create table public.leads (
  id            uuid primary key default gen_random_uuid(),
  customer_id   uuid references public.customers(id) on delete set null,
  name          text not null,
  phone         text,
  whatsapp      text,
  email         text,
  interest      text,
  tour_id       uuid references public.tours(id) on delete set null,
  desired_date  date,
  people        int check (people is null or people > 0),
  notes         text,
  source        text not null default 'site',
  stage         public.lead_stage not null default 'novo',
  lost_reason   text,
  assigned_to   uuid references public.profiles(id) on delete set null,
  position      double precision not null default extract(epoch from now()),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create trigger trg_leads_updated before update on public.leads for each row execute function public.touch_updated_at();
create index idx_leads_stage   on public.leads(stage, position);
create index idx_leads_created on public.leads(created_at desc);
create index idx_leads_phone   on public.leads(phone);

create table public.lead_history (
  id          uuid primary key default gen_random_uuid(),
  lead_id     uuid not null references public.leads(id) on delete cascade,
  from_stage  public.lead_stage,
  to_stage    public.lead_stage,
  note        text,
  created_by  uuid references public.profiles(id) on delete set null,
  created_at  timestamptz not null default now()
);
create index idx_lead_history on public.lead_history(lead_id, created_at desc);

-- ─── Reservas ────────────────────────────────────────────────────────
create sequence public.booking_code_seq;

create table public.bookings (
  id            uuid primary key default gen_random_uuid(),
  code          text not null unique,
  customer_id   uuid not null references public.customers(id) on delete restrict,
  tour_id       uuid not null references public.tours(id) on delete restrict,
  schedule_id   uuid references public.tour_schedules(id) on delete set null,
  lead_id       uuid references public.leads(id) on delete set null,
  date          date not null,
  start_time    time,
  people        int  not null check (people > 0),
  unit_price    numeric(10,2) check (unit_price is null or unit_price >= 0),
  total_amount  numeric(10,2) check (total_amount is null or total_amount >= 0),
  status        public.booking_status not null default 'pendente',
  source        text not null default 'site',
  notes         text,
  created_by    uuid references public.profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create trigger trg_bookings_updated before update on public.bookings for each row execute function public.touch_updated_at();
create index idx_bookings_date     on public.bookings(date, status);
create index idx_bookings_status   on public.bookings(status);
create index idx_bookings_tour     on public.bookings(tour_id, date);
create index idx_bookings_customer on public.bookings(customer_id);
create index idx_bookings_schedule on public.bookings(schedule_id) where schedule_id is not null;
create index idx_bookings_created  on public.bookings(created_at desc);

create table public.booking_passengers (
  id          uuid primary key default gen_random_uuid(),
  booking_id  uuid not null references public.bookings(id) on delete cascade,
  name        text not null,
  document    text,
  birth_date  date,
  phone       text,
  notes       text,
  created_at  timestamptz not null default now()
);
create index idx_passengers_booking on public.booking_passengers(booking_id);

create table public.booking_history (
  id           uuid primary key default gen_random_uuid(),
  booking_id   uuid not null references public.bookings(id) on delete cascade,
  from_status  public.booking_status,
  to_status    public.booking_status,
  note         text,
  changed_by   uuid references public.profiles(id) on delete set null,
  created_at   timestamptz not null default now()
);
create index idx_booking_history on public.booking_history(booking_id, created_at desc);

create table public.payments (
  id          uuid primary key default gen_random_uuid(),
  booking_id  uuid not null references public.bookings(id) on delete cascade,
  amount      numeric(10,2) not null check (amount >= 0),
  method      text not null default 'pix' check (method in ('pix', 'cartao', 'dinheiro', 'transferencia', 'outro')),
  status      public.payment_status not null default 'pago',
  paid_at     timestamptz default now(),
  notes       text,
  created_by  uuid references public.profiles(id) on delete set null,
  created_at  timestamptz not null default now()
);
create index idx_payments_booking on public.payments(booking_id);
create index idx_payments_paid_at on public.payments(paid_at) where status = 'pago';

-- ─── Conteúdo ────────────────────────────────────────────────────────
create table public.reviews (
  id                uuid primary key default gen_random_uuid(),
  author_name       text not null,
  author_photo_url  text,
  author_city       text,
  rating            smallint not null default 5 check (rating between 1 and 5),
  comment           text not null,
  review_date       date,
  tour_id           uuid references public.tours(id) on delete set null,
  visible           boolean not null default true,
  featured          boolean not null default false,
  sort_order        int not null default 0,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create trigger trg_reviews_updated before update on public.reviews for each row execute function public.touch_updated_at();
create index idx_reviews_public on public.reviews(visible, featured desc, sort_order);

create table public.media (
  id          uuid primary key default gen_random_uuid(),
  url         text not null,
  path        text,                 -- caminho no bucket "media" (null = arquivo estático/externo)
  kind        text not null default 'image' check (kind in ('image', 'video')),
  category    text not null default 'geral',
  alt         text,
  width       int,
  height      int,
  size_bytes  bigint,
  created_by  uuid references public.profiles(id) on delete set null,
  created_at  timestamptz not null default now()
);
create index idx_media_category on public.media(category, created_at desc);

create table public.gallery (
  id          uuid primary key default gen_random_uuid(),
  media_id    uuid references public.media(id) on delete set null,
  image_url   text not null,
  title       text,
  category    text not null default 'Lençóis',
  visible     boolean not null default true,
  featured    boolean not null default false,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger trg_gallery_updated before update on public.gallery for each row execute function public.touch_updated_at();
create index idx_gallery_public on public.gallery(visible, category, sort_order);

create table public.faqs (
  id          uuid primary key default gen_random_uuid(),
  question    text not null,
  answer      text not null,
  sort_order  int not null default 0,
  visible     boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create trigger trg_faqs_updated before update on public.faqs for each row execute function public.touch_updated_at();

-- Configurações públicas da empresa (linha única). NÃO guarde segredos aqui.
create table public.site_settings (
  id          int primary key default 1 check (id = 1),
  data        jsonb not null default '{}'::jsonb,
  updated_by  uuid references public.profiles(id) on delete set null,
  updated_at  timestamptz not null default now()
);

-- Seções editáveis do site com rascunho e versão publicada
create table public.site_sections (
  key           text primary key,
  draft         jsonb not null default '{}'::jsonb,
  published     jsonb not null default '{}'::jsonb,
  has_unpublished boolean not null default false,
  updated_by    uuid references public.profiles(id) on delete set null,
  updated_at    timestamptz not null default now(),
  published_by  uuid references public.profiles(id) on delete set null,
  published_at  timestamptz
);

create table public.banners (
  id            uuid primary key default gen_random_uuid(),
  title         text not null,
  subtitle      text,
  image_url     text,
  button_label  text,
  button_url    text,
  placement     text not null default 'home_topo' check (placement in ('home_topo', 'home_meio', 'passeios')),
  starts_at     timestamptz,
  ends_at       timestamptz,
  active        boolean not null default false,
  sort_order    int not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  check (ends_at is null or starts_at is null or ends_at > starts_at)
);
create trigger trg_banners_updated before update on public.banners for each row execute function public.touch_updated_at();
create index idx_banners_active on public.banners(active, placement, starts_at, ends_at);

create table public.ideas (
  id           uuid primary key default gen_random_uuid(),
  title        text not null,
  description  text,
  category     text not null default 'outros',
  priority     public.priority_level not null default 'media',
  status       public.idea_status not null default 'ideia',
  due_date     date,
  owner        text,
  notes        text,
  created_by   uuid references public.profiles(id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create trigger trg_ideas_updated before update on public.ideas for each row execute function public.touch_updated_at();
create index idx_ideas_status on public.ideas(status, priority);

-- ─── Notificações e auditoria ────────────────────────────────────────
create table public.notifications (
  id           uuid primary key default gen_random_uuid(),
  kind         text not null,  -- new_booking | new_lead | low_seats | sold_out | booking_cancelled | system
  title        text not null,
  body         text,
  link         text,
  entity       text,
  entity_id    uuid,
  user_id      uuid references public.profiles(id) on delete cascade,  -- null = toda a equipe
  created_at   timestamptz not null default now()
);
create index idx_notifications_created on public.notifications(created_at desc);

create table public.notification_reads (
  notification_id uuid not null references public.notifications(id) on delete cascade,
  user_id         uuid not null references public.profiles(id) on delete cascade,
  read_at         timestamptz not null default now(),
  primary key (notification_id, user_id)
);

create table public.audit_logs (
  id          bigserial primary key,
  user_id     uuid references public.profiles(id) on delete set null,
  user_name   text,
  action      text not null,         -- create | update | delete | status | publish | login ...
  entity      text not null,         -- tours | bookings | ...
  entity_id   text,
  summary     text not null,         -- frase legível
  changes     jsonb,
  created_at  timestamptz not null default now()
);
create index idx_audit_created on public.audit_logs(created_at desc);
create index idx_audit_entity  on public.audit_logs(entity, entity_id);
