-- =====================================================================
-- Funções, gatilhos e RPCs
-- =====================================================================

-- ─── Autorização ─────────────────────────────────────────────────────
create or replace function public.current_app_role() returns public.app_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and active
$$;

create or replace function public.is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and active)
$$;

create or replace function public.has_permission(p_permission text) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1
      from public.profiles pr
      join public.role_permissions rp on rp.role = pr.role
     where pr.id = auth.uid() and pr.active and rp.permission = p_permission
  )
$$;

-- Novo usuário do Auth → perfil. O primeiro usuário vira administrador ativo.
-- Os demais nascem INATIVOS e só são ativados pelo painel (convite do admin),
-- o que bloqueia cadastros abertos mesmo que o signup esteja habilitado.
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_first boolean;
begin
  select not exists (select 1 from public.profiles) into v_first;
  insert into public.profiles (id, full_name, email, role, active)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1)),
    new.email,
    case when v_first then 'admin'::public.app_role else 'atendente'::public.app_role end,
    v_first
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- Impede que um usuário altere o próprio papel/status sem permissão users.manage
create or replace function public.guard_profile_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if (new.role is distinct from old.role or new.active is distinct from old.active)
     and auth.uid() is not null
     and not public.has_permission('users.manage') then
    raise exception 'Sem permissão para alterar papel ou status do usuário' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger trg_guard_profile before update on public.profiles
for each row execute function public.guard_profile_update();

-- ─── Utilidades ──────────────────────────────────────────────────────
create or replace function public.slugify(p text) returns text
language sql stable set search_path = public, extensions as $$
  select trim(both '-' from regexp_replace(lower(extensions.unaccent(coalesce(p, ''))), '[^a-z0-9]+', '-', 'g'))
$$;

create or replace function public.digits_only(p text) returns text
language sql immutable set search_path = public as $$ select nullif(regexp_replace(coalesce(p, ''), '\D', '', 'g'), '') $$;

create or replace function public.notify_staff(p_kind text, p_title text, p_body text, p_link text, p_entity text, p_entity_id uuid)
returns void language sql security definer set search_path = public as $$
  insert into public.notifications (kind, title, body, link, entity, entity_id)
  values (p_kind, p_title, p_body, p_link, p_entity, p_entity_id);
$$;

-- Status que ocupam vaga
create or replace function public.booking_holds_seat(s public.booking_status) returns boolean
language sql immutable set search_path = public as $$ select s in ('confirmada', 'aguardando_pagamento', 'pago', 'concluida') $$;

-- ─── Disponibilidade ─────────────────────────────────────────────────
-- vagas disponíveis = capacidade − vagas ocupadas manualmente − reservas que seguram vaga
create or replace view public.schedule_availability with (security_invoker = true) as
select s.id,
       s.tour_id,
       s.date,
       s.start_time,
       s.capacity,
       s.manual_occupied,
       s.status,
       s.notes,
       coalesce(b.booked, 0)::int                                   as booked,
       coalesce(b.pending, 0)::int                                  as pending,
       greatest(s.capacity - s.manual_occupied - coalesce(b.booked, 0), 0)::int as available
  from public.tour_schedules s
  left join lateral (
    select sum(people) filter (where public.booking_holds_seat(status)) as booked,
           sum(people) filter (where status = 'pendente')              as pending
      from public.bookings where schedule_id = s.id
  ) b on true;

-- Versão pública (sem expor reservas): horários futuros de passeios publicados
create or replace function public.get_tour_availability(p_tour_id uuid)
returns table (schedule_id uuid, date date, start_time time, capacity int, available int, status public.schedule_status)
language sql stable security definer set search_path = public as $$
  select sa.id, sa.date, sa.start_time, sa.capacity, sa.available, sa.status
    from public.schedule_availability sa
    join public.tours t on t.id = sa.tour_id
   where sa.tour_id = p_tour_id
     and t.publication = 'publicado'
     and sa.status in ('aberto', 'fechado')
     and sa.date >= (now() at time zone 'America/Fortaleza')::date
   order by sa.date, sa.start_time nulls first
   limit 60
$$;

create or replace function public.get_tours_availability()
returns table (tour_id uuid, schedules int, capacity int, available int, next_date date)
language sql stable security definer set search_path = public as $$
  select sa.tour_id,
         count(*)::int,
         sum(sa.capacity - sa.manual_occupied)::int,
         sum(case when sa.status = 'aberto' then sa.available else 0 end)::int,
         min(sa.date) filter (where sa.status = 'aberto' and sa.available > 0)
    from public.schedule_availability sa
    join public.tours t on t.id = sa.tour_id
   where t.publication = 'publicado'
     and sa.status in ('aberto', 'fechado')
     and sa.date >= (now() at time zone 'America/Fortaleza')::date
   group by sa.tour_id
$$;

create or replace function public.get_published_sections()
returns table (key text, content jsonb)
language sql stable security definer set search_path = public as $$
  select key, published from public.site_sections
$$;

-- ─── Reservas: código, capacidade, histórico e alertas ───────────────
create or replace function public.bookings_before_write() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  v_sched public.tour_schedules%rowtype;
  v_taken int;
begin
  if tg_op = 'INSERT' and (new.code is null or new.code = '') then
    new.code := 'AVT-' || to_char(now() at time zone 'America/Fortaleza', 'YYMM') || '-' || lpad(nextval('public.booking_code_seq')::text, 4, '0');
  end if;

  if new.schedule_id is not null then
    select * into v_sched from public.tour_schedules where id = new.schedule_id for update;
    if v_sched.tour_id <> new.tour_id then
      raise exception 'O horário selecionado não pertence a este passeio' using errcode = '22023';
    end if;
    new.date := v_sched.date;
    new.start_time := v_sched.start_time;

    if public.booking_holds_seat(new.status)
       and (tg_op = 'INSERT'
            or not public.booking_holds_seat(old.status)
            or new.people <> old.people
            or new.schedule_id is distinct from old.schedule_id) then
      select coalesce(sum(people), 0) into v_taken
        from public.bookings
       where schedule_id = new.schedule_id
         and public.booking_holds_seat(status)
         and id <> new.id;
      if v_taken + v_sched.manual_occupied + new.people > v_sched.capacity then
        raise exception 'CAPACIDADE_EXCEDIDA: restam % vagas neste horário',
          greatest(v_sched.capacity - v_sched.manual_occupied - v_taken, 0) using errcode = 'P0001';
      end if;
    end if;
  end if;

  if new.total_amount is null and new.unit_price is not null then
    new.total_amount := new.unit_price * new.people;
  end if;
  return new;
end $$;
create trigger trg_bookings_before before insert or update on public.bookings
for each row execute function public.bookings_before_write();

create or replace function public.check_schedule_alerts(p_schedule_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare
  r record;
  v_threshold numeric := coalesce((select (data ->> 'low_seats_threshold')::numeric from public.site_settings where id = 1), 0.2);
begin
  if p_schedule_id is null then return; end if;
  select sa.*, t.name as tour_name into r
    from public.schedule_availability sa join public.tours t on t.id = sa.tour_id
   where sa.id = p_schedule_id;
  if not found or r.capacity = 0 then return; end if;

  if r.available = 0 then
    if not exists (select 1 from public.notifications where kind = 'sold_out' and entity_id = p_schedule_id) then
      perform public.notify_staff('sold_out', 'Passeio esgotado',
        r.tour_name || ' em ' || to_char(r.date, 'DD/MM') || coalesce(' às ' || to_char(r.start_time, 'HH24:MI'), '') || ' está lotado.',
        '/admin/passeios/' || r.tour_id || '#horarios', 'tour_schedules', p_schedule_id);
    end if;
  elsif r.available::numeric / r.capacity <= v_threshold then
    if not exists (select 1 from public.notifications where kind = 'low_seats' and entity_id = p_schedule_id
                   and created_at > now() - interval '12 hours') then
      perform public.notify_staff('low_seats', 'Poucas vagas',
        r.tour_name || ' em ' || to_char(r.date, 'DD/MM') || ': restam ' || r.available || ' vagas.',
        '/admin/passeios/' || r.tour_id || '#horarios', 'tour_schedules', p_schedule_id);
    end if;
  end if;
end $$;

create or replace function public.bookings_after_write() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_tour text; v_customer text;
begin
  select name into v_tour from public.tours where id = new.tour_id;
  select name into v_customer from public.customers where id = new.customer_id;

  if tg_op = 'INSERT' then
    insert into public.booking_history (booking_id, from_status, to_status, note, changed_by)
    values (new.id, null, new.status, 'Reserva criada (' || new.source || ')', auth.uid());
    perform public.notify_staff('new_booking', 'Nova reserva recebida',
      v_customer || ' · ' || v_tour || ' · ' || to_char(new.date, 'DD/MM') || ' · ' || new.people || ' pessoa(s)',
      '/admin/reservas/' || new.id, 'bookings', new.id);
  elsif new.status is distinct from old.status then
    insert into public.booking_history (booking_id, from_status, to_status, changed_by)
    values (new.id, old.status, new.status, auth.uid());
    if new.status = 'cancelada' then
      perform public.notify_staff('booking_cancelled', 'Reserva cancelada',
        new.code || ' · ' || v_customer || ' · ' || v_tour, '/admin/reservas/' || new.id, 'bookings', new.id);
    end if;
  end if;

  if new.schedule_id is not null then
    perform public.check_schedule_alerts(new.schedule_id);
  end if;
  return new;
end $$;
create trigger trg_bookings_after after insert or update on public.bookings
for each row execute function public.bookings_after_write();

-- ─── Leads: histórico e alerta ───────────────────────────────────────
create or replace function public.leads_after_write() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    insert into public.lead_history (lead_id, from_stage, to_stage, note, created_by)
    values (new.id, null, new.stage, 'Lead criado (' || new.source || ')', auth.uid());
    if new.source <> 'reserva_site' then
      perform public.notify_staff('new_lead', 'Novo lead recebido',
        new.name || coalesce(' · ' || new.interest, ''), '/admin/leads?lead=' || new.id, 'leads', new.id);
    end if;
  elsif new.stage is distinct from old.stage then
    insert into public.lead_history (lead_id, from_stage, to_stage, created_by)
    values (new.id, old.stage, new.stage, auth.uid());
  end if;
  return new;
end $$;
create trigger trg_leads_after after insert or update on public.leads
for each row execute function public.leads_after_write();

-- ─── RPCs públicas (site) ────────────────────────────────────────────
-- Localiza ou cria cliente pelo telefone
create or replace function public.upsert_customer(p_name text, p_phone text, p_email text, p_source text)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_digits text := public.digits_only(p_phone);
begin
  select id into v_id from public.customers
   where public.digits_only(phone) = v_digits or public.digits_only(whatsapp) = v_digits
   order by created_at limit 1;
  if v_id is null and p_email is not null and p_email <> '' then
    select id into v_id from public.customers where lower(email) = lower(p_email) order by created_at limit 1;
  end if;
  if v_id is null then
    insert into public.customers (name, phone, whatsapp, email, source)
    values (p_name, p_phone, p_phone, nullif(p_email, ''), p_source)
    returning id into v_id;
  else
    update public.customers set email = coalesce(email, nullif(p_email, '')) where id = v_id;
  end if;
  return v_id;
end $$;

create or replace function public.request_booking(
  p_tour_id uuid, p_schedule_id uuid, p_desired_date date, p_desired_time text,
  p_name text, p_phone text, p_email text, p_people int, p_notes text
) returns table (booking_code text, booking_date date, tour_name text)
language plpgsql security definer set search_path = public as $$
declare
  v_tour public.tours%rowtype;
  v_customer uuid;
  v_lead uuid;
  v_date date;
  v_avail int;
  v_code text;
  v_today date := (now() at time zone 'America/Fortaleza')::date;
begin
  -- validações de servidor (nunca confiar só no front)
  if coalesce(length(trim(p_name)), 0) < 2 or length(p_name) > 120 then raise exception 'Informe seu nome' using errcode = '22023'; end if;
  if length(coalesce(public.digits_only(p_phone), '')) not between 10 and 13 then raise exception 'Informe um WhatsApp válido com DDD' using errcode = '22023'; end if;
  if p_people is null or p_people < 1 or p_people > 50 then raise exception 'Quantidade de pessoas inválida' using errcode = '22023'; end if;
  if p_email is not null and p_email <> '' and p_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'E-mail inválido' using errcode = '22023'; end if;
  if length(coalesce(p_notes, '')) > 1000 then raise exception 'Observações muito longas' using errcode = '22023'; end if;

  -- limite simples contra abuso: 5 solicitações por telefone a cada 30 minutos
  if (select count(*) from public.leads
       where public.digits_only(phone) = public.digits_only(p_phone)
         and created_at > now() - interval '30 minutes') >= 5 then
    raise exception 'Muitas solicitações seguidas. Fale com a gente pelo WhatsApp.' using errcode = '22023';
  end if;

  select * into v_tour from public.tours where id = p_tour_id and publication = 'publicado';
  if not found then raise exception 'Passeio indisponível' using errcode = '22023'; end if;
  if v_tour.status in ('esgotado', 'encerrado', 'em_breve', 'oculto') then
    raise exception 'Este passeio não está recebendo reservas no momento' using errcode = '22023';
  end if;

  if p_schedule_id is not null then
    select sa.date, sa.available into v_date, v_avail
      from public.schedule_availability sa
     where sa.id = p_schedule_id and sa.tour_id = p_tour_id and sa.status = 'aberto';
    if not found then raise exception 'Horário indisponível' using errcode = '22023'; end if;
    if v_date < v_today then raise exception 'Escolha uma data futura' using errcode = '22023'; end if;
    if v_avail < p_people then
      raise exception 'Restam apenas % vagas nesse horário', v_avail using errcode = '22023';
    end if;
  else
    if exists (select 1 from public.tour_schedules where tour_id = p_tour_id and date >= v_today and status = 'aberto') then
      raise exception 'Escolha um dos horários disponíveis' using errcode = '22023';
    end if;
    if p_desired_date is null or p_desired_date < v_today then raise exception 'Escolha uma data futura' using errcode = '22023'; end if;
    v_date := p_desired_date;
  end if;

  v_customer := public.upsert_customer(trim(p_name), p_phone, p_email, 'site');

  insert into public.leads (customer_id, name, phone, whatsapp, email, interest, tour_id, desired_date, people, notes, source, stage)
  values (v_customer, trim(p_name), p_phone, p_phone, nullif(p_email, ''), 'Reserva: ' || v_tour.name, p_tour_id, v_date, p_people,
          nullif(concat_ws(' | ', nullif(p_desired_time, ''), nullif(p_notes, '')), ''), 'reserva_site', 'novo')
  returning id into v_lead;

  insert into public.bookings (customer_id, tour_id, schedule_id, lead_id, date, start_time, people, unit_price, status, source, notes)
  values (v_customer, p_tour_id, p_schedule_id, v_lead, v_date,
          case when p_schedule_id is null and p_desired_time ~ '^\d{2}:\d{2}$' then p_desired_time::time end,
          p_people, coalesce(v_tour.promo_price, v_tour.price), 'pendente', 'site',
          nullif(concat_ws(' | ', case when p_schedule_id is null then nullif('Horário desejado: ' || coalesce(p_desired_time, ''), 'Horário desejado: ') end, nullif(p_notes, '')), ''))
  returning code into v_code;

  return query select v_code, v_date, v_tour.name;
end $$;

create or replace function public.submit_lead(
  p_name text, p_phone text, p_email text, p_interest text, p_tour_id uuid, p_desired_date date, p_notes text, p_source text
) returns uuid language plpgsql security definer set search_path = public as $$
declare v_customer uuid; v_id uuid;
begin
  if coalesce(length(trim(p_name)), 0) < 2 or length(p_name) > 120 then raise exception 'Informe seu nome' using errcode = '22023'; end if;
  if length(coalesce(public.digits_only(p_phone), '')) not between 10 and 13 then raise exception 'Informe um WhatsApp válido com DDD' using errcode = '22023'; end if;
  if p_email is not null and p_email <> '' and p_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' then raise exception 'E-mail inválido' using errcode = '22023'; end if;
  if length(coalesce(p_notes, '')) > 1500 then raise exception 'Mensagem muito longa' using errcode = '22023'; end if;
  if (select count(*) from public.leads where public.digits_only(phone) = public.digits_only(p_phone)
        and created_at > now() - interval '30 minutes') >= 5 then
    raise exception 'Muitas mensagens seguidas. Fale com a gente pelo WhatsApp.' using errcode = '22023';
  end if;

  v_customer := public.upsert_customer(trim(p_name), p_phone, p_email, coalesce(p_source, 'site'));
  insert into public.leads (customer_id, name, phone, whatsapp, email, interest, tour_id, desired_date, notes, source)
  values (v_customer, trim(p_name), p_phone, p_phone, nullif(p_email, ''), left(p_interest, 200),
          (select id from public.tours where id = p_tour_id and publication = 'publicado'),
          p_desired_date, p_notes, left(coalesce(p_source, 'site'), 40))
  returning id into v_id;
  return v_id;
end $$;

-- Permissões de execução: o público só executa as RPCs do site
revoke all on function public.request_booking(uuid, uuid, date, text, text, text, text, int, text) from public;
revoke all on function public.submit_lead(text, text, text, text, uuid, date, text, text) from public;
revoke all on function public.upsert_customer(text, text, text, text) from public, anon, authenticated;
revoke all on function public.notify_staff(text, text, text, text, text, uuid) from public, anon, authenticated;
revoke all on function public.check_schedule_alerts(uuid) from public, anon, authenticated;
revoke all on function public.handle_new_user() from public, anon, authenticated;
grant execute on function public.request_booking(uuid, uuid, date, text, text, text, text, int, text) to anon, authenticated;
grant execute on function public.submit_lead(text, text, text, text, uuid, date, text, text) to anon, authenticated;
grant execute on function public.get_tour_availability(uuid) to anon, authenticated;
grant execute on function public.get_tours_availability() to anon, authenticated;
grant execute on function public.get_published_sections() to anon, authenticated;

-- Funções de gatilho não devem ser chamadas pela API
revoke all on function public.bookings_after_write() from public, anon, authenticated;
revoke all on function public.bookings_before_write() from public, anon, authenticated;
revoke all on function public.guard_profile_update() from public, anon, authenticated;
revoke all on function public.leads_after_write() from public, anon, authenticated;
revoke all on function public.touch_updated_at() from public, anon, authenticated;
