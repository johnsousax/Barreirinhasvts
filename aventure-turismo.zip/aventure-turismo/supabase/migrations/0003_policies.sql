-- =====================================================================
-- Row Level Security — as permissões valem no banco, não só na interface
-- =====================================================================

alter table public.roles                 enable row level security;
alter table public.permissions           enable row level security;
alter table public.role_permissions      enable row level security;
alter table public.profiles              enable row level security;
alter table public.tour_categories       enable row level security;
alter table public.destinations          enable row level security;
alter table public.tours                 enable row level security;
alter table public.tour_schedules        enable row level security;
alter table public.customers             enable row level security;
alter table public.customer_interactions enable row level security;
alter table public.leads                 enable row level security;
alter table public.lead_history          enable row level security;
alter table public.bookings              enable row level security;
alter table public.booking_passengers    enable row level security;
alter table public.booking_history       enable row level security;
alter table public.payments              enable row level security;
alter table public.reviews               enable row level security;
alter table public.media                 enable row level security;
alter table public.gallery               enable row level security;
alter table public.faqs                  enable row level security;
alter table public.site_settings         enable row level security;
alter table public.site_sections         enable row level security;
alter table public.banners               enable row level security;
alter table public.ideas                 enable row level security;
alter table public.notifications         enable row level security;
alter table public.notification_reads    enable row level security;
alter table public.audit_logs            enable row level security;

-- ─── Papéis e perfis ─────────────────────────────────────────────────
create policy "equipe lê papéis"        on public.roles            for select to authenticated using (public.is_staff());
create policy "equipe lê permissões"    on public.permissions      for select to authenticated using (public.is_staff());
create policy "lê permissões do papel"  on public.role_permissions for select to authenticated using (public.is_staff() or role = (select role from public.profiles where id = auth.uid()));
create policy "admin gerencia papéis"   on public.role_permissions for all    to authenticated using (public.has_permission('users.manage')) with check (public.has_permission('users.manage'));

create policy "lê o próprio perfil"     on public.profiles for select to authenticated using (id = auth.uid() or public.is_staff());
create policy "edita o próprio perfil"  on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "admin gerencia perfis"   on public.profiles for all    to authenticated using (public.has_permission('users.manage')) with check (public.has_permission('users.manage'));

-- ─── Leitura pública do catálogo e conteúdo ──────────────────────────
create policy "público lê categorias"   on public.tour_categories for select using (active or public.is_staff());
create policy "gestão de categorias"    on public.tour_categories for all to authenticated using (public.has_permission('tours.manage')) with check (public.has_permission('tours.manage'));

create policy "público lê destinos"     on public.destinations for select using (status = 'publicado' or public.is_staff());
create policy "gestão de destinos"      on public.destinations for all to authenticated using (public.has_permission('destinations.manage')) with check (public.has_permission('destinations.manage'));

create policy "público lê passeios"     on public.tours for select using ((publication = 'publicado' and status <> 'oculto') or public.has_permission('tours.view'));
create policy "gestão de passeios"      on public.tours for all to authenticated using (public.has_permission('tours.manage')) with check (public.has_permission('tours.manage'));

create policy "equipe lê horários"      on public.tour_schedules for select to authenticated using (public.has_permission('tours.view'));
create policy "gestão de horários"      on public.tour_schedules for all to authenticated using (public.has_permission('tours.manage')) with check (public.has_permission('tours.manage'));

create policy "público lê depoimentos"  on public.reviews for select using (visible or public.is_staff());
create policy "gestão de depoimentos"   on public.reviews for all to authenticated using (public.has_permission('content.manage')) with check (public.has_permission('content.manage'));

create policy "público lê galeria"      on public.gallery for select using (visible or public.is_staff());
create policy "gestão da galeria"       on public.gallery for all to authenticated using (public.has_permission('content.manage')) with check (public.has_permission('content.manage'));

create policy "público lê faq"          on public.faqs for select using (visible or public.is_staff());
create policy "gestão do faq"           on public.faqs for all to authenticated using (public.has_permission('content.manage')) with check (public.has_permission('content.manage'));

create policy "público lê banners"      on public.banners for select using (
  (active and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now())) or public.is_staff());
create policy "gestão de banners"       on public.banners for all to authenticated using (public.has_permission('content.manage')) with check (public.has_permission('content.manage'));

create policy "público lê configurações" on public.site_settings for select using (true);
create policy "gestão de configurações"  on public.site_settings for all to authenticated using (public.has_permission('settings.manage')) with check (public.has_permission('settings.manage'));

-- rascunhos NÃO são públicos: o site usa get_published_sections()
create policy "equipe lê seções"        on public.site_sections for select to authenticated using (public.is_staff());
create policy "gestão de seções"        on public.site_sections for all to authenticated using (public.has_permission('content.manage')) with check (public.has_permission('content.manage'));

create policy "equipe lê mídia"         on public.media for select to authenticated using (public.is_staff());
create policy "gestão de mídia"         on public.media for all to authenticated using (public.has_permission('content.manage') or public.has_permission('tours.manage'))
  with check (public.has_permission('content.manage') or public.has_permission('tours.manage'));

-- ─── Operação (somente equipe) ───────────────────────────────────────
create policy "clientes"                on public.customers for all to authenticated using (public.has_permission('customers.manage')) with check (public.has_permission('customers.manage'));
create policy "interações"              on public.customer_interactions for all to authenticated using (public.has_permission('customers.manage')) with check (public.has_permission('customers.manage'));
create policy "leads"                   on public.leads for all to authenticated using (public.has_permission('leads.manage')) with check (public.has_permission('leads.manage'));
create policy "histórico de leads"      on public.lead_history for all to authenticated using (public.has_permission('leads.manage')) with check (public.has_permission('leads.manage'));
create policy "reservas"                on public.bookings for all to authenticated using (public.has_permission('bookings.manage')) with check (public.has_permission('bookings.manage'));
create policy "passageiros"             on public.booking_passengers for all to authenticated using (public.has_permission('bookings.manage')) with check (public.has_permission('bookings.manage'));
create policy "histórico de reservas"   on public.booking_history for select to authenticated using (public.has_permission('bookings.manage'));
create policy "anota histórico"         on public.booking_history for update to authenticated using (public.has_permission('bookings.manage')) with check (public.has_permission('bookings.manage'));
create policy "pagamentos"              on public.payments for all to authenticated using (public.has_permission('bookings.manage')) with check (public.has_permission('bookings.manage'));
create policy "ideias"                  on public.ideas for all to authenticated using (public.has_permission('ideas.manage')) with check (public.has_permission('ideas.manage'));

create policy "lê notificações"         on public.notifications for select to authenticated using (public.has_permission('notifications.view') and (user_id is null or user_id = auth.uid()));
create policy "admin apaga notificações" on public.notifications for delete to authenticated using (public.has_permission('settings.manage'));
create policy "marca como lida"         on public.notification_reads for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid() and public.is_staff());

create policy "lê auditoria"            on public.audit_logs for select to authenticated using (public.has_permission('audit.view'));
create policy "registra auditoria"      on public.audit_logs for insert to authenticated with check (public.is_staff() and user_id = auth.uid());

-- A view herda o RLS de tour_schedules/bookings (security_invoker)
grant select on public.schedule_availability to authenticated;

-- ─── Storage: bucket público de mídia ────────────────────────────────
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('media', 'media', true, 10485760, array['image/jpeg', 'image/png', 'image/webp', 'image/avif', 'image/gif', 'video/mp4', 'video/webm'])
on conflict (id) do nothing;

-- bucket público: as URLs funcionam sem policy de leitura; listar arquivos só para a equipe
create policy "equipe lista mídia" on storage.objects for select to authenticated using (bucket_id = 'media' and public.is_staff());
create policy "equipe envia"      on storage.objects for insert to authenticated with check (bucket_id = 'media' and (public.has_permission('content.manage') or public.has_permission('tours.manage')));
create policy "equipe atualiza"   on storage.objects for update to authenticated using (bucket_id = 'media' and (public.has_permission('content.manage') or public.has_permission('tours.manage')));
create policy "equipe remove"     on storage.objects for delete to authenticated using (bucket_id = 'media' and public.has_permission('content.manage'));
