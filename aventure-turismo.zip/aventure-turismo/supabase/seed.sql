-- =====================================================================
-- Dados iniciais — Aventure Turismo
-- Conteúdo marcado com is_placeholder = true é DEMONSTRATIVO e aparece
-- com o selo "Conteúdo demonstrativo" no painel. Preços, durações e
-- horários NÃO foram informados pela empresa e ficam em branco
-- ("Consulte valores") até o administrador preencher.
-- =====================================================================

-- ─── Papéis e permissões ─────────────────────────────────────────────
insert into public.roles (key, name, description) values
  ('admin',     'Administrador', 'Acesso total ao sistema'),
  ('gerente',   'Gerente',       'Reservas, clientes, passeios, calendário e relatórios'),
  ('atendente', 'Atendente',     'Clientes, leads e reservas')
on conflict (key) do update set name = excluded.name, description = excluded.description;

insert into public.permissions (key, description) values
  ('dashboard.view',      'Ver o painel inicial'),
  ('tours.view',          'Ver passeios, horários e calendário'),
  ('tours.manage',        'Criar e editar passeios, horários e vagas'),
  ('destinations.manage', 'Criar e editar destinos'),
  ('bookings.manage',     'Gerenciar reservas, passageiros e pagamentos'),
  ('customers.manage',    'Gerenciar clientes'),
  ('leads.manage',        'Gerenciar leads e funil'),
  ('reports.view',        'Ver relatórios e faturamento'),
  ('content.manage',      'Editar site, galeria, depoimentos, banners, FAQ e mídia'),
  ('ideas.manage',        'Gerenciar ideias'),
  ('notifications.view',  'Receber notificações internas'),
  ('settings.manage',     'Alterar configurações da empresa'),
  ('users.manage',        'Gerenciar usuários e permissões'),
  ('audit.view',          'Ver registro de auditoria')
on conflict (key) do update set description = excluded.description;

insert into public.role_permissions (role, permission)
select 'admin', key from public.permissions
on conflict do nothing;

insert into public.role_permissions (role, permission) values
  ('gerente', 'dashboard.view'), ('gerente', 'tours.view'), ('gerente', 'tours.manage'),
  ('gerente', 'destinations.manage'), ('gerente', 'bookings.manage'), ('gerente', 'customers.manage'),
  ('gerente', 'leads.manage'), ('gerente', 'reports.view'), ('gerente', 'notifications.view'),
  ('atendente', 'dashboard.view'), ('atendente', 'tours.view'), ('atendente', 'bookings.manage'),
  ('atendente', 'customers.manage'), ('atendente', 'leads.manage'), ('atendente', 'notifications.view')
on conflict do nothing;

-- ─── Configurações (dados públicos do Instagram oficial) ─────────────
insert into public.site_settings (id, data) values (1, jsonb_build_object(
  'company_name',       'Aventure Turismo',
  'tagline',            'Viva grandes experiências',
  'description',        'Passeios, experiências e aventuras nos Lençóis Maranhenses, saindo de Barreirinhas - MA.',
  'logo_url',           '/brand/logo.png',
  'favicon_url',        '/brand/icon.png',
  'phone',              '',
  'whatsapp',           '5598992396818',
  'whatsapp_message',   'Olá! Vim pelo site da Aventure Turismo e gostaria de informações sobre os passeios.',
  'whatsapp_tour_message', 'Olá! Vim pelo site da Aventure Turismo e gostaria de informações sobre o passeio {passeio}.',
  'email',              '',
  'instagram',          'aventure_turismo',
  'facebook_url',       '',
  'tiktok_url',         '',
  'youtube_url',        '',
  'address',            '',
  'city',               'Barreirinhas',
  'state',              'MA',
  'zip',                '',
  'maps_url',           '',
  'business_hours',     '',
  'seo_title',          'Aventure Turismo | Passeios nos Lençóis Maranhenses em Barreirinhas - MA',
  'seo_description',    'Passeios, experiências e aventuras nos Lençóis Maranhenses: lagoas, dunas e quadriciclo saindo de Barreirinhas - MA. Reserve pelo site ou WhatsApp.',
  'og_image',           '/images/og-cover.jpg',
  'low_seats_threshold', 0.2,
  'show_closed_tours',  true,
  'notify_email',       '',
  'notify_new_booking', true,
  'notify_new_lead',    true
)) on conflict (id) do nothing;

-- Seções do site: conteúdo padrão vem do código (src/lib/cms-schema.ts) até ser editado
insert into public.site_sections (key) values
  ('hero'), ('about'), ('benefits'), ('experiences'), ('tours_section'), ('reviews_section'),
  ('gallery_section'), ('instagram'), ('faq_section'), ('cta'), ('footer'), ('contact_page'), ('legal')
on conflict (key) do nothing;

-- ─── Categorias ──────────────────────────────────────────────────────
insert into public.tour_categories (name, slug, sort_order) values
  ('Lagoas', 'lagoas', 1), ('Quadriciclo', 'quadriciclo', 2), ('4x4', '4x4', 3),
  ('Passeios privativos', 'privativos', 4), ('Passeios compartilhados', 'compartilhados', 5),
  ('Experiências', 'experiencias', 6), ('Passeios românticos', 'romanticos', 7),
  ('Passeios de aventura', 'aventura', 8), ('Transfer', 'transfer', 9), ('Outros', 'outros', 10)
on conflict (slug) do nothing;

-- ─── Destinos ────────────────────────────────────────────────────────
insert into public.destinations (name, slug, short_description, description, image_url, location, sort_order, is_placeholder) values
  ('Barreirinhas', 'barreirinhas',
   'Ponto de partida para os Lençóis Maranhenses, às margens do rio Preguiças.',
   'Barreirinhas é a principal porta de entrada do Parque Nacional dos Lençóis Maranhenses. É daqui que a Aventure Turismo organiza as saídas para as lagoas, as dunas e os passeios pela região. [Texto demonstrativo: revise no painel.]',
   '/images/por-do-sol.webp', 'Barreirinhas - MA', 1, true),
  ('Lençóis Maranhenses', 'lencois-maranhenses',
   'Dunas brancas e lagoas de água cristalina a perder de vista.',
   'O Parque Nacional dos Lençóis Maranhenses reúne um grande campo de dunas que, na temporada de chuvas, forma lagoas de água doce azul e verde entre a areia. [Texto demonstrativo: revise no painel.]',
   '/images/grupo-dunas.webp', 'Parque Nacional dos Lençóis Maranhenses - MA', 2, true),
  ('Santo Amaro', 'santo-amaro',
   'Outra entrada para os Lençóis, com paisagens de dunas e lagoas.',
   'Santo Amaro do Maranhão é outro acesso aos Lençóis Maranhenses. [Texto demonstrativo: detalhes do roteiro devem ser preenchidos pela equipe.]',
   '/images/casal-dunas.webp', 'Santo Amaro do Maranhão - MA', 3, true),
  ('Lagoa Azul', 'lagoa-azul',
   'Uma das lagoas mais conhecidas do circuito saindo de Barreirinhas.',
   'A Lagoa Azul faz parte de um dos circuitos mais procurados dos Lençóis Maranhenses a partir de Barreirinhas. [Texto demonstrativo: revise no painel.]',
   '/images/lagoa-casal.webp', 'Lençóis Maranhenses - MA', 4, true)
on conflict (slug) do nothing;

-- ─── Passeios (sem preço/duração/horário: dados não informados) ──────
insert into public.tours (slug, name, short_description, description, category_id, destination_id, tour_type,
  cover_url, photos, included, not_included, recommendations, important_info, status, publication, featured, sort_order, is_placeholder, published_at)
values
  ('lagoa-azul', 'Lagoa Azul',
   'Banho de lagoa entre as dunas no circuito mais clássico saindo de Barreirinhas.',
   'Um dos passeios mais procurados dos Lençóis Maranhenses: travessia até o campo de dunas e parada para banho nas lagoas do circuito da Lagoa Azul. [Descrição demonstrativa: ajuste roteiro, duração e valores no painel.]',
   (select id from public.tour_categories where slug = 'lagoas'),
   (select id from public.destinations where slug = 'lagoa-azul'), 'compartilhado',
   '/images/lagoa-casal.webp', array['/images/lagoa-casal.webp', '/images/lagoa-bandeira.webp', '/images/casal-lagoa.webp'],
   array['[A definir] Transporte', '[A definir] Condução local'], array['[A definir] Alimentação'],
   array['Protetor solar e óculos de sol', 'Roupa de banho e toalha', 'Água para hidratação'],
   array['Horários, valores e ponto de encontro são confirmados no atendimento.'],
   'disponivel', 'publicado', true, 1, true, now()),
  ('santo-amaro', 'Santo Amaro',
   'Um dia de dunas e lagoas pelo lado de Santo Amaro dos Lençóis.',
   'Passeio para conhecer a região de Santo Amaro do Maranhão e suas paisagens de dunas e lagoas. [Descrição demonstrativa: ajuste roteiro, duração e valores no painel.]',
   (select id from public.tour_categories where slug = 'lagoas'),
   (select id from public.destinations where slug = 'santo-amaro'), 'compartilhado',
   '/images/casal-dunas.webp', array['/images/casal-dunas.webp', '/images/grupo-dunas.webp'],
   array['[A definir] Transporte'], array['[A definir] Alimentação'],
   array['Protetor solar e óculos de sol', 'Roupa de banho e toalha', 'Água para hidratação'],
   array['Horários, valores e ponto de encontro são confirmados no atendimento.'],
   'disponivel', 'publicado', true, 2, true, now()),
  ('passeio-de-quadriciclo', 'Passeio de Quadriciclo',
   'Adrenalina sobre a areia pilotando pelas dunas da região.',
   'Experiência de aventura pilotando quadriciclo pelas dunas e trilhas de areia da região. [Descrição demonstrativa: ajuste roteiro, duração, regras de pilotagem e valores no painel.]',
   (select id from public.tour_categories where slug = 'quadriciclo'),
   (select id from public.destinations where slug = 'barreirinhas'), 'ambos',
   '/images/quadriciclo-grupo.webp', array['/images/quadriciclo-grupo.webp', '/images/quadriciclo-casal.webp'],
   array['[A definir] Quadriciclo', '[A definir] Condutor/guia'], array['[A definir]'],
   array['Óculos de sol e boné', 'Roupas leves', 'Calçado confortável'],
   array['Regras para pilotagem (idade, habilitação) devem ser confirmadas com a equipe.'],
   'disponivel', 'publicado', true, 3, true, now()),
  ('lencois-maranhenses', 'Lençóis Maranhenses',
   'O cenário que dá nome à região: dunas brancas e lagoas cristalinas.',
   'Passeio pelos Lençóis Maranhenses com tempo para caminhar pelas dunas, fotografar e aproveitar as lagoas. [Descrição demonstrativa: ajuste roteiro, duração e valores no painel.]',
   (select id from public.tour_categories where slug = 'lagoas'),
   (select id from public.destinations where slug = 'lencois-maranhenses'), 'compartilhado',
   '/images/grupo-dunas.webp', array['/images/grupo-dunas.webp', '/images/familia-lagoa.webp', '/images/grupo-bandeira.webp', '/images/por-do-sol.webp'],
   array['[A definir] Transporte'], array['[A definir] Alimentação'],
   array['Protetor solar e óculos de sol', 'Roupa de banho e toalha', 'Água para hidratação'],
   array['Horários, valores e ponto de encontro são confirmados no atendimento.'],
   'disponivel', 'publicado', true, 4, true, now())
on conflict (slug) do nothing;

-- ─── Mídia e galeria (fotos oficiais fornecidas) ─────────────────────
insert into public.media (url, category, alt) values
  ('/images/lagoa-bandeira.webp',    'Lagoas',      'Turista com a bandeira do Brasil diante de lagoa azul nos Lençóis'),
  ('/images/lagoa-casal.webp',       'Lagoas',      'Casal de braços abertos na beira de uma lagoa entre as dunas'),
  ('/images/casal-lagoa.webp',       'Clientes',    'Casal sorrindo dentro da lagoa'),
  ('/images/quadriciclo-grupo.webp', 'Quadriciclo', 'Dois casais em quadriciclos com aerogerador ao fundo'),
  ('/images/quadriciclo-casal.webp', 'Quadriciclo', 'Casal sobre quadriciclo vermelho nas dunas'),
  ('/images/casal-dunas.webp',       'Lençóis',     'Casal nas dunas brancas ao lado de uma lagoa'),
  ('/images/grupo-dunas.webp',       'Clientes',    'Grupo de turistas sobre as dunas com lagoa ao fundo'),
  ('/images/familia-lagoa.webp',     'Experiências','Família comemorando dentro da lagoa'),
  ('/images/grupo-bandeira.webp',    'Clientes',    'Grupo segurando a bandeira do Brasil na lagoa'),
  ('/images/por-do-sol.webp',        'Pôr do sol',  'Pôr do sol sobre as dunas com turistas no alto'),
  ('/images/og-cover.jpg',           'Lagoas',      'Capa para compartilhamento');

insert into public.gallery (image_url, title, category, sort_order, featured)
select url, alt, category, row_number() over (), url in ('/images/lagoa-bandeira.webp', '/images/por-do-sol.webp', '/images/quadriciclo-grupo.webp')
  from public.media where url <> '/images/og-cover.jpg';

-- ─── FAQ (respostas genéricas e verdadeiras; revise no painel) ───────
insert into public.faqs (question, answer, sort_order) values
  ('Como faço para reservar?', 'Escolha o passeio no site, selecione a data e envie a solicitação. Nossa equipe confirma a disponibilidade e os detalhes pelo WhatsApp. Se preferir, fale direto com a gente pelo botão de WhatsApp.', 1),
  ('Quais formas de pagamento são aceitas?', 'As formas de pagamento são informadas pela equipe no momento da confirmação da reserva.', 2),
  ('Os passeios são compartilhados ou privativos?', 'Cada passeio indica na página se é compartilhado, privativo ou se oferece as duas opções. Em caso de dúvida, pergunte no atendimento.', 3),
  ('Qual a duração dos passeios?', 'A duração aparece na página de cada passeio. Quando não estiver indicada, nossa equipe informa no atendimento.', 4),
  ('O que devo levar?', 'Protetor solar, óculos de sol, boné ou chapéu, roupa de banho, toalha e água. Evite levar objetos de valor para as dunas.', 5),
  ('Como funciona o transporte?', 'O transporte e o ponto de encontro de cada passeio são informados na página do passeio e confirmados na reserva.', 6),
  ('Qual a melhor época para visitar os Lençóis?', 'As lagoas se formam com as chuvas do primeiro semestre e costumam estar mais cheias entre junho e setembro. Fale com a equipe para saber como está a região na data da sua viagem.', 7);
